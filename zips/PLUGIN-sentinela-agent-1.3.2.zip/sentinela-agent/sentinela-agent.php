<?php
/**
 * Plugin Name:       Sentinela Agent
 * Description:       Envia ao painel Sentinela um relatório SOMENTE LEITURA do site (versões, atualizações, administradores, integridade de arquivos). Não recebe comandos, não abre rota, não altera nada.
 * Version:           1.3.2
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Sentinela
 * Update URI:        https://raw.githubusercontent.com/ccesarc/sentinela-plugins
 * License:           Proprietário (uso interno)
 *
 * Configuração — SÓ no wp-config.php (segredo fora do banco do WordPress):
 *
 *   define( 'SENTINELA_SITE_ID',  '...' );
 *   define( 'SENTINELA_SECRET',   '...' );
 *   define( 'SENTINELA_ENDPOINT', 'https://sentinela.exemplo.com.br/api/v1/agent/report' );
 *
 * Princípios (docs/AGENTE-WP.md do Sentinela):
 *  1. Somente leitura: coleta e envia. Nunca altera o site.
 *  2. Nunca obedece o painel: a resposta é ignorada além do status HTTP.
 *  3. Sem endpoint no site: nenhuma rota REST, AJAX ou admin-post.
 *  4. Mínimo de dados: sem conteúdo de arquivos, senhas, e-mails ou dados de clientes.
 */

defined( 'ABSPATH' ) || exit;

define( 'SENTINELA_AGENT_VERSION', '1.3.2' );
define( 'SENTINELA_AGENT_DIR', __DIR__ );

require_once __DIR__ . '/includes/class-coletor.php';
require_once __DIR__ . '/includes/class-envio.php';
require_once __DIR__ . '/includes/atualizador.php';

final class Sentinela_Agent {
	const EVENTO        = 'sentinela_agent_enviar';
	const EVENTO_RAPIDO = 'sentinela_agent_enviar_logo';
	const OPCAO_STATUS  = 'sentinela_agent_status';

	public static function iniciar() {
		add_filter( 'cron_schedules', array( __CLASS__, 'agendas' ) );
		add_action( self::EVENTO, array( __CLASS__, 'enviar' ) );
		add_action( self::EVENTO_RAPIDO, array( __CLASS__, 'enviar' ) );
		add_action( 'init', array( __CLASS__, 'garantir_agenda' ) );

		// Eventos que merecem relatório logo (não envia na hora: agenda para daqui a 1 min).
		foreach ( array( 'user_register', 'set_user_role', 'activated_plugin', 'deactivated_plugin', 'switch_theme', 'upgrader_process_complete', '_core_updated_successfully' ) as $gancho ) {
			add_action( $gancho, array( __CLASS__, 'enviar_logo' ), 99 );
		}
		add_action( 'wp_login', array( __CLASS__, 'login' ), 99, 2 );
		// O Blindagem varreu, pôs em quarentena, reconheceu ou viu mudança em mu-plugins: relatório logo, para o
		// painel não ficar horas mostrando o que já foi limpo. Só observa as opções dele; não fala com ele.
		foreach ( array( 'blindagem_rel_varredura', 'blindagem_rel_integridade', 'blindagem_quarentena', 'blindagem_reconhecidos', 'blindagem_mu_lista' ) as $opcao ) {
			add_action( 'update_option_' . $opcao, array( __CLASS__, 'enviar_logo' ) );
			add_action( 'add_option_' . $opcao, array( __CLASS__, 'enviar_logo' ) );
		}

		if ( is_admin() ) {
			add_action( 'admin_notices', array( __CLASS__, 'aviso' ) );
		}
	}

	public static function agendas( $s ) {
		$s['sentinela_6h'] = array(
			'interval' => 6 * HOUR_IN_SECONDS,
			'display'  => 'A cada 6 horas (Sentinela)',
		);
		return $s;
	}

	public static function garantir_agenda() {
		if ( ! wp_next_scheduled( self::EVENTO ) ) {
			wp_schedule_event( time() + 120, 'sentinela_6h', self::EVENTO );
		}
	}

	public static function enviar_logo() {
		if ( ! wp_next_scheduled( self::EVENTO_RAPIDO ) ) {
			wp_schedule_single_event( time() + 60, self::EVENTO_RAPIDO );
		}
	}

	public static function login( $login, $usuario ) {
		if ( $usuario instanceof WP_User && user_can( $usuario, 'manage_options' ) ) {
			self::enviar_logo();
		}
	}

	public static function configurado() {
		return defined( 'SENTINELA_SITE_ID' ) && defined( 'SENTINELA_SECRET' ) && defined( 'SENTINELA_ENDPOINT' )
			&& is_string( SENTINELA_SITE_ID ) && is_string( SENTINELA_SECRET ) && is_string( SENTINELA_ENDPOINT )
			&& strlen( SENTINELA_SECRET ) >= 32;
	}

	public static function enviar() {
		if ( ! self::configurado() ) {
			return;
		}
		$relatorio = Sentinela_Coletor::coletar();
		$r         = Sentinela_Envio::enviar( SENTINELA_ENDPOINT, SENTINELA_SITE_ID, SENTINELA_SECRET, $relatorio );
		update_option(
			self::OPCAO_STATUS,
			array(
				'em'     => time(),
				'status' => $r,
			),
			false
		);
	}

	/** Aviso só para quem administra, só no painel do WP. Nunca mostra o segredo. */
	public static function aviso() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! self::configurado() ) {
			echo '<div class="notice notice-warning"><p><strong>Sentinela Agent:</strong> defina SENTINELA_SITE_ID, SENTINELA_SECRET e SENTINELA_ENDPOINT no wp-config.php.</p></div>';
			return;
		}
		$st = get_option( self::OPCAO_STATUS );
		if ( is_array( $st ) && isset( $st['status'] ) && 204 !== $st['status'] ) {
			printf(
				'<div class="notice notice-error"><p><strong>Sentinela Agent:</strong> último envio falhou (%s) em %s.</p></div>',
				esc_html( (string) $st['status'] ),
				esc_html( wp_date( 'd/m/Y H:i', (int) $st['em'] ) )
			);
		}
	}

	public static function desativar() {
		wp_clear_scheduled_hook( self::EVENTO );
		wp_clear_scheduled_hook( self::EVENTO_RAPIDO );
	}
}

register_deactivation_hook( __FILE__, array( 'Sentinela_Agent', 'desativar' ) );
Sentinela_Agent::iniciar();
Divullg_Atualizador_1::registrar( 'sentinela-agent', __FILE__ );
