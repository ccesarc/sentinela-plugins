<?php
/**
 * Envio assinado para o Sentinela (docs/AGENTE-WP.md).
 *
 *   X-Sentinela-Signature = hex( HMAC-SHA256( segredo, site \n ts \n nonce \n sha256hex(corpo) ) )
 *
 * A resposta do painel é IGNORADA além do código HTTP: o agente nunca executa
 * nada que venha de lá.
 */

defined( 'ABSPATH' ) || exit;

final class Sentinela_Envio {

	/** @return int|string código HTTP ou motivo da falha */
	public static function enviar( $endpoint, $site_id, $segredo, array $relatorio ) {
		$permitir_http = defined( 'SENTINELA_PERMITIR_HTTP' ) && true === SENTINELA_PERMITIR_HTTP; // só dev local
		$esquema       = wp_parse_url( $endpoint, PHP_URL_SCHEME );
		if ( 'https' !== $esquema && ! ( $permitir_http && 'http' === $esquema ) ) {
			return 'endpoint-sem-https';
		}

		$corpo = wp_json_encode( $relatorio, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( false === $corpo ) {
			return 'json';
		}
		$ts         = (string) time();
		$nonce      = bin2hex( random_bytes( 16 ) );
		$assinatura = hash_hmac( 'sha256', $site_id . "\n" . $ts . "\n" . $nonce . "\n" . hash( 'sha256', $corpo ), $segredo );

		$r = wp_remote_post(
			$endpoint,
			array(
				'timeout'     => 15,
				'redirection' => 0,
				'sslverify'   => true,
				'user-agent'  => 'Sentinela-Agent/' . SENTINELA_AGENT_VERSION,
				'headers'     => array(
					'Content-Type'          => 'application/json',
					'X-Sentinela-Site'      => $site_id,
					'X-Sentinela-Timestamp' => $ts,
					'X-Sentinela-Nonce'     => $nonce,
					'X-Sentinela-Signature' => $assinatura,
				),
				'body'        => $corpo,
			)
		);
		if ( is_wp_error( $r ) ) {
			return 'rede';
		}
		return (int) wp_remote_retrieve_response_code( $r );
	}
}
