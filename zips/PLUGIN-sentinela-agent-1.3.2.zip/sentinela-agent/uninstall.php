<?php
/**
 * Remoção do plugin: apaga o que ele guardou (só o status do último envio).
 * Os segredos ficam no wp-config.php — apague as linhas SENTINELA_* à mão.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'sentinela_agent_status' );
wp_clear_scheduled_hook( 'sentinela_agent_enviar' );
wp_clear_scheduled_hook( 'sentinela_agent_enviar_logo' );
