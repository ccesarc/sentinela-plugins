# Blindagem — Segurança (v1.3.11)

Plugin genérico de endurecimento e vigilância para qualquer WordPress. Tudo em
**Configurações → Blindagem**, cada proteção com seu interruptor.

Não esconde que o site é WordPress, não troca a URL de login e não cria
mu-plugin: aparece na lista de plugins como qualquer outro.

## Instalar em outro site

Zipe a pasta `blindagem/` → Plugins → Adicionar novo → Enviar plugin → Ativar.
Depois abra **Configurações → Blindagem → Diagnóstico**.

## O que faz

| Aba | Proteção | Padrão |
|---|---|---|
| Login | Limite de tentativas por IP (bloqueia até a senha certa), progressivo: 2× as tentativas = 4× o tempo, 4× = 16× (máx. 24 h) | ligado, 5 → 15 min |
| | Código por e-mail para administradores (2FA) | **desligado** — ligue só depois do e-mail de teste chegar |
| | Senha forte (12+ caracteres, letras e números) | ligado |
| | Limite do "esqueci a senha" (3/hora por IP) | ligado |
| | Sessão curta (12 h; 7 dias com "lembrar") | ligado |
| | Senhas de aplicativo desligadas | ligado |
| | Registro dos últimos 200 acessos, com IP e navegador | ligado |
| | Aba **Sessões**: onde cada conta está logada (navegador, IP, desde quando); encerrar uma ou todas | — |
| Portas | XML-RPC desligado | ligado |
| | Lista de usuários escondida (REST, `?author=`, oEmbed) | ligado |
| | API REST só para logados | desligado (quebra formulários) |
| | Cadastro fechado | ligado |
| | Comentários desligados (formulário + POST direto) | ligado |
| | Anti-spam quando os comentários estão abertos: campo-isca, tempo mínimo de 3 s, no máximo 2 links, 5 por IP a cada 10 min | ligado |
| | Upload: lista branca, `foto.php.jpg` recusado, SVG sem script, `.htaccess` em uploads | ligado |
| Servidor | Cabeçalhos de segurança + HSTS (em HTTPS) | ligado |
| | Meta generator removido (WP e plugins) | ligado |
| | Editor de arquivos do painel | sempre desligado |
| | Atualização automática (menos versão maior do core) | ligado |
| Vigilância | Alerta de novo administrador | ligado |
| | Varredura diária: PHP em uploads, compactado aleatório, mu-plugin, drop-in | ligado |
| | Busca de código de backdoor (temas, uploads, plugins fora do wordpress.org) | ligado |
| | Integridade semanal: core e plugins × wordpress.org, arquivo por arquivo | ligado |
| | **Foto** diária dos temas, mu-plugins, drop-ins e plugins sem original oficial: arquivo novo, alterado ou apagado. Update pelo painel refaz a foto da pasta | ligado |
| | Diagnóstico diário: e-mail quando surge problema GRAVE/ATENÇÃO novo | ligado |
| | Script suspeito no banco (posts, páginas, opções): domínio desconhecido ou código ofuscado | ligado |
| | Tarefa agendada suspeita: nome aleatório, código nos argumentos, código em uploads/ ou criado por eval | ligado |
| | Registro de eventos: plugin/tema instalado, ativado, apagado; usuário criado/apagado; papel e e-mail alterados | ligado |
| | Alerta na hora quando muda opção crítica (siteurl, home, e-mail do admin, cadastro aberto, função padrão) | ligado |
| | Função padrão "administrador" recusada | ligado |
| | **Admin só pelo painel**: quem vira administrador sem ser promovido por outro admin numa tela de Usuários (ou WP-CLI) vira assinante, com e-mail | ligado |
| | **mu-plugins/ a cada 5 min**: e-mail quando aparece ou muda arquivo ali | ligado |
| | **Quarentena automática** das assinaturas exatas do vírus bright-backup-dot (mu-plugin, pastas falsas, `.gk_`/`.rd_`…, `<hex8>.zip`), com e-mail | ligado |
| | **Quarentena se limpa**: apaga de vez depois de 30 dias (7 o que entrou sozinho) | ligado |
| | **Atualização pelo botão do wp-admin**: o site busca a versão nova no GitHub (`ccesarc/sentinela-plugins`) e só instala zip com a assinatura da agência; sem automático | sempre |

A aba **Diagnóstico** aponta o que o plugin não resolve sozinho: HTTPS,
debug ligado, usuário "admin", papel padrão, salts, permissão do wp-config,
atualizações pendentes, plugins parados, versão do PHP.

A aba **Agendamentos** lista as tarefas do WP-Cron (próxima execução, repetição,
plugin dono, órfãs, atrasadas). As do WordPress ficam protegidas. As de plugin
ou tema podem ser **pausadas**: o plugin fica impedido de reagendar (filtro
`schedule_event`) até alguém clicar em Retomar. Órfã (sem ninguém ligado) pode
ser removida. Nas da Blindagem: rodar agora e recriar o agendamento.

## O que fazer com um achado

Cada linha da aba **Verificação** mostra o **Por quê** (regra que pegou, linha e trecho do código; tamanho e data do arquivo; domínio do script) e tem botões:

| Achado | Botão | O que acontece |
|---|---|---|
| Arquivo que não deveria existir (PHP em uploads, zip estranho, backdoor, mu-plugin, arquivo a mais) | **Pôr em quarentena** | Sai do lugar para `blindagem-quarentena-<aleatório>/` **fora da pasta pública** (um nível acima do WordPress, ex.: a home da hospedagem) — sem permissão lá, em `wp-content/` com `.htaccess` negando acesso. Renomeado sem extensão executável. Não roda mais. Na lista da quarentena: **Restaurar** (alarme falso) ou **Apagar de vez** |
| Arquivo de plugin do wordpress.org alterado | **Reinstalar plugin do original** | Baixa do wordpress.org (versão mais nova) por cima e roda a integridade de novo |
| Arquivo do WordPress alterado | **Reinstalar o WordPress** | Leva a Painel → Atualizações → "Reinstalar" |
| Script no banco | **Abrir para limpar** | Abre o post no editor (opção: limpar com quem conhece o plugin dono) |
| Tarefa agendada suspeita | **Ver em Agendamentos** | Pausar ou remover a tarefa |
| Arquivo novo em tema/plugin sem original (foto) | **Pôr em quarentena** | Como acima |
| Arquivo alterado/apagado em tema/plugin sem original | — | Foi você ou uma atualização: **Reconhecer**. Senão, reinstale do zip original |
| Qualquer um | **Reconhecer** | Só aquele item sai da lista (volta se mudar de novo). "Reconhecer todos" continua existindo, com aviso |

A quarentena só move arquivo que está no relatório da última verificação e que
não mudou desde então (hash) — o botão nunca escolhe um caminho qualquer do
servidor. `wp-config.php`, arquivos de carga do WordPress e a própria Blindagem
são recusados.

**Site que pode já estar infectado:** não use "Reconhecer todos" na primeira
verificação — some da lista e dos alertas. Confira um por um. Rode também a
varredura do Wordfence (assinaturas) ou do painel da hospedagem, e confira os
**Cron Jobs do painel da hospedagem**, que a Blindagem não enxerga.

## Arquivos legítimos conhecidos (vistos em site real)

Primeira verificação num site da Hostinger com Wordfence (06/10/2026) — estes aparecem na lista e são
**normais**. Reconheça (depois de olhar), não ponha em quarentena:

| Achado | De quem | Atenção |
|---|---|---|
| `mu-plugins/hostinger-auto-updates.php` | Hostinger — atualizações pelos servidores dela (`*.hostinger.io`) | Desliga as atualizações automáticas do WordPress: deixe "Atualização automática" da Blindagem **desligada** |
| `mu-plugins/hostinger-preview-domain.php` | Hostinger — domínio temporário de pré-visualização | Só age com o cabeçalho `X-Preview-Indicator` do painel |
| `wordfence-waf.php` (raiz) | Wordfence — firewall, carregado antes de tudo (`auto_prepend_file`) | ⚠️ **Nunca** em quarentena: o site inteiro cai |
| `default.php` (raiz) | Hostinger — página "Está tudo pronto!" anterior ao WordPress | HTML puro; pode apagar |
| `advanced-cache.php`, `object-cache.php` (wp-content) | Drop-ins de cache (LiteSpeed etc.) | Reconheça |
| `~/.private/config.json` (fora do site, não aparece) | Hostinger — endereços de atualização dos plugins dela | Não apagar |

**Suspeito de verdade** no mesmo site: `wp-content/4111357d.php` e `5bba92b5.php` (PHP de nome
aleatório solto em wp-content) e uma tarefa cron de nome aleatório sem dono. Arquivo assim é para
**quarentena** (guarda a prova) — apagar direto perde a chance de ver o que era.

Com Wordfence junto: um só limitador de login (desligue um dos dois). A varredura dele (assinaturas)
complementa a da Blindagem.

## Levar para outro site

Aba Proteções → **Levar estas configurações para outro site**: copie o bloco e
cole em **Importar** no outro site. O e-mail de alerta não vai junto.

## Testado como — sabotando

| Trava | Prova |
|---|---|
| `?author=1`, `/wp-json/wp/v2/users`, generator, comentários | Ligado: 302 para home, 404, 0 generator, 403. **Desligado: vazou `/author/caio/`, 200, 2 generator, 200.** |
| Limite de login | 5 erros → a senha certa foi recusada ("Acesso bloqueado") |
| Upload | `foto.php.jpg`, `shell.phar`, `x.pHtMl`, `.htaccess`, SVG com script recusados; `foto.jpg`, `doc.pdf`, SVG limpo passaram |
| Varredura | Iscas (PHP em uploads, `ef04646d.zip`, mu-plugin, `eval(base64_decode(` no tema): 4 de 4. Sem iscas: 0 |
| Varredura 1.2 | Iscas: PHP em uploads, `ef04646d.zip`, `eval(base64_decode($_POST…` num tema, `<script src=evil-cdn>` num post, `eval(atob(` numa opção, tarefa `a1b2c3d4e5f6a7b8` com base64 nos argumentos: 6 de 6. Post com Google Tag Manager: não acusado |
| Quarentena | Mover/restaurar/apagar ok. Pedido para mover `wp-config.php` e `../../wp-config.php`: recusado. Arquivo alterado depois da verificação: recusado |
| 2FA 1.2 | Login de admin por `wp_signon()` fora do wp-login (como formulário de tema/WooCommerce): barrado. Antes da 1.2 entrava só com a senha |
| IP atrás de proxy | `X-Forwarded-For: 6.6.6.6, 200.1.2.3` → 200.1.2.3 (antes: 6.6.6.6, forjável) |
| SVG | `&#106;avascript:`, entidade sem `;`, tab no meio de `javascript:`, `data:text/html`, `onload`: recusados. SVG limpo e logo com PNG embutido: aceitos |
| Evidência 1.3 | Backdoor `eval(base64_decode($_POST…` num tema: "executa texto escondido — linha 3: eval(base64_decode(…" |
| Foto 1.3 | Tema isca: functions.php alterado, novo.php criado, apagar.js removido → 3 de 3, com tamanho antes/depois. "Update" do tema pelo painel → foto refeita, alertas de foto somem e o backdoor **continua** acusado pela regra de código |
| Reconhecer 1.3 | Reconhecer novo.php: some; muda de novo: volta. Reconhecer `wp-config.php` (fora do relatório): recusado |
| Quarentena 1.3 | Gravada em `/var/www/blindagem-quarentena-…` (fora da pasta do site) |
| Sessões 1.3 | Chrome·Windows e Safari·iPhone listados; encerrar uma → some; encerrar todas → 0 |
| Login 1.3 | 5 erros → 15 min, 10 → 60 min, 20 → 240 min. Login errado via Firefox/Windows registrado com o navegador |
| Anti-spam | Sem campos, rápido demais, isca preenchida, 3 links, hash forjado: 403. Humano depois de 3 s: aceito (em moderação) |
| Função padrão | `update_option('default_role','administrator')` → continua `subscriber` + evento BLOQUEADO |
| Integridade | `load.php` alterado, arquivo novo em `wp-includes`, `elementor.php` alterado, PHP novo no Elementor: 4 de 4. Restaurado: 0 |

## Precisa de e-mail funcionando

Alertas e 2FA saem por `wp_mail`. Sem SMTP configurado na hospedagem, nada
chega — o aviso no painel continua aparecendo. Use o botão **Mandar e-mail de
teste** na aba Proteções.

## Servidor

- **Apache/LiteSpeed:** o plugin escreve a regra de `uploads/.htaccess` sozinho.
- **nginx:** coloque na config do site:
  `location ~* /wp-content/uploads/.*\.php$ { deny all; }`
- `readme.html` e `license.txt` mostram a versão: desde a 1.4.2 a Blindagem apaga sozinha (opção "Apagar readme.html
  e license.txt", ligada por padrão) — ao ativar, depois de cada atualização do core, ao abrir o painel e na
  varredura diária. Não apaga em `WP_ENVIRONMENT_TYPE = local`.
- WP-Cron depende de visita. Em produção: cron real a cada 15 min e
  `define( 'DISABLE_WP_CRON', true );`

## Trancou-se fora?

No `wp-config.php`: `define( 'BLINDAGEM_MODO_SEGURO', true );` — desliga limite
de login e 2FA. Ou apague a pasta do plugin: o WordPress o desativa sozinho.

## Versões

A fonte oficial fica no repositório do Sentinela (`agents/wordpress/blindagem/`, desde a 1.3.7);
as cópias nos repositórios dos sites são antigas. Zip: `./scripts/empacotar-agente.sh blindagem`.

- **1.4.2** (2026-10-22) — Apaga `readme.html` e `license.txt` da raiz (mostram a versão exata do WordPress e voltam
  a cada atualização): ao ativar, depois de cada atualização do core (`_core_updated_successfully` e o upgrader),
  ao abrir o painel (zip enviado por cima não roda a ativação) e na varredura diária (a Hostinger atualiza por fora
  do upgrader). Opção em Proteções → Servidor, ligada por padrão; evento no registro; Diagnóstico avisa se faltar
  permissão. Nada é apagado em ambiente `local`. Pedido do dono depois da Shantih (22/10).
- **1.4.1** (2026-10-21) — Chave pública da agência gravada no atualizador: a partir desta versão,
  atualização pelo botão do wp-admin (zip assinado em `ccesarc/sentinela-plugins`). Instalar à mão uma vez.
- **1.4.0** (2026-10-21) — Lições do surto bright-backup-dot (docs/INCIDENTES.md do Sentinela): admin
  criado fora do painel vira assinante; mu-plugins conferido a cada 5 min; quarentena automática das
  assinaturas exatas do vírus (lista em `inc/vigia.php`, cópia de `indicadores.ts`) e limpeza da
  quarentena (30/7 dias); `index.php` de 404 do WPForms e `default.php` da Hostinger não são mais
  achados; atualização pelo botão do wp-admin com pacote assinado (`inc/atualizador.php`).

- **1.3.11** (2026-10-20) — **Pasta falsa em plugins/** (casca: vazia ou com marcadores como
  `bright-backup-dot/.pv_…`) vai para a quarentena inteira — botão "Pôr pasta em quarentena" e lote;
  só pasta direto em plugins/, sem plugin dentro, que não mudou desde a verificação e pequena (até 50
  arquivos / 1 MB). Os arquivos de dentro ganham `.quarentena` no nome (nada roda); restaurar desfaz;
  "Apagar de vez" apaga a pasta. Quarentena fora da pasta pública em outro disco: mover/restaurar
  copia e apaga (antes o restaurar de arquivo falhava nesse caso). Mensagem de "não vai para a
  quarentena" corrigida (dizia que derrubaria o site).
- **1.3.10** (2026-10-20) — "Verificar agora" roda a integridade antes da varredura (a lista de plugins
  sem original, usada pela foto, fica em dia); plugin que acabou de entrar na foto vira uma linha só a
  partir de 2 arquivos (no Dau, os 4 arquivos do agente apareciam como NOVO soltos).
- **1.3.9** (2026-10-20) — Arquivo **escondido** (nome com ponto na frente) no 1º nível de wp-content,
  plugins, mu-plugins, themes e uploads vira achado (pode ir para a quarentena). Restos do malware do
  Perfil Portas passavam: `.4111357d.php` (o `*.php` não vê arquivo com ponto), marcadores vazios
  `.gk_…`/`.kk_…`/`.sc_…`/`.rd_<plugin falso>` e carga em `.wp-object-cache-<hex>.dat(.lkg)`.
  Ignorados: `.htaccess`, `.user.ini`, `.litespeed_conf.dat`, `.DS_Store`, `.gitignore`, `.gitkeep`.
- **1.3.8** (2026-10-20) — Plugin que deixa de ser fotografado com a pasta no lugar (ganhou original
  no wordpress.org, como versão nova do Elementor dias depois; ou lista de plugins velha logo após
  reenviar um zip) sai da foto calado, em vez de virar "apagado" (2693 linhas do Elementor na Onix).
- **1.3.7** (2026-10-20) — Tema/plugin instalado ou atualizado por fora do painel (zip enviado por
  cima, Hostinger Smart Auto Updates, FTP) virava uma linha por arquivo (200 no Perfil Portas): agora
  pasta com 5+ arquivos limpos novos/alterados/apagados vira **um achado** ("Tema/plugin inteiro");
  arquivo com código suspeito sempre sai sozinho, e reconhecer a pasta não aceita esse arquivo.
- **1.3.1–1.3.6** (2026-10-15) — nomes de webshell partidos no código (não acusa a si mesma); raiz,
  uploads, `.htaccess`/`.user.ini` e nome de arquivo inválido; ações em lote e "Marcar só";
  "PHP em imagem" sem falso alarme de PNG; quarentena atualiza a foto; casca de plugin, plugin
  escondido e plugin fora do wordpress.org na integridade.
- **1.3.0** — Ideias de uma especificação de plugin de segurança avaliadas contra o que já existia:
  evidência em todo achado (regra, linha e trecho; "Por quê" no painel e no e-mail); **foto** de
  temas/mu-plugins/plugins sem original oficial (novo/alterado/apagado), refeita sozinha em update
  pelo painel; **Reconhecer** item por item; aba **Sessões** (ver e encerrar); bloqueio de login
  progressivo; navegador no registro de acessos; quarentena fora da pasta pública quando possível.
- **1.2.1** — Só documentação: arquivos legítimos conhecidos (Hostinger, Wordfence, cache) vistos na
  primeira verificação de um site real.
- **1.2.0** — Corrige: 2FA valia só no wp-login.php (outro formulário de
  login entrava só com a senha); atrás de proxy o IP vinha do 1º item do
  X-Forwarded-For (forjável, furava o limite de login); SVG com script
  disfarçado por entidade/tab passava. Novo: quarentena com restaurar/apagar,
  reinstalar plugin alterado, varredura do banco e das tarefas agendadas,
  registro de eventos, alerta de opção crítica, trava da função padrão
  "administrador", anti-spam de comentários, exportar/importar configurações,
  aviso de outro plugin de segurança e do cron da hospedagem no diagnóstico.

- **1.1.0** — aba Agendamentos (tarefas do WP-Cron, pausar de plugin/tema,
  remover órfã); Diagnóstico mostra toda checagem com status e alerta por
  e-mail problema novo todo dia; placeholder do e-mail de alerta genérico.
- **1.0.0** — primeira versão.

## Não é antimalware

Não tem base de assinaturas e não limpa nada: **previne e avisa**. Plugin
pago/próprio não tem checksum oficial — passa só pela busca de código suspeito.
Site já invadido: limpe primeiro, depois `wp config shuffle-salts`.
Firewall de verdade (WAF): Wordfence Free, **um só** plugin externo de segurança.
