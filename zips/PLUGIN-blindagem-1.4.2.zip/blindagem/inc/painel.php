<?php
/**
 * Tela Configurações → Blindagem: proteções, relatório de verificação,
 * registro de acessos, agendamentos e diagnóstico.
 */

defined( 'ABSPATH' ) || exit;

/** Rótulo e explicação de cada interruptor, na ordem da tela. */
function blindagem_campos() {
	return array(
		'Login' => array(
			'limite_login'    => array( 'Limitar tentativas de login', 'Erros seguidos do mesmo IP bloqueiam o login — inclusive com a senha certa. Quem insiste fica bloqueado mais tempo: o dobro de tentativas = 4× o tempo; 4× as tentativas = 16× (no máximo 24 h).' ),
			'dois_fatores'    => array( 'Código por e-mail para administradores (2FA)', '⚠️ Ligue só depois que o "E-mail de teste" abaixo chegar. Sem e-mail funcionando, tranca todo admin do lado de fora.' ),
			'senha_forte'     => array( 'Exigir senha forte', 'Mínimo de 12 caracteres, com letras e números.' ),
			'limite_senha'    => array( 'Limitar "esqueci a senha"', 'Três pedidos por hora por IP.' ),
			'sessao_curta'    => array( 'Sessão mais curta', '12 horas; 7 dias com "lembrar de mim" (o padrão é 14).' ),
			'app_passwords'   => array( 'Desligar senhas de aplicativo', 'Religue se usar app móvel ou integração externa pela API.' ),
			'registro_acesso' => array( 'Registrar acessos', 'Guarda os últimos 200 logins (certos, errados e bloqueados).' ),
			'atras_de_proxy'  => array( 'Site atrás de CDN/proxy (Cloudflare etc.)', 'Lê o IP real do cabeçalho do CDN. Ligue SÓ se houver CDN: sem ele, o cabeçalho é forjável.' ),
		),
		'Portas de entrada' => array(
			'xmlrpc_off'      => array( 'Desligar XML-RPC', 'Usado para força bruta em massa. Só o app móvel antigo e o Jetpack precisam dele.' ),
			'enumeracao'      => array( 'Esconder a lista de usuários', 'Fecha /wp-json/wp/v2/users e ?author=1. Desligue se o site tiver páginas de autor.' ),
			'rest_privada'    => array( 'API REST só para usuários logados', 'Mais fechado, mas formulários e alguns construtores usam a API. Ligue e teste o site.' ),
			'registro_off'    => array( 'Fechar o cadastro de usuários', 'Ninguém se cadastra sozinho, mesmo que alguém ligue a opção no painel.' ),
			'comentarios_off' => array( 'Desligar comentários', 'Fecha o formulário e o POST direto no wp-comments-post.php. Desmarque se o site tiver blog com comentários.' ),
			'comentarios_antispam' => array( 'Anti-spam nos comentários', 'Vale quando os comentários estão abertos: campo-isca invisível, tempo mínimo, no máximo 2 links e 5 comentários por IP a cada 10 minutos. Sem captcha.' ),
			'upload_restrito' => array( 'Restringir upload', 'Só imagem, PDF, documento de escritório, áudio e vídeo; recusa foto.php.jpg; SVG só de admin e sem script; bloqueia PHP em uploads/.' ),
		),
		'Servidor' => array(
			'cabecalhos'      => array( 'Cabeçalhos de segurança', 'nosniff, X-Frame-Options, Referrer-Policy, Permissions-Policy.' ),
			'hsts'            => array( 'HSTS (só em HTTPS)', 'Obriga o navegador a usar HTTPS por um ano.' ),
			'esconder_versao' => array( 'Esconder versões', 'Tira o meta generator do WordPress e dos plugins.' ),
			'apagar_readme'   => array( 'Apagar readme.html e license.txt', 'Os dois mostram a versão exata do WordPress e voltam a cada atualização: apaga ao ativar, depois de cada atualização do core, ao abrir o painel e na varredura diária.' ),
			'autoupdate'      => array( 'Atualização automática', 'Plugins, temas e versões menores do core. Versão maior do core, não.' ),
		),
		'Vigilância' => array(
			'alerta_admin'    => array( 'Alertar novo administrador', 'E-mail quando qualquer usuário vira administrador.' ),
			'trava_admin'     => array( 'Admin só pelo painel', 'Usuário que vira administrador sem ser promovido por outro admin numa tela de Usuários (ou WP-CLI) vira assinante na hora, com e-mail. Plugin de migração que cria admin: desligue durante a migração.' ),
			'vigia_mu'        => array( 'Vigiar mu-plugins a cada 5 minutos', 'E-mail quando aparece ou muda um arquivo em mu-plugins/ (onde o vírus de 2026-10 morava).' ),
			'quarentena_auto' => array( 'Quarentena automática do vírus conhecido', 'Assinaturas exatas do vírus bright-backup-dot (mu-plugin, pastas falsas, marcadores .gk_/.rd_…) vão sozinhas para a quarentena, com e-mail. Dá para restaurar.' ),
			'quarentena_expira' => array( 'Limpar a quarentena sozinho', 'Apaga de vez o que está na quarentena há mais de 30 dias (7 dias o que entrou pela quarentena automática).' ),
			'registro_eventos'   => array( 'Registrar eventos', 'Plugin instalado/ativado/apagado, tema trocado, usuário criado/apagado, papel ou e-mail alterado, opção crítica alterada. Últimos 300, na aba Eventos.' ),
			'alerta_opcoes'      => array( 'Alertar mudança em opção crítica', 'E-mail na hora quando mudam o endereço do site, o e-mail do admin, o cadastro aberto ou a função padrão — o rastro típico de plugin vulnerável explorado.' ),
			'trava_papel_padrao' => array( 'Recusar "administrador" como função padrão', 'Ninguém precisa que todo usuário novo nasça admin; é como invasores criam a própria conta.' ),
			'varredura'       => array( 'Varredura diária', 'PHP em uploads/, compactado de nome aleatório, mu-plugins e drop-ins.' ),
			'codigo_suspeito' => array( 'Procurar código de backdoor', 'Em temas, uploads, mu-plugins e plugins que não são do wordpress.org.' ),
			'integridade'     => array( 'Integridade semanal', 'Compara o core e os plugins do wordpress.org, arquivo por arquivo, com o oficial.' ),
			'foto'            => array( 'Foto dos temas e plugins sem original', 'Guarda o "retrato" (hash) de cada arquivo de temas, mu-plugins e plugins pagos/próprios; na varredura diária aponta arquivo novo, alterado ou apagado. Atualização pelo painel refaz a foto sozinha.' ),
			'alerta_diagnostico' => array( 'Alertar problema novo no diagnóstico', 'Todo dia confere a aba Diagnóstico e manda e-mail quando surge item GRAVE ou ATENÇÃO que não estava lá.' ),
		),
	);
}

add_action( 'admin_menu', function () {
	add_options_page( 'Blindagem', 'Blindagem', 'manage_options', 'blindagem', 'blindagem_tela' );
} );

add_filter( 'plugin_action_links_' . plugin_basename( BLINDAGEM_ARQUIVO ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=blindagem' ) ) . '">Configurações</a>' );
	return $links;
} );

add_action( 'admin_init', function () {
	register_setting( 'blindagem', 'blindagem_opcoes', array(
		'type'              => 'array',
		'sanitize_callback' => 'blindagem_sanitizar',
	) );
} );

function blindagem_sanitizar( $entrada ) {
	$entrada = is_array( $entrada ) ? $entrada : array();
	$saida   = array();

	foreach ( array_keys( blindagem_padroes_seguranca() ) as $chave ) {
		$saida[ $chave ] = empty( $entrada[ $chave ] ) ? 0 : 1;
	}

	$saida['tentativas']   = min( 50, max( 1, absint( $entrada['tentativas'] ?? 5 ) ) );
	$saida['minutos']      = min( 1440, max( 1, absint( $entrada['minutos'] ?? 15 ) ) );
	$saida['email_alerta'] = sanitize_email( $entrada['email_alerta'] ?? '' );

	return $saida;
}

/** Liga/desliga a regra do uploads/.htaccess junto com a opção. */
add_action( 'update_option_blindagem_opcoes', function ( $antigo, $novo ) {
	blindagem_htaccess_uploads( ! empty( $novo['upload_restrito'] ) );
}, 10, 2 );


/* ==========================================================================
   Ações dos botões (admin-post.php)
   ========================================================================== */

function blindagem_voltar( $aba, $aviso ) {
	wp_safe_redirect( add_query_arg( array( 'page' => 'blindagem', 'aba' => $aba, 'aviso' => $aviso ), admin_url( 'options-general.php' ) ) );
	exit;
}

function blindagem_conferir_permissao( $acao ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Sem permissão.', 403 );
	}
	check_admin_referer( $acao );
}

add_action( 'admin_post_blindagem_verificar', function () {
	blindagem_conferir_permissao( 'blindagem_verificar' );
	// Integridade primeiro: ela renova a lista de plugins sem original no wordpress.org, que a foto da varredura usa
	// (na ordem inversa, plugin recém-enviado aparecia como arquivos NOVO soltos — visto no Dau).
	blindagem_rodar( 'integridade' );
	blindagem_rodar( 'varredura' );
	blindagem_voltar( 'verificacao', 'verificado' );
} );

add_action( 'admin_post_blindagem_reconhecer', function () {
	blindagem_conferir_permissao( 'blindagem_reconhecer' );

	$conhecidos = get_option( 'blindagem_reconhecidos', array() );
	$conhecidos = is_array( $conhecidos ) ? $conhecidos : array();

	foreach ( array( 'varredura', 'integridade' ) as $qual ) {
		$relatorio = get_option( 'blindagem_rel_' . $qual );
		if ( ! is_array( $relatorio ) ) {
			continue;
		}
		foreach ( $relatorio['achados'] as $achado ) {
			$conhecidos[ $achado['arquivo'] ] = $achado['hash'];
		}
		$relatorio['achados'] = array();
		update_option( 'blindagem_rel_' . $qual, $relatorio, false );
		update_option( 'blindagem_alertado_' . $qual, '', false );
	}

	update_option( 'blindagem_reconhecidos', $conhecidos, false );
	blindagem_voltar( 'verificacao', 'reconhecido' );
} );

add_action( 'admin_post_blindagem_esquecer', function () {
	blindagem_conferir_permissao( 'blindagem_esquecer' );
	delete_option( 'blindagem_reconhecidos' );
	blindagem_voltar( 'verificacao', 'esquecido' );
} );

add_action( 'admin_post_blindagem_email_teste', function () {
	blindagem_conferir_permissao( 'blindagem_email_teste' );

	$ok = wp_mail(
		wp_get_current_user()->user_email,
		sprintf( '[%s] E-mail de teste da Blindagem', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
		"Se você recebeu isto, o site consegue mandar e-mail: os alertas e o código de acesso (2FA) vão chegar.\n"
	);

	blindagem_voltar( 'protecoes', $ok ? 'email_ok' : 'email_falhou' );
} );

add_action( 'admin_post_blindagem_limpar_eventos', function () {
	blindagem_conferir_permissao( 'blindagem_limpar_eventos' );
	delete_option( 'blindagem_eventos' );
	blindagem_voltar( 'eventos', 'eventos_limpos' );
} );

/*
 * Importar configurações de outro site: o mesmo caminho do formulário
 * (blindagem_sanitizar), então só entram chaves conhecidas com valor válido.
 * O e-mail de alerta NÃO vem junto: é de cada site.
 */
add_action( 'admin_post_blindagem_importar', function () {
	blindagem_conferir_permissao( 'blindagem_importar' );

	$texto = isset( $_POST['configuracoes'] ) ? wp_unslash( $_POST['configuracoes'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- JSON, sanitizado abaixo por blindagem_sanitizar().
	$dados = json_decode( (string) $texto, true );

	if ( ! is_array( $dados ) || empty( $dados['blindagem'] ) || ! is_array( $dados['blindagem'] ) ) {
		blindagem_voltar( 'protecoes', 'importar_erro' );
	}

	$entrada                 = $dados['blindagem'];
	$entrada['email_alerta'] = blindagem_opcao( 'email_alerta' );
	update_option( 'blindagem_opcoes', blindagem_sanitizar( $entrada ) );
	blindagem_voltar( 'protecoes', 'importado' );
} );

add_action( 'admin_post_blindagem_limpar_acessos', function () {
	blindagem_conferir_permissao( 'blindagem_limpar_acessos' );
	delete_option( 'blindagem_acessos' );
	blindagem_voltar( 'acessos', 'limpo' );
} );

foreach ( array( 'varredura', 'integridade' ) as $blindagem_qual ) {
	add_action( 'admin_post_blindagem_rodar_' . $blindagem_qual, function () use ( $blindagem_qual ) {
		blindagem_conferir_permissao( 'blindagem_rodar_' . $blindagem_qual );
		blindagem_rodar( $blindagem_qual );
		blindagem_voltar( 'agenda', 'rodado' );
	} );
}

add_action( 'admin_post_blindagem_reagendar', function () {
	blindagem_conferir_permissao( 'blindagem_reagendar' );
	wp_clear_scheduled_hook( 'blindagem_varredura' );
	wp_clear_scheduled_hook( 'blindagem_integridade' );
	blindagem_agendar();
	blindagem_voltar( 'agenda', 'reagendado' );
} );

/** Hook de tarefa vindo do formulário, só se existir no cron ou na lista de pausadas. */
function blindagem_hook_do_post() {
	return blindagem_hook_valido( isset( $_POST['hook'] ) ? sanitize_text_field( wp_unslash( $_POST['hook'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification -- conferido antes.
}

/** O hook existe no cron ou na lista de pausadas? Devolve ele mesmo ou ''. */
function blindagem_hook_valido( $hook ) {
	$no_cron = false;
	foreach ( (array) _get_cron_array() as $hooks ) {
		$no_cron = $no_cron || isset( $hooks[ $hook ] );
	}
	return ( $no_cron || isset( blindagem_cron_pausadas()[ $hook ] ) ) ? $hook : '';
}

add_action( 'admin_post_blindagem_cron_pausar', function () {
	blindagem_conferir_permissao( 'blindagem_cron_pausar' );
	blindagem_voltar( 'agenda', blindagem_cron_pausar_hook( blindagem_hook_do_post() ) ? 'pausada' : 'protegida' );
} );

/** Pausa uma tarefa de plugin/tema (as do WordPress e da Blindagem são protegidas). */
function blindagem_cron_pausar_hook( $hook ) {
	if ( ! $hook || blindagem_cron_protegida( $hook, blindagem_origem_hook( $hook ) ) ) {
		return false;
	}

	// Guarda repetição e argumentos para o "Retomar" recriar igual.
	$guardados = array();
	foreach ( (array) _get_cron_array() as $hooks ) {
		foreach ( $hooks[ $hook ] ?? array() as $evento ) {
			$guardados[] = array( 'schedule' => $evento['schedule'], 'args' => $evento['args'] );
		}
	}

	$pausadas          = blindagem_cron_pausadas();
	$pausadas[ $hook ] = $guardados;
	update_option( 'blindagem_cron_pausadas', $pausadas, true );
	wp_unschedule_hook( $hook );
	return true;
}

add_action( 'admin_post_blindagem_cron_retomar', function () {
	blindagem_conferir_permissao( 'blindagem_cron_retomar' );
	$hook     = blindagem_hook_do_post();
	$pausadas = blindagem_cron_pausadas();
	if ( ! isset( $pausadas[ $hook ] ) ) {
		blindagem_voltar( 'agenda', 'protegida' );
	}

	$guardados = $pausadas[ $hook ];
	unset( $pausadas[ $hook ] );
	update_option( 'blindagem_cron_pausadas', $pausadas, true );

	// Só as repetitivas voltam; evento único que já passou não faz sentido recriar.
	$agendas = wp_get_schedules();
	foreach ( $guardados as $evento ) {
		if ( $evento['schedule'] && isset( $agendas[ $evento['schedule'] ] ) && ! wp_next_scheduled( $hook, $evento['args'] ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, $evento['schedule'], $hook, $evento['args'] );
		}
	}
	blindagem_voltar( 'agenda', 'retomada' );
} );

add_action( 'admin_post_blindagem_cron_remover', function () {
	blindagem_conferir_permissao( 'blindagem_cron_remover' );
	blindagem_voltar( 'agenda', blindagem_cron_remover_hook( blindagem_hook_do_post() ) ? 'removida' : 'protegida' );
} );

/** Remove uma tarefa ÓRFÃ (sem ninguém ligado: ninguém recria nem sente falta). */
function blindagem_cron_remover_hook( $hook ) {
	if ( ! $hook || '' !== blindagem_origem_hook( $hook ) || blindagem_cron_protegida( $hook, '' ) ) {
		return false;
	}
	wp_unschedule_hook( $hook );
	return true;
}

function blindagem_botao( $acao, $rotulo, $classe = 'button', $confirmar = '', $campos = array() ) {
	printf( '<form method="post" action="%s" style="display:inline-block;margin:0 .5em .5em 0">', esc_url( admin_url( 'admin-post.php' ) ) );
	printf( '<input type="hidden" name="action" value="%s">', esc_attr( $acao ) );
	foreach ( $campos as $nome => $valor ) {
		printf( '<input type="hidden" name="%s" value="%s">', esc_attr( $nome ), esc_attr( $valor ) );
	}
	wp_nonce_field( $acao );
	printf(
		'<button type="submit" class="%s"%s>%s</button></form>',
		esc_attr( $classe ),
		$confirmar ? ' onclick="return confirm(' . esc_attr( wp_json_encode( $confirmar ) ) . ')"' : '',
		esc_html( $rotulo )
	);
}



/* ==========================================================================
   A tela
   ========================================================================== */

function blindagem_tela() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$abas = array(
		'protecoes'   => 'Proteções',
		'verificacao' => 'Verificação',
		'acessos'     => 'Acessos',
		'eventos'     => 'Eventos',
		'sessoes'     => 'Sessões',
		'agenda'      => 'Agendamentos',
		'diagnostico' => 'Diagnóstico',
	);
	$aba = isset( $_GET['aba'] ) && isset( $abas[ $_GET['aba'] ] ) ? sanitize_key( $_GET['aba'] ) : 'protecoes'; // phpcs:ignore WordPress.Security.NonceVerification

	$avisos = array(
		'verificado'   => array( 'success', 'Verificação concluída.' ),
		'reconhecido'  => array( 'success', 'Achados reconhecidos. Só voltam a aparecer se o arquivo mudar.' ),
		'esquecido'    => array( 'success', 'Lista de reconhecidos apagada. A próxima verificação mostra tudo de novo.' ),
		'email_ok'     => array( 'success', 'E-mail enviado para você. Chegou? Então pode ligar o código por e-mail (2FA).' ),
		'email_falhou' => array( 'error', 'O site NÃO conseguiu mandar e-mail. Não ligue o 2FA; configure o SMTP antes.' ),
		'limpo'        => array( 'success', 'Registro de acessos apagado.' ),
		'eventos_limpos' => array( 'success', 'Registro de eventos apagado.' ),
		'quarentena_ok' => array( 'success', 'Arquivo posto em quarentena: não roda mais. Confira se o site continua funcionando.' ),
		'reconhecido_um' => array( 'success', 'Item reconhecido como legítimo. Só volta a aparecer se mudar de novo.' ),
		'sessao_encerrada' => array( 'success', 'Sessão encerrada.' ),
		'sessoes_encerradas' => array( 'success', 'Sessões encerradas.' ),
		'restaurado'    => array( 'success', 'Arquivo devolvido ao lugar original.' ),
		'apagado'       => array( 'success', 'Arquivo apagado de vez.' ),
		'reinstalado'   => array( 'success', 'Plugin reinstalado do wordpress.org e integridade conferida de novo.' ),
		'importado'    => array( 'success', 'Configurações importadas.' ),
		'importar_erro' => array( 'error', 'Não reconheci o texto colado. Copie de novo o bloco inteiro da tela "Exportar" do outro site.' ),
		'rodado'       => array( 'success', 'Rodou. Resultado na aba Verificação.' ),
		'reagendado'   => array( 'success', 'Agendamentos da Blindagem recriados.' ),
		'pausada'      => array( 'success', 'Tarefa pausada. O plugin fica impedido de reagendar até você retomar.' ),
		'retomada'     => array( 'success', 'Tarefa retomada: volta a rodar em 1 minuto (se o plugin não a recriar antes).' ),
		'removida'     => array( 'success', 'Tarefa órfã removida.' ),
		'protegida'    => array( 'error', 'Essa tarefa não pode ser parada por aqui.' ),
	);
	$aviso = isset( $_GET['aviso'] ) ? sanitize_key( $_GET['aviso'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="wrap">
		<h1>Blindagem — Segurança</h1>

		<?php
		$erro_acao = 'acao_erro' === $aviso ? get_transient( 'blindagem_erro_' . get_current_user_id() ) : '';
		if ( $erro_acao ) :
			delete_transient( 'blindagem_erro_' . get_current_user_id() );
			?>
			<div class="notice notice-error is-dismissible"><p><?php echo esc_html( $erro_acao ); ?></p></div>
		<?php endif; ?>

		<?php
		$lote = 'lote' === $aviso ? get_transient( 'blindagem_lote_' . get_current_user_id() ) : '';
		if ( is_array( $lote ) ) :
			delete_transient( 'blindagem_lote_' . get_current_user_id() );
			?>
			<div class="notice notice-<?php echo esc_attr( $lote[0] ); ?> is-dismissible"><p><?php echo esc_html( $lote[1] ); ?></p></div>
		<?php endif; ?>

		<?php if ( isset( $avisos[ $aviso ] ) ) : ?>
			<div class="notice notice-<?php echo esc_attr( $avisos[ $aviso ][0] ); ?> is-dismissible"><p><?php echo esc_html( $avisos[ $aviso ][1] ); ?></p></div>
		<?php endif; ?>

		<?php if ( defined( 'BLINDAGEM_MODO_SEGURO' ) && BLINDAGEM_MODO_SEGURO ) : ?>
			<div class="notice notice-warning"><p><strong>BLINDAGEM_MODO_SEGURO está ligado no wp-config.php:</strong> limite de login e 2FA desligados. Tire assim que recuperar o acesso.</p></div>
		<?php endif; ?>

		<nav class="nav-tab-wrapper">
			<?php foreach ( $abas as $chave => $rotulo ) : ?>
				<a class="nav-tab<?php echo $chave === $aba ? ' nav-tab-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'page' => 'blindagem', 'aba' => $chave ), admin_url( 'options-general.php' ) ) ); ?>"><?php echo esc_html( $rotulo ); ?></a>
			<?php endforeach; ?>
		</nav>

		<?php call_user_func( 'blindagem_aba_' . $aba ); ?>
	</div>
	<?php
}

function blindagem_aba_protecoes() {
	$opcoes = blindagem_opcoes();
	?>
	<form method="post" action="options.php">
		<?php settings_fields( 'blindagem' ); ?>

		<?php foreach ( blindagem_campos() as $grupo => $campos ) : ?>
			<h2><?php echo esc_html( $grupo ); ?></h2>
			<table class="form-table" role="presentation">
				<?php foreach ( $campos as $chave => $campo ) : ?>
					<tr>
						<th scope="row"><?php echo esc_html( $campo[0] ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="blindagem_opcoes[<?php echo esc_attr( $chave ); ?>]" value="1" <?php checked( ! empty( $opcoes[ $chave ] ) ); ?>>
								<?php echo esc_html( $campo[1] ); ?>
							</label>
							<?php if ( 'limite_login' === $chave ) : ?>
								<p>
									<input type="number" min="1" max="50" name="blindagem_opcoes[tentativas]" value="<?php echo esc_attr( $opcoes['tentativas'] ); ?>" class="small-text"> tentativas &rarr;
									<input type="number" min="1" max="1440" name="blindagem_opcoes[minutos]" value="<?php echo esc_attr( $opcoes['minutos'] ); ?>" class="small-text"> minutos de bloqueio
								</p>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
		<?php endforeach; ?>

		<h2>Alertas</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="blindagem-email">E-mail dos alertas</label></th>
				<td>
					<input type="email" id="blindagem-email" name="blindagem_opcoes[email_alerta]" value="<?php echo esc_attr( $opcoes['email_alerta'] ); ?>" class="regular-text" placeholder="seuemail@seuemail.com.br">
					<p class="description">Vazio = e-mail do administrador do site.</p>
				</td>
			</tr>
		</table>

		<?php submit_button( 'Salvar' ); ?>
	</form>

	<h2>Testar e-mail</h2>
	<p>Os alertas e o código de acesso dependem de o site conseguir mandar e-mail. Teste antes de ligar o 2FA.</p>
	<?php
	blindagem_botao( 'blindagem_email_teste', 'Mandar e-mail de teste para mim' );

	$exportar = $opcoes;
	unset( $exportar['email_alerta'] );
	?>
	<h2>Levar estas configurações para outro site</h2>
	<p>Copie o bloco abaixo e cole em <strong>Importar</strong> na Blindagem do outro site. O e-mail de alerta não vai junto (é de cada site).</p>
	<textarea class="large-text code" rows="4" readonly onclick="this.select()"><?php echo esc_textarea( wp_json_encode( array( 'blindagem' => $exportar, 'versao' => BLINDAGEM_VERSAO ) ) ); ?></textarea>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="blindagem_importar">
		<?php wp_nonce_field( 'blindagem_importar' ); ?>
		<p><label for="blindagem-importar"><strong>Importar</strong> — cole aqui o bloco copiado de outro site:</label></p>
		<textarea id="blindagem-importar" name="configuracoes" class="large-text code" rows="4" required></textarea>
		<?php submit_button( 'Importar configurações', 'secondary', 'submit', true, array( 'onclick' => 'return confirm(' . wp_json_encode( 'Substituir as proteções deste site pelas coladas?' ) . ')' ) ); ?>
	</form>
	<?php
}

function blindagem_aba_verificacao() {
	$rotulos = blindagem_tipos_achado();
	?>
	<p>
		<?php blindagem_botao( 'blindagem_verificar', 'Verificar agora', 'button button-primary' ); ?>
		<span class="description">Roda a varredura e a checagem de integridade. Pode levar um minuto.</span>
	</p>
	<?php
	$algum = false;

	foreach ( array( 'varredura' => 'Varredura', 'integridade' => 'Integridade (core e plugins × wordpress.org)' ) as $qual => $titulo ) {
		$relatorio = get_option( 'blindagem_rel_' . $qual );
		echo '<h2>' . esc_html( $titulo ) . '</h2>';

		if ( ! is_array( $relatorio ) ) {
			echo '<p>Ainda não rodou. Clique em "Verificar agora".</p>';
			continue;
		}

		// Arquivo apagado depois da verificação (pelo gerenciador da hospedagem, FTP…) sai da lista na hora.
		$antes_qtd             = count( $relatorio['achados'] );
		$relatorio['achados'] = array_values( array_filter( $relatorio['achados'], 'blindagem_achado_ainda_vale' ) );
		if ( count( $relatorio['achados'] ) !== $antes_qtd ) {
			update_option( 'blindagem_rel_' . $qual, $relatorio, false );
		}

		echo '<p>Última: ' . esc_html( mysql2date( 'd/m/Y H:i', $relatorio['quando'] ) ) . '</p>';

		if ( ! empty( $relatorio['observacao'] ) ) {
			echo '<p><em>' . esc_html( $relatorio['observacao'] ) . '</em></p>';
		}

		if ( ! $relatorio['achados'] ) {
			echo '<p style="color:#008a20"><strong>✔ Nada encontrado.</strong></p>';
			continue;
		}

		$algum = true;
		$form  = 'blindagem-lote-' . $qual;
		$grupos = array();
		foreach ( $relatorio['achados'] as $achado ) {
			$curto = array( 'foto_novo' => 'NOVO', 'foto_alterado' => 'ALTERADO', 'foto_apagado' => 'SUMIU', 'foto_pasta' => 'Tema/plugin inteiro', 'escondido' => 'Escondido', 'php_disfarcado' => 'PHP em imagem/texto' )[ $achado['tipo'] ] ?? ( $rotulos[ $achado['tipo'] ] ?? $achado['tipo'] );
			$grupos[ $achado['tipo'] ] = array( $curto, ( $grupos[ $achado['tipo'] ][1] ?? 0 ) + 1 );
		}
		blindagem_lote_barra( $form, 'blindagem_lote_achados', array( 'quarentena' => 'Pôr em quarentena (os que podem sair)', 'reconhecer' => 'Reconhecer como legítimos (falso alarme / fui eu)' ), $grupos );
		echo '<table class="widefat striped"><thead><tr>';
		blindagem_lote_todos( $form );
		echo '<th>O quê</th><th>Arquivo</th><th>Ação</th></tr></thead><tbody>';
		foreach ( $relatorio['achados'] as $achado ) {
			echo '<tr>';
			blindagem_lote_caixa( $form, $achado['arquivo'], $achado['tipo'] );
			printf(
				'<td>%s</td><td><code>%s</code>%s</td><td>',
				esc_html( $rotulos[ $achado['tipo'] ] ?? $achado['tipo'] ),
				esc_html( blindagem_visivel( $achado['arquivo'] ) ),
				! empty( $achado['evidencia'] ) ? '<br><small style="color:#646970"><strong>Por quê:</strong> ' . esc_html( $achado['evidencia'] ) . '</small>' : ''
			);
			blindagem_botao_achado( $achado );
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	if ( $algum ) {
		?>
		<h2>O que fazer</h2>
		<ol>
			<li><strong>Arquivo que não deveria existir</strong> (PHP em uploads, compactado estranho, código de backdoor): <em>Pôr em quarentena</em>. Ele para de rodar mas fica guardado — se o site quebrar, restaure. Tudo certo depois de alguns dias? <em>Apagar de vez</em>.</li>
			<li><strong>Arquivo do WordPress ou de plugin alterado:</strong> não tire do lugar (o site cai). Use <em>Reinstalar</em> — volta o original por cima.</li>
			<li><strong>Script no banco:</strong> abra o item e apague o trecho de código estranho; se for opção, peça ajuda a quem conhece o plugin dono dela.</li>
			<li>Depois de limpar: troque <strong>todas</strong> as senhas (painel, hospedagem, FTP, banco) e rode <code>wp config shuffle-salts</code> (derruba toda sessão aberta). Confira a lista de administradores.</li>
			<li><strong>Arquivo novo/alterado em tema ou plugin próprio</strong> ("foto"): foi você ou uma atualização? Reconheça. Ninguém mexeu e o "Por quê" mostra código estranho? Quarentena (arquivo novo) ou reinstale o tema/plugin do zip original (arquivo alterado).</li>
			<li><strong>Tema/plugin inteiro</strong> (instalado ou atualizado por fora do painel — zip enviado por cima, atualização automática da hospedagem): você ou a hospedagem atualizou? Reconheça. Ninguém mexeu? Reinstale do zip original. Arquivo com código estranho nunca entra nesta linha: aparece sozinho.</li>
			<li>Conferiu e é legítimo (ex.: drop-in de plugin de cache)? Use <em>Reconhecer</em> na linha dele — volta a aparecer se o arquivo mudar.</li>
		</ol>
		<p><strong>⚠️ Site que pode já estar infectado:</strong> não use "Reconhecer todos" na primeira verificação. Reconhecer marca como legítimo e o achado some da lista e dos alertas.</p>
		<?php
		blindagem_botao( 'blindagem_reconhecer', 'Reconhecer todos os achados como legítimos', 'button', 'TODOS os itens da lista somem e param de alertar. Você conferiu cada um?' );
	}

	if ( get_option( 'blindagem_reconhecidos' ) ) {
		blindagem_botao( 'blindagem_esquecer', 'Esquecer os reconhecidos', 'button' );
	}

	blindagem_tabela_quarentena();
}

function blindagem_aba_acessos() {
	$log = get_option( 'blindagem_acessos', array() );

	if ( ! blindagem_ligado( 'registro_acesso' ) ) {
		echo '<p>O registro de acessos está desligado na aba Proteções.</p>';
	}

	if ( ! $log ) {
		echo '<p>Nenhum acesso registrado ainda.</p>';
		return;
	}

	$rotulo = array( 'entrou' => '✔ entrou', 'falhou' => '✖ errou', 'bloqueado' => '⛔ bloqueado' );

	echo '<table class="widefat striped"><thead><tr><th>Quando</th><th>Evento</th><th>Login tentado</th><th>IP</th><th>Navegador</th></tr></thead><tbody>';
	foreach ( $log as $linha ) {
		printf(
			'<tr><td>%s</td><td>%s</td><td>%s</td><td><code>%s</code></td><td title="%s">%s</td></tr>',
			esc_html( mysql2date( 'd/m/Y H:i:s', $linha['quando'] ) ),
			esc_html( $rotulo[ $linha['evento'] ] ?? $linha['evento'] ),
			esc_html( $linha['login'] ),
			esc_html( $linha['ip'] ),
			esc_attr( $linha['ua'] ?? '' ),
			esc_html( function_exists( 'blindagem_descrever_navegador' ) ? blindagem_descrever_navegador( $linha['ua'] ?? '' ) : '' )
		);
	}
	echo '</tbody></table><p></p>';

	blindagem_botao( 'blindagem_limpar_acessos', 'Apagar registro', 'button', 'Apagar o registro de acessos?' );
}

function blindagem_aba_eventos() {
	$log = get_option( 'blindagem_eventos', array() );

	if ( ! blindagem_ligado( 'registro_eventos' ) ) {
		echo '<p>O registro de eventos está desligado na aba Proteções.</p>';
	}

	echo '<p>O que mudou no site e quem mudou: plugins, temas, usuários e opções críticas. Os últimos 300.</p>';

	if ( ! $log ) {
		echo '<p>Nenhum evento registrado ainda.</p>';
		return;
	}

	echo '<table class="widefat striped"><thead><tr><th>Quando</th><th>Evento</th><th>Detalhe</th><th>Quem</th><th>IP</th></tr></thead><tbody>';
	foreach ( $log as $linha ) {
		$grave = in_array( $linha['evento'], array( 'BLOQUEADO', 'Opção crítica alterada', 'Arquivo em quarentena' ), true );
		printf(
			'<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><code>%s</code></td></tr>',
			esc_html( mysql2date( 'd/m/Y H:i:s', $linha['quando'] ) ),
			$grave ? '<strong style="color:#b32d2e">' . esc_html( $linha['evento'] ) . '</strong>' : esc_html( $linha['evento'] ),
			esc_html( $linha['detalhe'] ),
			esc_html( $linha['quem'] ),
			esc_html( $linha['ip'] )
		);
	}
	echo '</tbody></table><p></p>';

	blindagem_botao( 'blindagem_limpar_eventos', 'Apagar registro', 'button', 'Apagar o registro de eventos?' );
}

/**
 * Quem responde a um hook: "WordPress", nome do plugin, "Tema" ou "mu-plugin".
 * Sem ninguém ligado, o evento é órfão (sobrou de plugin removido).
 */
function blindagem_origem_hook( $hook ) {
	global $wp_filter;

	if ( empty( $wp_filter[ $hook ] ) ) {
		return '';
	}

	$pastas  = array(
		wp_normalize_path( WPMU_PLUGIN_DIR ) . '/' => 'mu-plugin',
		wp_normalize_path( WP_PLUGIN_DIR ) . '/'   => null,
		wp_normalize_path( get_theme_root() ) . '/' => 'Tema',
		wp_normalize_path( ABSPATH )              => 'WordPress',
	);
	$plugins = get_plugins();
	$origens = array();

	foreach ( $wp_filter[ $hook ]->callbacks as $por_prioridade ) {
		foreach ( $por_prioridade as $cb ) {
			try {
				$f = $cb['function'];
				if ( is_array( $f ) ) {
					$ref = new ReflectionMethod( $f[0], $f[1] );
				} elseif ( is_string( $f ) && strpos( $f, '::' ) ) {
					$ref = new ReflectionMethod( $f );
				} else {
					$ref = new ReflectionFunction( $f );
				}
				$arquivo = wp_normalize_path( (string) $ref->getFileName() );
			} catch ( ReflectionException $e ) {
				continue;
			}

			foreach ( $pastas as $pasta => $rotulo ) {
				if ( 0 !== strpos( $arquivo, $pasta ) ) {
					continue;
				}
				if ( null === $rotulo ) {
					$pasta_plugin = strtok( substr( $arquivo, strlen( $pasta ) ), '/' );
					$rotulo       = $pasta_plugin;
					foreach ( $plugins as $base => $dados ) {
						if ( 0 === strpos( $base, $pasta_plugin . '/' ) ) {
							$rotulo = $dados['Name'];
							break;
						}
					}
				}
				$origens[ $rotulo ] = true;
				break;
			}
		}
	}

	return $origens ? implode( ', ', array_keys( $origens ) ) : '?';
}

/**
 * Por que uma tarefa não pode ser pausada ('' = pode).
 * Core: parar update check ou limpeza deixa o site sem aviso de falha de segurança.
 */
function blindagem_cron_protegida( $hook, $origem ) {
	if ( 0 === strpos( $hook, 'blindagem_' ) ) {
		return 'Da Blindagem: desligue na aba Proteções.';
	}
	if ( '' === $origem ) {
		return '';
	}
	if ( '?' === $origem || false !== strpos( $origem, 'WordPress' ) ) {
		return 'Do WordPress: protegida.';
	}
	return '';
}

function blindagem_aba_agenda() {
	$eventos = _get_cron_array();
	$agendas = wp_get_schedules();
	$agora   = time();
	$nossos  = array( 'blindagem_varredura' => 'varredura', 'blindagem_integridade' => 'integridade' );

	echo '<p>Tarefas agendadas do WP-Cron. As do WordPress ficam protegidas: parar a checagem de atualização ou a limpeza deixa o site sem aviso de falha de segurança. As de plugin e tema podem ser <strong>pausadas</strong> (o plugin fica impedido de recriar) e as órfãs, <strong>removidas</strong>.</p>';

	if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
		echo '<div class="notice notice-info inline"><p><code>DISABLE_WP_CRON</code> está ligado: as tarefas só rodam se o servidor chamar <code>wp-cron.php</code> (cron da hospedagem).</p></div>';
	}

	// WP-Cron roda a cada visita. Mais de 1 h atrasado = site sem visita ou cron travado.
	$atrasados = 0;
	foreach ( (array) $eventos as $quando => $hooks ) {
		if ( $quando < $agora - HOUR_IN_SECONDS ) {
			$atrasados += count( $hooks );
		}
	}
	if ( $atrasados ) {
		printf(
			'<div class="notice notice-warning inline"><p>%d tarefa(s) atrasada(s) mais de 1 hora. O WP-Cron só roda quando alguém visita o site; em site com pouca visita, configure um cron na hospedagem chamando <code>%s</code>.</p></div>',
			(int) $atrasados,
			esc_html( site_url( 'wp-cron.php' ) )
		);
	}

	if ( ! $eventos ) {
		echo '<p>Nenhuma tarefa agendada.</p>';
		return;
	}

	blindagem_lote_barra( 'blindagem-lote-cron', 'blindagem_lote_cron', array( 'remover' => 'Remover (só as órfãs)', 'pausar' => 'Pausar (de plugin/tema)' ) );
	echo '<table class="widefat striped"><thead><tr>';
	blindagem_lote_todos( 'blindagem-lote-cron' );
	echo '<th>Próxima execução</th><th>Tarefa</th><th>Repete</th><th>De quem</th><th>Ação</th></tr></thead><tbody>';
	foreach ( $eventos as $quando => $hooks ) {
		foreach ( $hooks as $hook => $instancias ) {
			$origem = blindagem_origem_hook( $hook );
			foreach ( $instancias as $evento ) {
				$falta = $quando - $agora;
				if ( $falta >= 0 ) {
					$relativo = 'em ' . human_time_diff( $agora, $quando );
				} else {
					$relativo = 'atrasada há ' . human_time_diff( $quando, $agora );
				}
				$repete = empty( $evento['schedule'] ) ? 'uma vez' : ( $agendas[ $evento['schedule'] ]['display'] ?? $evento['schedule'] );
				$nota   = '';
				if ( isset( $nossos[ $hook ] ) && ! blindagem_ligado( $nossos[ $hook ] ) ) {
					$nota = '<br><span class="description">Desligada na aba Proteções: roda, mas não faz nada.</span>';
				}
				echo '<tr>';
				blindagem_lote_caixa( 'blindagem-lote-cron', blindagem_cron_protegida( $hook, $origem ) ? null : $hook );
				printf(
					'<td>%s<br><span style="color:%s">%s</span></td><td><code>%s</code>%s%s</td><td>%s</td><td>%s</td><td>',
					esc_html( wp_date( 'd/m/Y H:i', $quando ) ),
					$falta < -HOUR_IN_SECONDS ? '#d63638' : '#646970',
					esc_html( $relativo ),
					esc_html( $hook ),
					$evento['args'] ? ' <span class="description">' . esc_html( wp_json_encode( $evento['args'] ) ) . '</span>' : '',
					$nota, // phpcs:ignore WordPress.Security.EscapeOutput -- HTML fixo acima.
					esc_html( $repete ),
					'' === $origem ? '<span style="color:#d63638">ninguém — órfã</span>' : esc_html( $origem ) // phpcs:ignore WordPress.Security.EscapeOutput
				);
				$motivo = blindagem_cron_protegida( $hook, $origem );
				if ( $motivo ) {
					echo '<span class="description">' . esc_html( $motivo ) . '</span>';
				} elseif ( '' === $origem ) {
					blindagem_botao( 'blindagem_cron_remover', 'Remover', 'button button-small', 'Remover a tarefa órfã ' . $hook . '?', array( 'hook' => $hook ) );
				} else {
					blindagem_botao( 'blindagem_cron_pausar', 'Pausar', 'button button-small', "Pausar {$hook} ({$origem})? O plugin pode deixar de fazer algo que precisa; confira depois.", array( 'hook' => $hook ) );
				}
				echo '</td></tr>';
			}
		}
	}
	echo '</tbody></table>';

	$pausadas = blindagem_cron_pausadas();
	if ( $pausadas ) {
		echo '<h2>Pausadas</h2><table class="widefat striped"><thead><tr><th>Tarefa</th><th>De quem</th><th>Ação</th></tr></thead><tbody>';
		foreach ( array_keys( $pausadas ) as $hook ) {
			$origem = blindagem_origem_hook( $hook );
			printf( '<tr><td><code>%s</code></td><td>%s</td><td>', esc_html( $hook ), esc_html( '' === $origem ? 'ninguém (plugin removido?)' : $origem ) );
			blindagem_botao( 'blindagem_cron_retomar', 'Retomar', 'button button-small', '', array( 'hook' => $hook ) );
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	echo '<h2>Tarefas da Blindagem</h2><p>';
	foreach ( $nossos as $hook => $qual ) {
		if ( ! wp_next_scheduled( $hook ) ) {
			printf( '<strong style="color:#d63638">%s não está agendada.</strong> ', esc_html( $hook ) );
		}
	}
	blindagem_botao( 'blindagem_rodar_varredura', 'Rodar varredura agora', 'button button-primary' );
	blindagem_botao( 'blindagem_rodar_integridade', 'Rodar integridade agora' );
	blindagem_botao( 'blindagem_reagendar', 'Recriar agendamentos' );
	echo '</p><p class="description">Recriar apaga e agenda de novo as duas tarefas (varredura em 5 min, integridade em 15 min). Use se aparecerem atrasadas ou sumirem.</p>';
}

function blindagem_aba_diagnostico() {
	$cores = array( 'grave' => '#d63638', 'aviso' => '#dba617', 'info' => '#72aee6', 'ok' => '#00a32a' );
	$nomes = array( 'grave' => 'GRAVE', 'aviso' => 'ATENÇÃO', 'info' => 'INFO', 'ok' => 'OK' );
	$itens = blindagem_diagnostico();

	usort( $itens, function ( $a, $b ) {
		$ordem = array( 'grave' => 0, 'aviso' => 1, 'info' => 2, 'ok' => 3 );
		return $ordem[ $a['nivel'] ] <=> $ordem[ $b['nivel'] ];
	} );

	$contagem = array_count_values( wp_list_pluck( $itens, 'nivel' ) );
	echo '<p>O que o plugin não resolve sozinho, mas aponta. Todas as checagens, com o status de cada uma. Recalculado a cada visita a esta aba.' . ( blindagem_ligado( 'alerta_diagnostico' ) ? ' Também conferido todo dia: problema GRAVE ou ATENÇÃO novo vira e-mail.' : '' ) . '</p><p>';
	foreach ( $nomes as $nivel => $nome ) {
		printf( '<strong style="color:%s;margin-right:1.5em">%s: %d</strong>', esc_attr( $cores[ $nivel ] ), esc_html( $nome ), (int) ( $contagem[ $nivel ] ?? 0 ) );
	}
	echo '</p>';
	echo '<table class="widefat striped"><tbody>';
	foreach ( $itens as $it ) {
		printf(
			'<tr><td style="width:7em"><strong style="color:%s">%s</strong></td><td>%s%s</td></tr>',
			esc_attr( $cores[ $it['nivel'] ] ),
			esc_html( $nomes[ $it['nivel'] ] ),
			esc_html( $it['titulo'] ),
			$it['como'] ? '<br><span class="description">' . esc_html( $it['como'] ) . '</span>' : ''
		);
	}
	echo '</tbody></table>';
}
