<?php
/**
 * Coleta SOMENTE LEITURA do estado do site. Nada aqui altera o WordPress.
 *
 * Nunca entra no relatório: conteúdo de arquivos, wp-config, senhas, hashes de
 * senha, e-mails, dados de clientes/pedidos. Só versões, logins de admin,
 * caminhos relativos e hashes de arquivos.
 */

defined( 'ABSPATH' ) || exit;

final class Sentinela_Coletor {

	const LIMITE_ARQUIVOS = 20000;
	const LIMITE_SEGUNDOS = 25;

	/** Pastas de scanners de segurança: contêm assinaturas de malware como texto. */
	const IGNORAR_SCAN = array( 'sentinela-agent', 'wordfence', 'sucuri-scanner', 'all-in-one-wp-security-and-firewall', 'better-wp-security', 'ithemes-security-pro', 'malcare-security', 'wpscan', 'defender-security', 'shield-security', 'anti-malware', 'gotmls' );

	const ASSINATURAS = array(
		'eval_decodificado' => '/\beval\s*\(\s*(base64_decode|gzinflate|gzuncompress|gzdecode|str_rot13|strrev|hex2bin)\s*\(/i',
		'execucao_request'  => '/\b(eval|assert|system|shell_exec|passthru|exec|popen|proc_open)\s*\(\s*(stripslashes\s*\(\s*)?\$_(POST|GET|REQUEST|COOKIE|SERVER)\b/i',
		'preg_replace_e'    => '/preg_replace\s*\(\s*[\'"].{1,200}\/[a-z]*e[a-z]*[\'"]\s*,/i',
		// Nomes partidos com [x]: casam igual, mas o texto do arquivo não traz o nome inteiro — senão scanners
		// como o Blindagem acusam este arquivo de webshell.
		'webshell'          => '/(Files[M]an|c99[s]hell|r57[s]hell|WSO[s]etcookie|b37[4]k|[U]name:\s*<|Indo[X]ploit|Anonymous[F]ox)/',
		// Só em linha de código: comentário de documentação (ex.: biblioteca do Google) citando URL não conta.
		'include_remoto'    => '/^(?![ \t]*(\*|\/\/|#|\/\*))[^\n]*?\b(include|require)(_once)?\s*\(?\s*[\'"]https?:\/\//im',
		'create_function'   => '/create_function\s*\([^)]{0,200}\$_(POST|GET|REQUEST|COOKIE)/i',
	);

	private static $inicio;

	public static function coletar() {
		self::$inicio = microtime( true );
		@set_time_limit( 60 ); // phpcs:ignore -- só em cron

		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/update.php';
		self::atualizar_listas();

		global $wp_version, $table_prefix;

		return array(
			'plataforma'    => 'wordpress',
			'agente_versao' => SENTINELA_AGENT_VERSION,
			'gerado_em'     => gmdate( 'c' ),
			'core'          => self::core( $wp_version ),
			'php'           => array( 'versao' => PHP_VERSION ),
			'plugins'       => self::plugins(),
			'temas'         => self::temas(),
			'admins'        => self::admins(),
			'arquivos'      => array(
				'php_em_uploads' => self::php_em_uploads(),
				'suspeitos'      => self::suspeitos(),
				'hashes'         => self::hashes(),
			),
			'config'        => array(
				'disallow_file_edit' => defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
				'wp_debug'           => defined( 'WP_DEBUG' ) && WP_DEBUG,
				'wp_debug_display'   => defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY ),
				'prefixo_padrao'     => 'wp_' === $table_prefix,
				'https_admin'        => ( defined( 'FORCE_SSL_ADMIN' ) && FORCE_SSL_ADMIN ) || 0 === strpos( admin_url(), 'https://' ),
			),
			'backup'        => self::backup(),
			'estrutura'     => self::estrutura(),
			'blindagem'     => self::blindagem(),
			'defesas'       => array( 'wordfence' => self::wordfence() ),
		);
	}

	private static function tempo_esgotado() {
		return ( microtime( true ) - self::$inicio ) > self::LIMITE_SEGUNDOS;
	}

	private static function rel( $caminho ) {
		return ltrim( str_replace( wp_normalize_path( ABSPATH ), '', wp_normalize_path( $caminho ) ), '/' );
	}

	// ---------------------------------------------------------------- core

	private static function core( $versao ) {
		$atualizacao = null;
		$t           = get_site_transient( 'update_core' );
		if ( $t && ! empty( $t->updates ) ) {
			foreach ( $t->updates as $u ) {
				if ( isset( $u->response, $u->current ) && 'upgrade' === $u->response ) {
					$atualizacao = (string) $u->current;
					break;
				}
			}
		}

		// Checksums OFICIAIS (api.wordpress.org, pela função do próprio WP).
		$locale    = get_locale();
		$checksums = get_core_checksums( $versao, $locale ? $locale : 'en_US' );
		if ( ! is_array( $checksums ) && 'en_US' !== $locale ) {
			$checksums = get_core_checksums( $versao, 'en_US' );
		}
		// Instalado em inglês e trocado de idioma depois (padrão da Hostinger): version.php, readme.html e
		// wp-config-sample.php são os do pacote en_US. Os dois pacotes são oficiais — vale bater com qualquer um.
		$ingles = 'en_US' !== $locale && is_array( $checksums ) ? get_core_checksums( $versao, 'en_US' ) : null;
		$alterados = array();
		$ok        = null;
		if ( is_array( $checksums ) ) {
			$ok = true;
			foreach ( $checksums as $arquivo => $md5 ) {
				if ( 0 === strpos( $arquivo, 'wp-content/' ) ) {
					continue; // temas/plugins padrão podem ter sido apagados/atualizados
				}
				$abs = ABSPATH . $arquivo;
				if ( ! is_file( $abs ) ) {
					continue; // apagado não executa nada
				}
				$atual = md5_file( $abs );
				if ( $atual !== $md5 && ! ( is_array( $ingles ) && isset( $ingles[ $arquivo ] ) && $ingles[ $arquivo ] === $atual ) ) {
					$ok          = false;
					$alterados[] = $arquivo;
				}
			}
			if ( is_array( $ingles ) ) {
				$checksums += $ingles; // arquivo que só existe no pacote en_US não é "extra"
			}
			// PHP a mais em wp-admin/wp-includes: lugar clássico de backdoor.
			foreach ( array( 'wp-admin', 'wp-includes' ) as $pasta ) {
				foreach ( self::arquivos( ABSPATH . $pasta, '/\.(php|phtml|phar)$/i', 5000 ) as $abs ) {
					$r = self::rel( $abs );
					if ( ! isset( $checksums[ $r ] ) ) {
						$ok          = false;
						$alterados[] = $r . ' (extra)';
					}
				}
			}
		}
		return array(
			'versao'       => (string) $versao,
			'atualizacao'  => $atualizacao,
			'checksums_ok' => $ok,
			'alterados'    => array_slice( $alterados, 0, 500 ),
			'locale'       => (string) $locale,
		);
	}

	// ------------------------------------------------------ plugins / temas

	private static function plugins() {
		$atual = get_site_transient( 'update_plugins' );
		$out   = array();
		foreach ( get_plugins() as $arquivo => $p ) {
			$slug = false !== strpos( $arquivo, '/' ) ? dirname( $arquivo ) : basename( $arquivo, '.php' );
			$novo = isset( $atual->response[ $arquivo ]->new_version ) ? (string) $atual->response[ $arquivo ]->new_version : null;
			$out[] = array(
				'slug'        => (string) $slug,
				'nome'        => wp_strip_all_tags( (string) $p['Name'] ),
				'versao'      => $p['Version'] ? (string) $p['Version'] : '0',
				'ativo'       => is_plugin_active( $arquivo ),
				'atualizacao' => $novo,
			);
		}
		return array_slice( $out, 0, 500 );
	}

	private static function temas() {
		$atual = get_site_transient( 'update_themes' );
		$ativo = array( get_stylesheet(), get_template() );
		$out   = array();
		foreach ( wp_get_themes() as $slug => $t ) {
			$out[] = array(
				'slug'        => (string) $slug,
				'nome'        => wp_strip_all_tags( (string) $t->get( 'Name' ) ),
				'versao'      => $t->get( 'Version' ) ? (string) $t->get( 'Version' ) : '0',
				'ativo'       => in_array( $slug, $ativo, true ),
				'atualizacao' => isset( $atual->response[ $slug ]['new_version'] ) ? (string) $atual->response[ $slug ]['new_version'] : null,
			);
		}
		return array_slice( $out, 0, 200 );
	}

	// ---------------------------------------------------------------- admins

	private static function admins() {
		$usuarios = get_users(
			array(
				'role'   => 'administrator',
				'fields' => array( 'ID', 'user_login', 'user_registered' ),
				'number' => 200,
			)
		);
		$out = array();
		foreach ( $usuarios as $u ) {
			$out[ (int) $u->ID ] = array(
				'id'         => (int) $u->ID,
				'login'      => (string) $u->user_login,
				'registrado' => (string) $u->user_registered,
			);
		}
		if ( is_multisite() ) {
			foreach ( get_super_admins() as $login ) {
				$u = get_user_by( 'login', $login );
				if ( $u ) {
					$out[ (int) $u->ID ] = array(
						'id'         => (int) $u->ID,
						'login'      => (string) $u->user_login,
						'registrado' => (string) $u->user_registered,
					);
				}
			}
		}
		return array_values( $out );
	}

	// -------------------------------------------------------------- arquivos

	/** Lista arquivos (caminho absoluto) que batem com o padrão, com limite. */
	private static function arquivos( $raiz, $padrao, $limite ) {
		$out = array();
		if ( ! is_dir( $raiz ) || ! is_readable( $raiz ) ) {
			return $out;
		}
		try {
			$it = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY,
				RecursiveIteratorIterator::CATCH_GET_CHILD
			);
			$n = 0;
			foreach ( $it as $f ) {
				if ( ++$n > self::LIMITE_ARQUIVOS || count( $out ) >= $limite || self::tempo_esgotado() ) {
					break;
				}
				if ( $f->isFile() && ! $f->isLink() && preg_match( $padrao, $f->getFilename() ) ) {
					$out[] = $f->getPathname();
				}
			}
		} catch ( Exception $e ) {
			// sem permissão: segue com o que deu
		}
		return $out;
	}

	private static function php_em_uploads() {
		$up = wp_upload_dir( null, false );
		if ( empty( $up['basedir'] ) ) {
			return array();
		}
		$out = array();
		foreach ( self::arquivos( $up['basedir'], '/\.(php\d?|phtml|pht|phar)$/i', 400 ) as $abs ) {
			// index.php que plugins colocam para bloquear listagem: "Silence is golden" ou só um 404 (WPForms).
			if ( 'index.php' === basename( $abs ) && filesize( $abs ) < 300 && self::index_inofensivo( (string) file_get_contents( $abs ) ) ) {
				continue;
			}
			$out[] = self::rel( $abs );
		}
		return array_slice( $out, 0, 200 );
	}

	/** `<?php` vazio, com "Silence is golden" ou só mandando 404 (header()). Qualquer outra coisa = suspeito. */
	private static function index_inofensivo( $codigo ) {
		$sem = preg_replace( '/^\s*header\(\s*\$_SERVER\[\s*[\'"]SERVER_PROTOCOL[\'"]\s*\]\s*\.\s*[\'"] 404 Not Found[\'"]\s*\);\s*$|^\s*header\(\s*[\'"]Status: 404 Not Found[\'"]\s*\);\s*$/m', '', $codigo );
		return (bool) preg_match( '/^<\?php\s*(\/\/\s*Silence is golden\.?)?\s*$/i', (string) $sem );
	}

	private static function suspeitos() {
		$raizes = array( WP_PLUGIN_DIR, get_theme_root(), WPMU_PLUGIN_DIR );
		$up     = wp_upload_dir( null, false );
		if ( ! empty( $up['basedir'] ) ) {
			$raizes[] = $up['basedir'];
		}
		$out = array();
		foreach ( $raizes as $raiz ) {
			foreach ( self::arquivos( $raiz, '/\.(php\d?|phtml|inc)$/i', 8000 ) as $abs ) {
				if ( self::tempo_esgotado() || count( $out ) >= 200 ) {
					break 2;
				}
				$rel = self::rel( $abs );
				foreach ( self::IGNORAR_SCAN as $ign ) {
					if ( false !== strpos( $rel, '/' . $ign . '/' ) ) {
						continue 2;
					}
				}
				$tam = @filesize( $abs );
				if ( ! $tam ) {
					continue;
				}
				// Malware costuma vir inchado para escapar de scanner que pula arquivo grande:
				// acima de 2 MB lê o começo e o fim (onde fica o código que roda).
				$codigo = $tam > 2 * 1024 * 1024
					? (string) @file_get_contents( $abs, false, null, 0, 1024 * 1024 ) . "\n" . (string) @file_get_contents( $abs, false, null, $tam - 1024 * 1024 )
					: (string) @file_get_contents( $abs );
				foreach ( self::ASSINATURAS as $nome => $re ) {
					if ( preg_match( $re, $codigo ) ) {
						$out[] = array(
							'caminho'    => $rel,
							'assinatura' => $nome,
						);
						break;
					}
				}
			}
		}
		// Arquivos PHP soltos na raiz que não são do WordPress.
		$raiz_wp = array( 'index.php', 'wp-activate.php', 'wp-blog-header.php', 'wp-comments-post.php', 'wp-config.php', 'wp-config-sample.php', 'wp-cron.php', 'wp-links-opml.php', 'wp-load.php', 'wp-login.php', 'wp-mail.php', 'wp-settings.php', 'wp-signup.php', 'wp-trackback.php', 'xmlrpc.php' );
		foreach ( (array) glob( ABSPATH . '*.php' ) as $abs ) {
			if ( ! in_array( basename( $abs ), $raiz_wp, true ) && count( $out ) < 200 ) {
				$codigo = (string) @file_get_contents( $abs, false, null, 0, 2 * 1024 * 1024 );
				foreach ( self::ASSINATURAS as $nome => $re ) {
					if ( preg_match( $re, $codigo ) ) {
						$out[] = array(
							'caminho'    => self::rel( $abs ),
							'assinatura' => $nome,
						);
						break;
					}
				}
			}
		}
		return $out;
	}

	/**
	 * Faz o WordPress conferir se há atualização quando a lista guardada está
	 * velha (rodando pelo agendador ela pode estar vazia). É o mesmo pedido ao
	 * wordpress.org que o próprio WordPress faz; não instala nada.
	 */
	private static function atualizar_listas() {
		$velha = function ( $nome ) {
			$t = get_site_transient( $nome );
			return ! is_object( $t ) || empty( $t->last_checked ) || time() - (int) $t->last_checked > 12 * HOUR_IN_SECONDS;
		};
		if ( $velha( 'update_plugins' ) && function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
		}
		if ( $velha( 'update_themes' ) && function_exists( 'wp_update_themes' ) ) {
			wp_update_themes();
		}
		if ( $velha( 'update_core' ) && function_exists( 'wp_version_check' ) ) {
			wp_version_check();
		}
	}

	/**
	 * O que roda sem aparecer na lista de plugins (mu-plugins e drop-ins) e
	 * pastas em plugins/ que não são plugin (casca deixada por malware).
	 * Só nomes e tamanhos — nunca conteúdo.
	 */
	private static function estrutura() {
		$mu = array();
		foreach ( (array) glob( WPMU_PLUGIN_DIR . '/*.php' ) as $abs ) {
			$mu[] = array(
				'arquivo' => basename( $abs ),
				'tamanho' => (int) @filesize( $abs ),
			);
		}
		$dropins = array();
		foreach ( array_keys( get_dropins() ) as $arquivo ) {
			$abs       = WP_CONTENT_DIR . '/' . $arquivo;
			$dropins[] = array(
				'arquivo' => (string) $arquivo,
				'tamanho' => (int) @filesize( $abs ),
			);
		}
		$com_plugin = array();
		foreach ( array_keys( get_plugins() ) as $arquivo ) {
			if ( false !== strpos( $arquivo, '/' ) ) {
				$com_plugin[ dirname( $arquivo ) ] = true;
			}
		}
		$falsas = array();
		foreach ( (array) glob( WP_PLUGIN_DIR . '/*', GLOB_ONLYDIR ) as $abs ) {
			$nome = basename( $abs );
			if ( ! isset( $com_plugin[ $nome ] ) ) {
				$falsas[] = $nome;
			}
		}
		$escondidos = self::escondidos();
		// Data de modificação do que é suspeito (pista de desde quando; o invasor pode forjar).
		$datas = array();
		$data  = function ( $chave, $abs ) use ( &$datas ) {
			$t = @filemtime( $abs ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( $t && count( $datas ) < 300 ) {
				$datas[ $chave ] = gmdate( 'c', $t );
			}
		};
		foreach ( array_slice( $falsas, 0, 100 ) as $nome ) {
			$data( 'plugins/' . $nome, WP_PLUGIN_DIR . '/' . $nome );
		}
		foreach ( array_slice( $mu, 0, 100 ) as $m ) {
			$data( 'mu-plugins/' . $m['arquivo'], WPMU_PLUGIN_DIR . '/' . $m['arquivo'] );
		}
		foreach ( $escondidos as $x ) {
			$data( $x['arquivo'], WP_CONTENT_DIR . '/' . $x['arquivo'] );
		}
		foreach ( self::php_em_uploads() as $rel ) {
			$data( $rel, ABSPATH . $rel );
		}
		return array(
			'mu_plugins'        => array_slice( $mu, 0, 100 ),
			'dropins'           => array_slice( $dropins, 0, 50 ),
			'pastas_sem_plugin' => array_slice( $falsas, 0, 100 ),
			'escondidos'        => $escondidos,
			'prepend'           => self::prepend(),
			'datas'             => (object) $datas, // vazio vira {} no JSON
		);
	}

	/**
	 * Arquivos com ponto na frente no 1º nível de wp-content, plugins, mu-plugins, themes e uploads — onde o
	 * malware do Perfil Portas guardava marcadores (.gk_…, .sd_…) e carga (.wp-object-cache-<hex>.dat).
	 * Nome relativo a wp-content, tamanho e se tem PHP; nunca o conteúdo.
	 */
	private static function escondidos() {
		$uploads = wp_get_upload_dir();
		$pastas  = array_unique( array( WP_CONTENT_DIR, WP_PLUGIN_DIR, WPMU_PLUGIN_DIR, get_theme_root(), (string) $uploads['basedir'] ) );
		$base    = wp_normalize_path( WP_CONTENT_DIR ) . '/';
		$saida   = array();
		foreach ( $pastas as $pasta ) {
			foreach ( (array) @scandir( $pasta ) as $nome ) { // phpcs:ignore -- pasta pode não existir
				$abs = $pasta . '/' . $nome;
				if ( '.' !== substr( (string) $nome, 0, 1 ) || '.' === $nome || '..' === $nome || ! is_file( $abs ) || is_link( $abs ) ) {
					continue;
				}
				if ( preg_match( '/^\.(htaccess|user\.ini|DS_Store|litespeed_conf\.dat|gitignore|gitkeep)$/i', $nome ) ) {
					continue;
				}
				$inicio  = (string) @file_get_contents( $abs, false, null, 0, 4096 ); // phpcs:ignore -- só a ponta, para saber se é PHP
				$rel     = wp_normalize_path( $abs );
				$saida[] = array(
					'arquivo' => 0 === strpos( $rel, $base ) ? substr( $rel, strlen( $base ) ) : basename( $abs ),
					'tamanho' => (int) @filesize( $abs ),
					'php'     => (bool) preg_match( '/<\?php|<\?=/i', $inicio ),
				);
				if ( count( $saida ) >= 100 ) {
					return $saida;
				}
			}
		}
		return $saida;
	}

	/**
	 * auto_prepend_file no .htaccess/.user.ini/php.ini da raiz: arquivo que roda antes de TODA página. Só o nome
	 * do arquivo apontado (o caminho completo traz o usuário da hospedagem) e se ele existe.
	 */
	private static function prepend() {
		$saida = array();
		foreach ( array( '.htaccess', '.user.ini', 'php.ini' ) as $config ) {
			$abs = ABSPATH . $config;
			if ( ! is_file( $abs ) || filesize( $abs ) > 512000 ) {
				continue;
			}
			if ( preg_match_all( '/auto_prepend_file["\'\s=]+["\']?([^"\'\s]+)/i', (string) file_get_contents( $abs ), $m ) ) { // phpcs:ignore
				foreach ( array_unique( $m[1] ) as $alvo ) {
					$saida[] = array(
						'origem' => $config,
						'alvo'   => basename( $alvo ),
						'existe' => is_file( $alvo ) || is_file( ABSPATH . ltrim( $alvo, '/' ) ),
					);
				}
			}
		}
		return array_slice( $saida, 0, 20 );
	}

	/**
	 * Resumo do plugin Blindagem, se instalado: o que a última verificação dele achou e ninguém reconheceu.
	 * Só LÊ as opções que ele grava (o agente nunca pede ao Blindagem para fazer nada).
	 */
	private static function blindagem() {
		if ( ! defined( 'BLINDAGEM_VERSAO' ) ) {
			return null;
		}
		$resumo = array( 'versao' => (string) BLINDAGEM_VERSAO );
		foreach ( array( 'varredura', 'integridade' ) as $qual ) {
			$rel   = get_option( 'blindagem_rel_' . $qual );
			$tipos = array();
			$itens = array();
			foreach ( (array) ( is_array( $rel ) ? ( $rel['achados'] ?? array() ) : array() ) as $a ) {
				$tipo           = isset( $a['tipo'] ) ? (string) $a['tipo'] : '?';
				$tipos[ $tipo ] = ( $tipos[ $tipo ] ?? 0 ) + 1;
				if ( count( $itens ) < 30 ) {
					$itens[] = array( 'tipo' => $tipo, 'arquivo' => substr( (string) ( $a['arquivo'] ?? '' ), 0, 200 ) );
				}
			}
			$resumo[ $qual ] = array(
				'quando' => is_array( $rel ) && ! empty( $rel['quando'] ) ? (string) $rel['quando'] : null,
				'tipos'  => (object) $tipos, // vazio vira {} no JSON (array vazio viraria [] e o painel recusaria)
				'itens'  => $itens,
			);
		}
		$quarentena           = get_option( 'blindagem_quarentena' );
		$resumo['quarentena'] = is_array( $quarentena ) ? count( $quarentena ) : 0;
		return $resumo;
	}

	/**
	 * Wordfence está trabalhando? Só LÊ a configuração dele: data da última varredura, se terminou bem e
	 * quando as regras do firewall foram atualizadas. Null = Wordfence não está ativo.
	 */
	private static function wordfence() {
		if ( ! class_exists( 'wfConfig' ) || ! method_exists( 'wfConfig', 'get' ) ) {
			return null;
		}
		$quando = function ( $t ) {
			return is_numeric( $t ) && (int) $t > 0 ? gmdate( 'c', (int) $t ) : null;
		};
		try {
			$fim    = wfConfig::get( 'lastScanCompleted' ); // 'ok' ou mensagem de erro
			$regras = null;
			if ( class_exists( 'wfWAF' ) && method_exists( 'wfWAF', 'getInstance' ) && wfWAF::getInstance() ) {
				$regras = wfWAF::getInstance()->getStorageEngine()->getConfig( 'rulesLastUpdated', null, 'transient' );
			}
			return array(
				'varredura_em' => $quando( wfConfig::get( 'scanTime' ) ),
				'varredura_ok' => null === $fim || '' === $fim || false === $fim ? null : 'ok' === $fim,
				'regras_em'    => $quando( $regras ),
			);
		} catch ( Throwable $e ) {
			return null;
		}
	}

	/** Hash dos arquivos PHP de cada plugin/tema. O painel compara com a base. */
	private static function hashes() {
		$out = array();
		foreach ( get_plugins() as $arquivo => $p ) {
			if ( false === strpos( $arquivo, '/' ) ) {
				$h = @md5_file( WP_PLUGIN_DIR . '/' . $arquivo );
				$id = 'plugin:' . basename( $arquivo, '.php' );
			} else {
				$h  = self::hash_pasta( WP_PLUGIN_DIR . '/' . dirname( $arquivo ) );
				$id = 'plugin:' . dirname( $arquivo );
			}
			if ( $h && preg_match( '/^[a-z0-9][a-z0-9._-]{0,199}$/i', substr( $id, 7 ) ) ) {
				$out[] = array(
					'id'     => $id,
					'versao' => $p['Version'] ? (string) $p['Version'] : '0',
					'hash'   => $h,
				);
			}
			if ( self::tempo_esgotado() ) {
				break;
			}
		}
		foreach ( wp_get_themes() as $slug => $t ) {
			$h = self::hash_pasta( $t->get_stylesheet_directory() );
			if ( $h && preg_match( '/^[a-z0-9][a-z0-9._-]{0,199}$/i', $slug ) ) {
				$out[] = array(
					'id'     => 'tema:' . $slug,
					'versao' => $t->get( 'Version' ) ? (string) $t->get( 'Version' ) : '0',
					'hash'   => $h,
				);
			}
			if ( self::tempo_esgotado() ) {
				break;
			}
		}
		return array_slice( $out, 0, 800 );
	}

	private static function hash_pasta( $dir ) {
		$lista = array();
		foreach ( self::arquivos( $dir, '/\.(php\d?|phtml|inc|js)$/i', 5000 ) as $abs ) {
			$lista[] = self::rel( $abs ) . ':' . md5_file( $abs );
		}
		if ( ! $lista ) {
			return null;
		}
		sort( $lista, SORT_STRING );
		return md5( implode( "\n", $lista ) );
	}

	// ---------------------------------------------------------------- backup

	private static function backup() {
		if ( is_plugin_active( 'updraftplus/updraftplus.php' ) ) {
			$u = get_option( 'updraft_last_backup' );
			$t = is_array( $u ) && ! empty( $u['backup_time'] ) ? (int) $u['backup_time'] : 0;
			return array(
				'plugin'    => 'updraftplus',
				'ultimo_em' => $t ? gmdate( 'c', $t ) : null,
			);
		}
		foreach ( array(
			'backwpup/backwpup.php'                                   => 'backwpup',
			'duplicator/duplicator.php'                               => 'duplicator',
			'all-in-one-wp-migration/all-in-one-wp-migration.php'     => 'all-in-one-wp-migration',
			'jetpack/jetpack.php'                                     => 'jetpack',
			'backup-backup/backup-backup.php'                         => 'backup-migration',
			'wpvivid-backuprestore/wpvivid-backuprestore.php'         => 'wpvivid',
		) as $arquivo => $nome ) {
			if ( is_plugin_active( $arquivo ) ) {
				return array(
					'plugin'    => $nome,
					'ultimo_em' => null,
				);
			}
		}
		return array(
			'plugin'    => null,
			'ultimo_em' => null,
		);
	}
}
