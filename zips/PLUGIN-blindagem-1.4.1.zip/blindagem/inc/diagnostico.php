<?php
/**
 * Diagnóstico: o que o plugin não resolve sozinho, mas aponta.
 *
 * Mostrado na aba Diagnóstico e conferido todo dia pelo cron da varredura:
 * item GRAVE ou ATENÇÃO que não estava na última conferência vira e-mail.
 */

defined( 'ABSPATH' ) || exit;

function blindagem_diagnostico() {
	global $wpdb;

	$itens = array();
	$item  = function ( $nivel, $titulo, $como = '' ) use ( &$itens ) {
		$itens[] = compact( 'nivel', 'titulo', 'como' );
	};

	// HTTPS
	if ( 0 === strpos( home_url(), 'https://' ) ) {
		$item( 'ok', 'O site usa HTTPS.' );
	} else {
		$item( 'grave', 'O site não usa HTTPS: senha e cookie de login trafegam em texto puro.', 'Ative o SSL na hospedagem e troque o endereço em Configurações → Geral. (Normal em ambiente local.)' );
	}

	// Papel padrão e cadastro
	if ( 'administrator' === get_option( 'default_role' ) ) {
		$item( 'grave', 'Todo usuário novo nasce ADMINISTRADOR.', 'Configurações → Geral → Função padrão: Assinante. Confira a lista de usuários.' );
	} else {
		$item( 'ok', 'Usuário novo não nasce administrador.' );
	}
	if ( get_option( 'users_can_register' ) && ! blindagem_ligado( 'registro_off' ) ) {
		$item( 'aviso', 'Qualquer pessoa pode se cadastrar no site.', 'Configurações → Geral → desmarque "Qualquer pessoa pode se registrar", ou ligue "Fechar o cadastro".' );
	} else {
		$item( 'ok', 'Cadastro aberto ao público está fechado.' );
	}

	// Usuário "admin" e quantidade de administradores
	if ( get_user_by( 'login', 'admin' ) ) {
		$item( 'aviso', 'Existe um usuário com login "admin" — é o primeiro que todo robô tenta.', 'Crie outro administrador, entre com ele e apague o "admin" transferindo o conteúdo.' );
	} else {
		$item( 'ok', 'Nenhum usuário com login "admin".' );
	}
	$admins = get_users( array( 'role' => 'administrator', 'fields' => array( 'user_login' ) ) );
	$item(
		count( $admins ) > 3 ? 'aviso' : 'ok',
		sprintf( '%d administrador(es): %s.', count( $admins ), implode( ', ', wp_list_pluck( $admins, 'user_login' ) ) ),
		count( $admins ) > 3 ? 'Cada admin é uma senha a mais que pode vazar. Rebaixe quem não precisa.' : ''
	);

	// Chaves de segurança
	if ( ! defined( 'AUTH_KEY' ) || 'put your unique phrase here' === AUTH_KEY || strlen( AUTH_KEY ) < 32 ) {
		$item( 'grave', 'As chaves de segurança (salts) do wp-config.php estão vazias ou no padrão.', 'Rode `wp config shuffle-salts`.' );
	} else {
		$item( 'ok', 'Chaves de segurança (salts) do wp-config.php preenchidas.' );
	}

	// Debug
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY ) ) {
		$item( 'grave', 'Erros do PHP aparecem na tela para o visitante (WP_DEBUG_DISPLAY).', "No wp-config.php: define( 'WP_DEBUG_DISPLAY', false );" );
	} else {
		$item( 'ok', 'Erros do PHP não aparecem para o visitante.' );
	}
	if ( file_exists( WP_CONTENT_DIR . '/debug.log' ) ) {
		$item( 'aviso', 'Existe wp-content/debug.log — é público por padrão e costuma ter caminho e dado sensível.', 'Apague, ou aponte WP_DEBUG_LOG para fora da pasta pública.' );
	} else {
		$item( 'ok', 'Sem wp-content/debug.log exposto.' );
	}

	// Arquivos que entregam a versão
	foreach ( array( 'readme.html', 'license.txt' ) as $arquivo ) {
		if ( file_exists( ABSPATH . $arquivo ) ) {
			$item( 'info', "{$arquivo} está na raiz e mostra a versão exata do WordPress.", 'Pode apagar (volta a cada atualização do core) ou bloquear no servidor — ver o LEIA-ME.' );
		} else {
			$item( 'ok', "{$arquivo} não está na raiz." );
		}
	}

	// wp-config legível por todos
	$config = file_exists( ABSPATH . 'wp-config.php' ) ? ABSPATH . 'wp-config.php' : dirname( ABSPATH ) . '/wp-config.php';
	if ( file_exists( $config ) && ( fileperms( $config ) & 0x0004 ) ) {
		$item( 'aviso', 'O wp-config.php pode ser lido por qualquer usuário do servidor (tem a senha do banco).', 'Permissão 640 ou 600: `chmod 640 wp-config.php`.' );
	} elseif ( file_exists( $config ) ) {
		$item( 'ok', sprintf( 'wp-config.php só é lido pelo dono (permissão %o).', fileperms( $config ) & 0777 ) );
	}

	// Prefixo das tabelas
	if ( 'wp_' === $wpdb->prefix ) {
		$item( 'info', 'As tabelas usam o prefixo padrão "wp_".', 'Só atrapalha ataque de SQL injection automatizado. Trocar num site pronto é trabalhoso — em site novo, use outro.' );
	} else {
		$item( 'ok', 'Tabelas com prefixo próprio ("' . $wpdb->prefix . '").' );
	}

	// Versão do PHP
	if ( version_compare( PHP_VERSION, '8.2', '<' ) ) {
		$item( 'aviso', 'PHP ' . PHP_VERSION . ' está fora do suporte de segurança ou perto disso.', 'Troque para PHP 8.3 ou mais novo no painel da hospedagem.' );
	} else {
		$item( 'ok', 'PHP ' . PHP_VERSION . '.' );
	}

	// Atualizações pendentes e código parado
	$core    = get_site_transient( 'update_core' );
	$plugins = get_site_transient( 'update_plugins' );
	$temas   = get_site_transient( 'update_themes' );
	$pendentes = count( (array) ( $plugins->response ?? array() ) ) + count( (array) ( $temas->response ?? array() ) );
	if ( ! empty( $core->updates[0]->response ) && 'upgrade' === $core->updates[0]->response ) {
		$item( 'grave', 'O WordPress tem atualização pendente.', 'Painel → Atualizações.' );
	} else {
		$item( 'ok', 'WordPress ' . get_bloginfo( 'version' ) . ' em dia.' );
	}
	if ( $pendentes ) {
		$item( 'aviso', "{$pendentes} plugin(s)/tema(s) com atualização pendente.", 'Painel → Atualizações. Desatualizado é a causa nº 1 de invasão.' );
	} else {
		$item( 'ok', 'Plugins e temas em dia.' );
	}

	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$inativos = array_diff( array_keys( get_plugins() ), (array) get_option( 'active_plugins', array() ) );
	if ( $inativos ) {
		$item( 'aviso', count( $inativos ) . ' plugin(s) instalado(s) e desativado(s): ' . implode( ', ', array_map( 'dirname', $inativos ) ) . '.', 'Plugin desativado continua no servidor e pode ser explorado direto pelo arquivo. Apague o que não usa.' );
	} else {
		$item( 'ok', 'Nenhum plugin desativado parado no servidor.' );
	}
	$temas_parados = array_diff( array_keys( wp_get_themes() ), array( get_stylesheet(), get_template() ) );
	if ( count( $temas_parados ) > 1 ) {
		$item( 'info', count( $temas_parados ) . ' temas sem uso: ' . implode( ', ', $temas_parados ) . '.', 'Deixe um tema padrão de reserva e apague o resto.' );
	} else {
		$item( 'ok', 'No máximo um tema de reserva além do ativo.' );
	}

	// Outro plugin de segurança junto
	$outros = array(
		'wordfence/wordfence.php'                                   => 'Wordfence',
		'better-wp-security/better-wp-security.php'                 => 'Solid Security (iThemes)',
		'all-in-one-wp-security-and-firewall/wp-security.php'       => 'All-In-One Security',
		'sucuri-scanner/sucuri.php'                                 => 'Sucuri',
		'limit-login-attempts-reloaded/limit-login-attempts-reloaded.php' => 'Limit Login Attempts Reloaded',
		'wp-cerber/wp-cerber.php'                                   => 'WP Cerber',
	);
	$ativos_seg = array();
	foreach ( $outros as $arquivo => $nome ) {
		if ( is_plugin_active( $arquivo ) ) {
			$ativos_seg[] = $nome;
		}
	}
	if ( $ativos_seg ) {
		$item( 'info', 'Outro plugin de segurança ativo: ' . implode( ', ', $ativos_seg ) . '.', 'Dá para usar junto (o firewall e a varredura por assinatura do Wordfence complementam a Blindagem), mas deixe UM limitador de login: desligue "Limitar tentativas de login" aqui ou o "Brute Force Protection" lá. 2FA também: um só.' );
	}

	// Plugins que não dá para conferir
	$sem = get_option( 'blindagem_sem_checksum', array() );
	if ( $sem ) {
		$item( 'info', 'Plugins sem checksum no wordpress.org (pagos ou próprios): ' . implode( ', ', $sem ) . '.', 'A integridade deles não é conferida; passam pela busca de código suspeito. Baixe sempre do site oficial do autor.' );
	} else {
		$item( 'ok', 'Todos os plugins têm checksum no wordpress.org (ou a integridade ainda não rodou).' );
	}

	// Cron do servidor (fora do WordPress)
	$item( 'info', 'Tarefas agendadas do SERVIDOR (cron do painel da hospedagem) não aparecem aqui.', 'Confira no painel da hospedagem (ex.: hPanel → Avançado → Cron Jobs) se não há comando que você não criou — malware também se reinstala por lá.' );

	// Cron
	if ( ! defined( 'DISABLE_WP_CRON' ) || ! DISABLE_WP_CRON ) {
		$item( 'info', 'As verificações automáticas dependem de visitas ao site (WP-Cron).', "Em produção, cron real: `*/15 * * * * php /caminho/wp-cron.php` e define( 'DISABLE_WP_CRON', true );" );
	} else {
		$item( 'ok', 'WP-Cron desligado nas visitas: tarefas rodam pelo cron do servidor.' );
	}

	// Servidor e uploads
	$software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '';
	// Sem SERVER_SOFTWARE (cron pelo terminal) não dá para saber: pula.
	if ( blindagem_ligado( 'upload_restrito' ) && $software && ! preg_match( '/apache|litespeed/i', $software ) ) {
		$item( 'aviso', 'O servidor (' . $software . ') não lê .htaccess: a trava de PHP em uploads/ não vale aqui.', 'nginx: `location ~* /wp-content/uploads/.*\.php$ { deny all; }`. As outras camadas de upload continuam valendo.' );
	} elseif ( blindagem_ligado( 'upload_restrito' ) ) {
		$item( 'ok', 'Servidor lê .htaccess: trava de PHP em uploads/ vale.' );
	}

	return $itens;
}

/**
 * Chave estável de um item: o título sem números, para "3 plugins" → "4 plugins"
 * não contar como problema novo.
 */
function blindagem_chave_diagnostico( $it ) {
	return md5( $it['nivel'] . preg_replace( '/\d+/', '#', $it['titulo'] ) );
}

/** Confere o diagnóstico e manda e-mail só com os problemas que surgiram desde a última vez. */
function blindagem_vigiar_diagnostico() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$problemas = array();
	foreach ( blindagem_diagnostico() as $it ) {
		if ( in_array( $it['nivel'], array( 'grave', 'aviso' ), true ) ) {
			$problemas[ blindagem_chave_diagnostico( $it ) ] = $it;
		}
	}

	$anteriores = get_option( 'blindagem_alertado_diagnostico', array() );
	$novos      = array_diff_key( $problemas, array_flip( (array) $anteriores ) );

	// Guarda o conjunto atual: problema resolvido que voltar alerta de novo.
	update_option( 'blindagem_alertado_diagnostico', array_keys( $problemas ), false );

	if ( ! $novos ) {
		return;
	}

	$linhas = array();
	foreach ( $novos as $it ) {
		$linhas[] = sprintf( '- [%s] %s', 'grave' === $it['nivel'] ? 'GRAVE' : 'ATENÇÃO', $it['titulo'] );
		if ( $it['como'] ) {
			$linhas[] = '  Como resolver: ' . $it['como'];
		}
	}

	wp_mail(
		blindagem_email_alerta(),
		sprintf( '[%s] Diagnóstico de segurança: %d problema(s) novo(s)', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), count( $novos ) ),
		sprintf(
			"Site: %s\n\n%s\n\n---\nLista completa: %s\nSó avisa problema novo; o mesmo não se repete amanhã.\n",
			home_url( '/' ),
			implode( "\n", $linhas ),
			admin_url( 'options-general.php?page=blindagem&aba=diagnostico' )
		)
	);
}

add_action( 'blindagem_varredura', function () {
	if ( blindagem_ligado( 'alerta_diagnostico' ) ) {
		blindagem_vigiar_diagnostico();
	}
} );
