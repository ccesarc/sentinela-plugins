<?php
/**
 * Sessões abertas: onde cada conta está logada agora (navegador, IP, desde
 * quando) e o botão para encerrar uma ou todas. Senha vazada ou cookie
 * roubado aparece aqui como sessão que você não reconhece.
 *
 * Lê o que o próprio WordPress guarda (user meta "session_tokens"). Se outro
 * plugin trocou o gerenciador de sessões, só "encerrar todas" funciona.
 */

defined( 'ABSPATH' ) || exit;

/** O WordPress está usando o gerenciador de sessões padrão (user meta)? */
function blindagem_sessoes_padrao() {
	return 'WP_User_Meta_Session_Tokens' === apply_filters( 'session_token_manager', 'WP_User_Meta_Session_Tokens' );
}

/** Mesmo cálculo do WordPress para a chave da sessão a partir do token. */
function blindagem_sessao_chave( $token ) {
	return function_exists( 'hash' ) ? hash( 'sha256', $token ) : sha1( $token );
}

/** Todas as sessões válidas: [user_id, chave, login, expira, ip, navegador]. */
function blindagem_sessoes() {
	global $wpdb;
	$linhas  = $wpdb->get_results( $wpdb->prepare( "SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = %s", 'session_tokens' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$sessoes = array();

	foreach ( $linhas as $linha ) {
		$tokens = maybe_unserialize( $linha->meta_value );
		if ( ! is_array( $tokens ) ) {
			continue;
		}
		foreach ( $tokens as $chave => $s ) {
			if ( ! is_array( $s ) || ( $s['expiration'] ?? 0 ) < time() ) {
				continue;
			}
			$sessoes[] = array(
				'user_id'   => (int) $linha->user_id,
				'chave'     => (string) $chave,
				'login'     => (int) ( $s['login'] ?? 0 ),
				'expira'    => (int) $s['expiration'],
				'ip'        => (string) ( $s['ip'] ?? '' ),
				'navegador' => blindagem_descrever_navegador( (string) ( $s['ua'] ?? '' ) ),
			);
		}
	}

	usort( $sessoes, fn( $a, $b ) => $b['login'] <=> $a['login'] );
	return $sessoes;
}

/** "Chrome · Windows" a partir do user-agent (aproximado, só para reconhecer). */
function blindagem_descrever_navegador( $ua ) {
	if ( '' === $ua ) {
		return 'desconhecido';
	}
	$navegadores = array( 'Edg/' => 'Edge', 'OPR/' => 'Opera', 'SamsungBrowser' => 'Samsung Internet', 'Firefox/' => 'Firefox', 'Chrome/' => 'Chrome', 'Safari/' => 'Safari', 'curl/' => 'curl (programa)', 'python' => 'Python (programa)', 'WordPress/' => 'WordPress (servidor)' );
	$sistemas    = array( 'Android' => 'Android', 'iPhone' => 'iPhone', 'iPad' => 'iPad', 'Windows' => 'Windows', 'Mac OS X' => 'Mac', 'CrOS' => 'Chromebook', 'Linux' => 'Linux' );
	$nav         = 'outro navegador';
	$so          = '';
	foreach ( $navegadores as $marca => $nome ) {
		if ( false !== stripos( $ua, $marca ) ) {
			$nav = $nome;
			break;
		}
	}
	foreach ( $sistemas as $marca => $nome ) {
		if ( false !== stripos( $ua, $marca ) ) {
			$so = $nome;
			break;
		}
	}
	return $so ? $nav . ' · ' . $so : $nav;
}

function blindagem_encerrar_sessao( $user_id, $chave ) {
	$tokens = get_user_meta( $user_id, 'session_tokens', true );
	if ( ! is_array( $tokens ) || ! isset( $tokens[ $chave ] ) ) {
		return 'Sessão não encontrada (talvez já tenha expirado).';
	}
	unset( $tokens[ $chave ] );
	$tokens ? update_user_meta( $user_id, 'session_tokens', $tokens ) : delete_user_meta( $user_id, 'session_tokens' );
	$usuario = get_userdata( $user_id );
	blindagem_registrar_evento( 'Sessão encerrada', $usuario ? $usuario->user_login : '#' . $user_id );
	return '';
}

add_action( 'admin_post_blindagem_sessao_encerrar', function () {
	blindagem_conferir_permissao( 'blindagem_sessao_encerrar' );
	$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
	$chave   = isset( $_POST['chave'] ) ? preg_replace( '/[^a-f0-9]/', '', sanitize_text_field( wp_unslash( $_POST['chave'] ) ) ) : '';
	if ( ! $user_id || ! current_user_can( 'edit_user', $user_id ) || ! blindagem_sessoes_padrao() ) {
		wp_die( 'Sem permissão.', 403 );
	}
	$erro = blindagem_encerrar_sessao( $user_id, $chave );
	if ( $erro ) {
		set_transient( 'blindagem_erro_' . get_current_user_id(), $erro, MINUTE_IN_SECONDS );
	}
	blindagem_voltar( 'sessoes', $erro ? 'acao_erro' : 'sessao_encerrada' );
} );

add_action( 'admin_post_blindagem_sessoes_encerrar_todas', function () {
	blindagem_conferir_permissao( 'blindagem_sessoes_encerrar_todas' );
	$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
	if ( ! $user_id || ! current_user_can( 'edit_user', $user_id ) ) {
		wp_die( 'Sem permissão.', 403 );
	}
	$gerente = WP_Session_Tokens::get_instance( $user_id );
	if ( get_current_user_id() === $user_id ) {
		$gerente->destroy_others( wp_get_session_token() ); // A sua, desta tela, continua.
	} else {
		$gerente->destroy_all();
	}
	$usuario = get_userdata( $user_id );
	blindagem_registrar_evento( 'Todas as sessões encerradas', $usuario ? $usuario->user_login : '#' . $user_id );
	blindagem_voltar( 'sessoes', 'sessoes_encerradas' );
} );

function blindagem_aba_sessoes() {
	$sessoes = blindagem_sessoes();
	$minha   = blindagem_sessao_chave( wp_get_session_token() );
	echo '<p>Onde cada conta está logada agora. Não reconhece uma sessão (navegador, lugar, horário)? Encerre e troque a senha dessa conta.</p>';

	if ( ! blindagem_sessoes_padrao() ) {
		echo '<p><em>Outro plugin controla as sessões neste site: a lista pode estar incompleta e só "Encerrar todas" funciona.</em></p>';
	}
	if ( ! $sessoes ) {
		echo '<p>Nenhuma sessão aberta.</p>';
		return;
	}

	echo '<table class="widefat striped"><thead><tr><th>Usuário</th><th>Navegador</th><th>IP</th><th>Entrou em</th><th>Expira em</th><th>Ação</th></tr></thead><tbody>';
	$usuarios = array();
	foreach ( $sessoes as $s ) {
		$usuario = get_userdata( $s['user_id'] );
		if ( ! $usuario ) {
			continue;
		}
		$usuarios[ $s['user_id'] ] = $usuario->user_login;
		$e_minha = $s['user_id'] === get_current_user_id() && hash_equals( $s['chave'], $minha );
		printf(
			'<tr><td>%s%s</td><td>%s</td><td><code>%s</code></td><td>%s</td><td>%s</td><td>',
			esc_html( $usuario->user_login ),
			in_array( 'administrator', (array) $usuario->roles, true ) ? ' <small>(admin)</small>' : '',
			esc_html( $s['navegador'] ),
			esc_html( $s['ip'] ),
			esc_html( wp_date( 'd/m/Y H:i', $s['login'] ) ),
			esc_html( wp_date( 'd/m/Y H:i', $s['expira'] ) )
		);
		if ( $e_minha ) {
			echo '<strong>esta é você</strong>';
		} elseif ( blindagem_sessoes_padrao() && current_user_can( 'edit_user', $s['user_id'] ) ) {
			blindagem_botao( 'blindagem_sessao_encerrar', 'Encerrar', 'button button-small', 'Encerrar esta sessão? A pessoa terá de entrar de novo.', array( 'user_id' => $s['user_id'], 'chave' => $s['chave'] ) );
		}
		echo '</td></tr>';
	}
	echo '</tbody></table><h2>Encerrar todas de uma conta</h2><p>';
	foreach ( $usuarios as $id => $login ) {
		if ( current_user_can( 'edit_user', $id ) ) {
			blindagem_botao(
				'blindagem_sessoes_encerrar_todas',
				get_current_user_id() === $id ? 'Encerrar minhas outras sessões' : 'Encerrar todas de ' . $login,
				'button',
				get_current_user_id() === $id ? 'Encerrar todas as suas sessões, menos esta?' : 'Encerrar todas as sessões de ' . $login . '?',
				array( 'user_id' => $id )
			);
		}
	}
	echo '</p>';
}
