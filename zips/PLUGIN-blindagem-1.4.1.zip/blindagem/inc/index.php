<?php
// Silêncio.
