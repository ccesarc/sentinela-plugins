<?php
/**
 * "Foto" dos arquivos que não têm original oficial para comparar.
 *
 * Core e plugins do wordpress.org são conferidos contra o original
 * (integridade). Mas temas, mu-plugins, drop-ins e plugins pagos/próprios
 * não têm checksum público — antes só passavam pela busca de código
 * suspeito. Aqui guardamos o hash e o tamanho de cada arquivo deles e, a
 * cada varredura, comparamos: arquivo NOVO, ALTERADO ou APAGADO vira achado.
 *
 * A primeira foto é tirada na primeira varredura (sem alarme). Atualização
 * de tema/plugin pelo painel refaz a foto daquela pasta sozinha; mudança fora
 * disso (FTP, invasão) aparece. Achado conferido e legítimo: "Reconhecer"
 * atualiza a foto daquele arquivo.
 */

defined( 'ABSPATH' ) || exit;

const BLINDAGEM_FOTO_MAX   = 30000; // Arquivos por foto: protege a memória em site enorme.
const BLINDAGEM_FOTO_GRUPO = 5;     // A partir de quantos arquivos limpos na mesma pasta de tema/plugin vira uma linha só.

/**
 * Pasta de tema/plugin (relativa) a que o arquivo pertence, ou '' — mu-plugins e arquivos soltos nunca
 * são agrupados: um arquivo novo ali já é motivo para olhar.
 */
function blindagem_foto_pasta_de( $relativo ) {
	return preg_match( '#^(.*?/(?:themes|plugins)/[^/]+)/#', $relativo, $m ) ? $m[1] : '';
}

/** Extensões que importam: código e o que muda comportamento do servidor. */
function blindagem_foto_extensao( $nome ) {
	return (bool) preg_match( '/\.(php\d?|phtml|pht|phar|inc|js|htaccess|user\.ini)$|^\.htaccess$|^\.user\.ini$/i', $nome );
}

/** Pastas fotografadas (caminho absoluto => rótulo). */
function blindagem_foto_pastas() {
	$pastas = array(
		wp_normalize_path( get_theme_root() ) => 'temas',
		wp_normalize_path( WPMU_PLUGIN_DIR )  => 'mu-plugins',
	);
	foreach ( blindagem_plugins_sem_checksum() as $pasta_plugin ) {
		$pastas[ wp_normalize_path( $pasta_plugin ) ] = 'plugin ' . basename( $pasta_plugin );
	}
	return $pastas;
}

/** Hash e tamanho de cada arquivo relevante nas pastas: [relativo => [md5, bytes]]. */
function blindagem_foto_calcular( $pastas = null ) {
	$todas    = null === $pastas;
	$pastas   = $todas ? array_keys( blindagem_foto_pastas() ) : (array) $pastas;
	$arquivos = array();

	foreach ( $pastas as $pasta ) {
		blindagem_percorrer( $pasta, function ( $arquivo ) use ( &$arquivos ) {
			if ( blindagem_foto_extensao( $arquivo->getFilename() ) ) {
				$caminho = $arquivo->getPathname();
				$arquivos[ blindagem_relativo( $caminho ) ] = array( (string) md5_file( $caminho ), (int) $arquivo->getSize() );
			}
			return count( $arquivos ) < BLINDAGEM_FOTO_MAX;
		} );
	}

	// Drop-ins e PHP solto na raiz de wp-content (só na foto completa).
	if ( $todas ) {
		foreach ( (array) glob( WP_CONTENT_DIR . '/*.php' ) as $caminho ) {
			$arquivos[ blindagem_relativo( $caminho ) ] = array( (string) md5_file( $caminho ), (int) filesize( $caminho ) );
		}
	}

	return $arquivos;
}

function blindagem_foto() {
	$foto = get_option( 'blindagem_foto' );
	return is_array( $foto ) && isset( $foto['arquivos'] ) ? $foto : null;
}

function blindagem_foto_salvar( $arquivos ) {
	update_option( 'blindagem_foto', array( 'quando' => current_time( 'mysql' ), 'arquivos' => $arquivos ), false );
}

/**
 * Compara o disco com a foto e devolve os achados. Sem foto ainda: tira a
 * primeira e não acusa nada (devolve a observação para o relatório).
 */
function blindagem_foto_comparar( &$observacao = '' ) {
	$atual = blindagem_foto_calcular();
	$foto  = blindagem_foto();

	if ( ! $foto ) {
		blindagem_foto_salvar( $atual );
		$observacao = sprintf( 'Foto inicial dos temas e plugins sem original oficial tirada agora (%d arquivos). A partir da próxima varredura, arquivo novo, alterado ou apagado nessas pastas aparece aqui.', count( $atual ) );
		return array();
	}

	$achados = array();
	$antes   = $foto['arquivos'];
	$limpos  = array(); // Pasta de tema/plugin => achados sem código suspeito (candidatos a virar uma linha só).

	foreach ( $atual as $relativo => [ $md5, $bytes ] ) {
		$caminho = blindagem_absoluto_relativo( $relativo );
		if ( ! isset( $antes[ $relativo ] ) ) {
			$codigo    = blindagem_codigo_suspeito( $caminho );
			$evidencia = trim( blindagem_dados_arquivo( $caminho ) . '. ' . $codigo, '. ' );
			$achado    = array( 'foto_novo', $caminho, $md5, $evidencia );
		} elseif ( $antes[ $relativo ][0] !== $md5 ) {
			$codigo    = blindagem_codigo_suspeito( $caminho );
			$evidencia = sprintf( 'tamanho %s → %s, modificado em %s', size_format( $antes[ $relativo ][1] ), size_format( $bytes ), wp_date( 'd/m/Y H:i', (int) filemtime( $caminho ) ) ) . ( $codigo ? '. ' . $codigo : '' );
			$achado    = array( 'foto_alterado', $caminho, $md5, $evidencia );
		} else {
			continue;
		}
		$pasta = blindagem_foto_pasta_de( $relativo );
		if ( ! $codigo && $pasta ) {
			$limpos[ $pasta ][ $relativo ] = $achado;
		} else {
			$achados[] = $achado;
		}
	}

	// Tema/plugin removido inteiro (pasta não existe mais) não é invasão: sai da foto com uma linha só de aviso,
	// em vez de um achado por arquivo (o tema da Hostinger dava ~180).
	$removidas = array();
	// Plugin que deixou de ser fotografado com a pasta ainda no lugar: passou a ter original no wordpress.org
	// (versão nova do Elementor ganha checksum dias depois — dava 2693 "apagados" na Onix) ou a lista de plugins
	// sem original era de antes de ele ser reenviado. Sai da foto calado: a integridade confere ele agora.
	$fotografadas = array();
	foreach ( array_keys( blindagem_foto_pastas() ) as $pasta ) {
		$fotografadas[ untrailingslashit( blindagem_relativo( $pasta ) ) ] = true;
	}
	$fora = 0;
	foreach ( $antes as $relativo => [ $md5, $bytes ] ) {
		if ( isset( $atual[ $relativo ] ) ) {
			continue;
		}
		if ( preg_match( '#^(.*?/(?:themes|plugins|mu-plugins)/[^/]+)/#', $relativo, $m ) && ! is_dir( blindagem_absoluto_relativo( $m[1] ) ) ) {
			$removidas[ $m[1] ] = ( $removidas[ $m[1] ] ?? 0 ) + 1;
			unset( $antes[ $relativo ] );
			continue;
		}
		if ( preg_match( '#^(.*?/plugins/[^/]+)/#', $relativo, $m ) && ! isset( $fotografadas[ $m[1] ] ) ) {
			unset( $antes[ $relativo ] );
			++$fora;
			continue;
		}
		$achado = array( 'foto_apagado', blindagem_absoluto_relativo( $relativo ), 'apagado', 'tinha ' . size_format( $bytes ) . ' na foto de ' . mysql2date( 'd/m/Y H:i', $foto['quando'] ) );
		$pasta  = blindagem_foto_pasta_de( $relativo );
		if ( $pasta ) {
			$limpos[ $pasta ][ $relativo ] = $achado;
		} else {
			$achados[] = $achado;
		}
	}

	// Instalação ou atualização feita por fora do painel (envio de zip por cima, Hostinger Smart Auto Updates,
	// FTP) mexe em dezenas de arquivos de uma vez e dava uma linha para cada (200 no Perfil Portas). Pasta com
	// BLINDAGEM_FOTO_GRUPO ou mais arquivos limpos vira um achado só; arquivo com código suspeito sempre sai sozinho.
	// Pasta que não tinha nada na foto (plugin que acabou de entrar nela) agrupa a partir de 2 arquivos.
	$pastas_antes = array();
	foreach ( array_keys( $foto['arquivos'] ) as $relativo ) {
		$pastas_antes[ blindagem_foto_pasta_de( $relativo ) ] = true;
	}
	foreach ( $limpos as $pasta => $lista ) {
		if ( count( $lista ) < ( isset( $pastas_antes[ $pasta ] ) ? BLINDAGEM_FOTO_GRUPO : 2 ) ) {
			$achados = array_merge( $achados, array_values( $lista ) );
			continue;
		}
		ksort( $lista );
		$conta  = array( 'foto_novo' => 0, 'foto_alterado' => 0, 'foto_apagado' => 0 );
		$hashes = array();
		foreach ( $lista as $relativo => $a ) {
			++$conta[ $a[0] ];
			$hashes[] = $relativo . ':' . $a[2];
		}
		$nomes     = array_map( function ( $r ) use ( $pasta ) { return substr( $r, strlen( $pasta ) + 1 ); }, array_slice( array_keys( $lista ), 0, 5 ) );
		$achados[] = array(
			'foto_pasta',
			blindagem_absoluto_relativo( $pasta ),
			md5( implode( '|', $hashes ) ),
			sprintf(
				'%d arquivo(s) novo(s), %d alterado(s) e %d apagado(s), nenhum com código suspeito (ex.: %s%s)',
				$conta['foto_novo'],
				$conta['foto_alterado'],
				$conta['foto_apagado'],
				implode( ', ', $nomes ),
				count( $lista ) > 5 ? '…' : ''
			),
		);
	}
	if ( $fora && ! $removidas ) {
		blindagem_foto_salvar( $antes );
	}
	if ( $removidas ) {
		blindagem_foto_salvar( $antes );
		$partes = array();
		foreach ( $removidas as $pasta => $qtd ) {
			$partes[] = basename( $pasta ) . ' (' . $qtd . ' arquivos)';
		}
		$observacao = trim( $observacao . ' Removido(s) por inteiro e tirado(s) da foto: ' . implode( ', ', $partes ) . '.' );
	}

	return array_slice( $achados, 0, 200 );
}

/** Caminho absoluto a partir do relativo guardado (relativo à raiz do WordPress). */
function blindagem_absoluto_relativo( $relativo ) {
	return path_is_absolute( $relativo ) ? $relativo : ABSPATH . $relativo;
}

/** Atualiza a foto só de algumas pastas (ou de um arquivo), mantendo o resto. */
function blindagem_foto_atualizar_pastas( $pastas ) {
	$foto = blindagem_foto();
	if ( ! $foto ) {
		return;
	}
	$arquivos = $foto['arquivos'];
	foreach ( $pastas as $pasta ) {
		$prefixo = blindagem_relativo( trailingslashit( wp_normalize_path( $pasta ) ) );
		foreach ( array_keys( $arquivos ) as $relativo ) {
			if ( 0 === strpos( $relativo, $prefixo ) ) {
				unset( $arquivos[ $relativo ] );
			}
		}
	}
	blindagem_foto_salvar( array_merge( $arquivos, blindagem_foto_calcular( $pastas ) ) );
}

function blindagem_foto_aceitar_arquivo( $relativo ) {
	$foto = blindagem_foto();
	if ( ! $foto ) {
		return;
	}
	$caminho = blindagem_absoluto_relativo( $relativo );
	if ( is_dir( $caminho ) ) {
		// Achado 'foto_pasta': aceita a pasta como está, MENOS arquivo com código suspeito — esse nunca entrou na
		// linha agrupada e continua acusando sozinho (fica na foto como estava antes, ou fora dela se era novo).
		$prefixo = blindagem_relativo( trailingslashit( wp_normalize_path( $caminho ) ) );
		$antes   = $foto['arquivos'];
		foreach ( array_keys( $foto['arquivos'] ) as $r ) {
			if ( 0 === strpos( $r, $prefixo ) ) {
				unset( $foto['arquivos'][ $r ] );
			}
		}
		foreach ( blindagem_foto_calcular( array( $caminho ) ) as $r => $dados ) {
			if ( ! blindagem_codigo_suspeito( blindagem_absoluto_relativo( $r ) ) ) {
				$foto['arquivos'][ $r ] = $dados;
			} elseif ( isset( $antes[ $r ] ) ) {
				$foto['arquivos'][ $r ] = $antes[ $r ];
			}
		}
		blindagem_foto_salvar( $foto['arquivos'] );
		return;
	}
	if ( is_file( $caminho ) ) {
		$foto['arquivos'][ $relativo ] = array( (string) md5_file( $caminho ), (int) filesize( $caminho ) );
	} else {
		unset( $foto['arquivos'][ $relativo ] );
	}
	blindagem_foto_salvar( $foto['arquivos'] );
}

/*
 * Atualização legítima pelo painel: refaz a foto da pasta atualizada, para
 * não acusar como invasão o update de um tema ou plugin.
 */
add_action( 'upgrader_process_complete', function ( $upgrader, $extra ) {
	if ( empty( $extra['type'] ) || ! blindagem_foto() ) {
		return;
	}
	$pastas = array();
	if ( 'plugin' === $extra['type'] ) {
		$lista = ! empty( $extra['plugins'] ) ? (array) $extra['plugins'] : array();
		if ( ! $lista && is_object( $upgrader ) && method_exists( $upgrader, 'plugin_info' ) && $upgrader->plugin_info() ) {
			$lista = array( $upgrader->plugin_info() );
		}
		foreach ( $lista as $arquivo ) {
			if ( dirname( $arquivo ) !== '.' ) {
				$pastas[] = WP_PLUGIN_DIR . '/' . dirname( $arquivo );
			}
		}
	} elseif ( 'theme' === $extra['type'] ) {
		$lista = ! empty( $extra['themes'] ) ? (array) $extra['themes'] : array();
		if ( ! $lista && is_object( $upgrader ) && method_exists( $upgrader, 'theme_info' ) && $upgrader->theme_info() ) {
			$lista = array( $upgrader->theme_info()->get_stylesheet() );
		}
		foreach ( $lista as $tema ) {
			$pastas[] = get_theme_root() . '/' . $tema;
		}
	}
	if ( $pastas ) {
		blindagem_foto_atualizar_pastas( $pastas );
		if ( function_exists( 'blindagem_registrar_evento' ) ) {
			blindagem_registrar_evento( 'Foto atualizada', 'depois da atualização: ' . implode( ', ', array_map( 'basename', $pastas ) ) );
		}
	}
}, 20, 2 );
