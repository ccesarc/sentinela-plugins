<?php
/**
 * Registro de eventos e vigia de opções críticas.
 *
 * Registro: o que mudou no site e quem mudou — plugin instalado, ativado,
 * desativado ou apagado; tema trocado; usuário criado, apagado, com papel ou
 * e-mail alterado; opção crítica alterada. É o que responde "o que
 * aconteceu?" depois de um susto. Últimos 300, numa opção (sem tabela nova).
 *
 * Opções críticas: o ataque típico a plugin vulnerável não sobe arquivo —
 * muda users_can_register + default_role para criar um admin, ou troca o
 * admin_email/siteurl. Mudança nelas vira e-mail na hora; papel padrão
 * "administrador" é recusado.
 */

defined( 'ABSPATH' ) || exit;

/** Opções que nenhum uso normal do site muda sem o dono saber. */
function blindagem_opcoes_criticas() {
	return array(
		'siteurl'            => 'Endereço do WordPress (siteurl)',
		'home'               => 'Endereço do site (home)',
		'admin_email'        => 'E-mail do administrador',
		'users_can_register' => 'Qualquer pessoa pode se registrar',
		'default_role'       => 'Função padrão de usuário novo',
	);
}

function blindagem_registrar_evento( $evento, $detalhe ) {
	if ( ! blindagem_ligado( 'registro_eventos' ) ) {
		return;
	}

	$log = get_option( 'blindagem_eventos', array() );
	$log = is_array( $log ) ? $log : array();

	$quem = wp_get_current_user();
	if ( $quem->exists() ) {
		$quem = $quem->user_login;
	} elseif ( defined( 'WP_CLI' ) && WP_CLI ) {
		$quem = '(terminal / wp-cli)';
	} elseif ( wp_doing_cron() ) {
		$quem = '(tarefa agendada)';
	} else {
		$quem = '(ninguém logado)';
	}

	array_unshift( $log, array(
		'quando'  => current_time( 'mysql' ),
		'evento'  => $evento,
		'detalhe' => mb_substr( wp_strip_all_tags( (string) $detalhe ), 0, 300 ),
		'quem'    => $quem,
		'ip'      => blindagem_ip(),
	) );

	update_option( 'blindagem_eventos', array_slice( $log, 0, 300 ), false );
}

/** Nome legível do plugin a partir de "pasta/arquivo.php". */
function blindagem_nome_plugin( $arquivo ) {
	$caminho = WP_PLUGIN_DIR . '/' . $arquivo;
	if ( is_readable( $caminho ) ) {
		$dados = get_file_data( $caminho, array( 'nome' => 'Plugin Name' ) );
		if ( $dados['nome'] ) {
			return $dados['nome'] . ' (' . $arquivo . ')';
		}
	}
	return $arquivo;
}


/* ==========================================================================
   Plugins e temas
   ========================================================================== */

add_action( 'activated_plugin', function ( $arquivo ) {
	blindagem_registrar_evento( 'Plugin ativado', blindagem_nome_plugin( $arquivo ) );
} );

add_action( 'deactivated_plugin', function ( $arquivo ) {
	blindagem_registrar_evento( 'Plugin desativado', blindagem_nome_plugin( $arquivo ) );
} );

add_action( 'deleted_plugin', function ( $arquivo, $apagou ) {
	if ( $apagou ) {
		blindagem_registrar_evento( 'Plugin apagado', $arquivo );
	}
}, 10, 2 );

add_action( 'upgrader_process_complete', function ( $upgrader, $extra ) {
	if ( empty( $extra['type'] ) || empty( $extra['action'] ) ) {
		return;
	}

	$acao = 'install' === $extra['action'] ? 'instalado' : 'atualizado';

	if ( 'plugin' === $extra['type'] ) {
		$lista = ! empty( $extra['plugins'] ) ? (array) $extra['plugins'] : array();
		if ( ! $lista && 'install' === $extra['action'] && is_object( $upgrader ) && method_exists( $upgrader, 'plugin_info' ) ) {
			$lista = array_filter( array( $upgrader->plugin_info() ) );
		}
		foreach ( $lista as $arquivo ) {
			blindagem_registrar_evento( 'Plugin ' . $acao, blindagem_nome_plugin( $arquivo ) );
		}
	} elseif ( 'theme' === $extra['type'] ) {
		$lista = ! empty( $extra['themes'] ) ? (array) $extra['themes'] : array();
		if ( ! $lista && is_object( $upgrader ) && method_exists( $upgrader, 'theme_info' ) && $upgrader->theme_info() ) {
			$lista = array( $upgrader->theme_info()->get_stylesheet() );
		}
		foreach ( $lista as $tema ) {
			blindagem_registrar_evento( 'Tema ' . $acao, $tema );
		}
	} elseif ( 'core' === $extra['type'] ) {
		blindagem_registrar_evento( 'WordPress atualizado', 'versão ' . get_bloginfo( 'version' ) );
	}
}, 10, 2 );

add_action( 'switch_theme', function ( $nome ) {
	blindagem_registrar_evento( 'Tema trocado', $nome );
} );


/* ==========================================================================
   Usuários
   ========================================================================== */

add_action( 'user_register', function ( $user_id ) {
	$usuario = get_userdata( $user_id );
	if ( $usuario ) {
		blindagem_registrar_evento( 'Usuário criado', sprintf( '%s <%s> — %s', $usuario->user_login, $usuario->user_email, implode( ', ', $usuario->roles ) ) );
	}
} );

add_action( 'delete_user', function ( $user_id ) {
	$usuario = get_userdata( $user_id );
	if ( $usuario ) {
		blindagem_registrar_evento( 'Usuário apagado', $usuario->user_login );
	}
} );

add_action( 'set_user_role', function ( $user_id, $papel, $antigos ) {
	$usuario = get_userdata( $user_id );
	// Na criação o papel é definido também; o "Usuário criado" já conta.
	if ( $usuario && $antigos ) {
		blindagem_registrar_evento( 'Papel alterado', sprintf( '%s: %s → %s', $usuario->user_login, implode( ', ', (array) $antigos ), $papel ) );
	}
}, 10, 3 );

// E-mail trocado é o primeiro passo para tomar a conta pelo "esqueci a senha".
add_action( 'profile_update', function ( $user_id, $antes ) {
	$depois = get_userdata( $user_id );
	if ( $depois && $antes instanceof WP_User && $antes->user_email !== $depois->user_email ) {
		blindagem_registrar_evento( 'E-mail de usuário alterado', sprintf( '%s: %s → %s', $depois->user_login, $antes->user_email, $depois->user_email ) );
	}
}, 10, 2 );


/* ==========================================================================
   Opções críticas
   ========================================================================== */

/** Papel padrão "administrador" é sempre recusado: não existe uso legítimo. */
add_filter( 'pre_update_option_default_role', function ( $novo, $antigo ) {
	if ( ! blindagem_ligado( 'trava_papel_padrao' ) || 'administrator' !== $novo ) {
		return $novo;
	}

	blindagem_registrar_evento( 'BLOQUEADO', 'Tentativa de tornar "administrador" a função padrão de usuário novo' );
	blindagem_alertar_opcao( 'default_role', $antigo, 'administrator (BLOQUEADO — continua ' . $antigo . ')' );

	return $antigo;
}, 10, 2 );

foreach ( array_keys( blindagem_opcoes_criticas() ) as $blindagem_opcao_critica ) {
	add_action( 'update_option_' . $blindagem_opcao_critica, function ( $antigo, $novo, $opcao ) {
		if ( (string) $antigo === (string) $novo ) {
			return;
		}
		blindagem_registrar_evento( 'Opção crítica alterada', sprintf( '%s: "%s" → "%s"', blindagem_opcoes_criticas()[ $opcao ], $antigo, $novo ) );
		blindagem_alertar_opcao( $opcao, $antigo, $novo );
	}, 10, 3 );
}

function blindagem_alertar_opcao( $opcao, $antigo, $novo ) {
	if ( ! blindagem_ligado( 'alerta_opcoes' ) ) {
		return;
	}

	$quem = is_user_logged_in() ? wp_get_current_user()->user_login : '(ninguém logado — suspeito)';

	wp_mail(
		blindagem_email_alerta(),
		sprintf( '[%s] ALERTA: configuração crítica alterada', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
		sprintf(
			"No site %s mudou:\n\n%s\nAntes......: %s\nDepois.....: %s\nQuem fez...: %s\nIP.........: %s\nQuando.....: %s\n\n" .
			"Se não foi você, é sinal de invasão por plugin vulnerável: confira os usuários\n" .
			"administradores, atualize todos os plugins e veja Configurações → Blindagem → Eventos.\n",
			home_url( '/' ),
			blindagem_opcoes_criticas()[ $opcao ] ?? $opcao,
			is_scalar( $antigo ) ? $antigo : wp_json_encode( $antigo ),
			is_scalar( $novo ) ? $novo : wp_json_encode( $novo ),
			$quem,
			blindagem_ip(),
			current_time( 'd/m/Y H:i:s' )
		)
	);
}
