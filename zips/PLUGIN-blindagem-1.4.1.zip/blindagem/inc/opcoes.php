<?php
/**
 * Opções do plugin: valores padrão, leitura e o IP de quem faz a requisição.
 *
 * Tudo fica numa opção só (blindagem_opcoes). O padrão é o mais seguro que
 * não quebra um site comum — o que pode atrapalhar algum site específico
 * (comentários, página de autor, atualização automática) desliga no painel.
 */

defined( 'ABSPATH' ) || exit;

/** Checkboxes — a lista também serve para a sanitização saber o que é 0/1. */
function blindagem_padroes_seguranca() {
	return array(
		'limite_login'    => 1,
		'enumeracao'      => 1,
		'xmlrpc_off'      => 1,
		'cabecalhos'      => 1,
		'hsts'            => 1,
		'esconder_versao' => 1,
		'comentarios_off' => 1,
		'registro_off'    => 1,
		'alerta_admin'    => 1,
		'upload_restrito' => 1,
		'autoupdate'      => 1,
		'varredura'       => 1,
		'integridade'     => 1,
		'alerta_diagnostico' => 1,
		'atras_de_proxy'  => 0,
		'limite_senha'    => 1,
		'senha_forte'     => 1,
		'app_passwords'   => 1,
		'sessao_curta'    => 1,
		'rest_privada'    => 0,
		'registro_acesso' => 1,
		'codigo_suspeito' => 1,
		'dois_fatores'    => 0,
		'registro_eventos'   => 1,
		'alerta_opcoes'      => 1,
		'trava_papel_padrao' => 1,
		'comentarios_antispam' => 1,
		'foto'                 => 1,
		'trava_admin'          => 1,
		'vigia_mu'             => 1,
		'quarentena_auto'      => 1,
		'quarentena_expira'    => 1,
	);
}

function blindagem_padroes() {
	return array_merge(
		blindagem_padroes_seguranca(),
		array(
			'tentativas'     => 5,
			'minutos'        => 15,
			'email_alerta'   => '',
		)
	);
}

function blindagem_opcoes() {
	return wp_parse_args( (array) get_option( 'blindagem_opcoes', array() ), blindagem_padroes() );
}

function blindagem_opcao( $chave ) {
	$opcoes = blindagem_opcoes();
	return isset( $opcoes[ $chave ] ) ? $opcoes[ $chave ] : null;
}

function blindagem_ligado( $chave ) {
	return ! empty( blindagem_opcao( $chave ) );
}

/** Para onde vão os alertas: o e-mail do painel ou, se vazio, o do admin do site. */
function blindagem_email_alerta() {
	$email = blindagem_opcao( 'email_alerta' );
	return is_email( $email ) ? $email : get_option( 'admin_email' );
}

/**
 * IP de quem está batendo, ou '' se não der para saber.
 *
 * Padrão: REMOTE_ADDR, que não dá para forjar. Atrás de CDN/proxy
 * (Cloudflare, CDN da hospedagem) o REMOTE_ADDR é o IP da borda — aí o
 * limite de login trancaria todo mundo junto. Para esses sites existe a opção
 * "atrás de proxy", que lê o cabeçalho do CDN. Só ligue se o site estiver
 * mesmo atrás de um: quem fala direto com o servidor forja esse cabeçalho.
 */
function blindagem_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';

	if ( blindagem_ligado( 'atras_de_proxy' ) ) {
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$ip = wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] );
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			/*
			 * O ÚLTIMO da lista: é o que o nosso proxy acrescentou, o IP de
			 * quem falou com ele. Os anteriores vêm do próprio visitante e são
			 * forjáveis — usar o primeiro deixava o atacante trocar de "IP" a
			 * cada tentativa e passar por cima do limite de login.
			 */
			$lista = explode( ',', wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
			$ip    = trim( end( $lista ) );
		}
	}

	$ip = filter_var( $ip, FILTER_VALIDATE_IP );

	return $ip ? $ip : '';
}
