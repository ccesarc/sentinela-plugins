<?php
/**
 * Lições do surto bright-backup-dot (2026-10, docs/INCIDENTES.md do Sentinela):
 *
 * - Admin criado por código (robô, tarefa agendada, backdoor) vira assinante na hora.
 * - mu-plugins/ conferido a cada 5 minutos, não só na varredura diária.
 * - O que é assinatura conhecida do vírus vai sozinho para a quarentena (dá para restaurar).
 * - A quarentena se limpa: 30 dias (7 para o que entrou sozinho).
 *
 * Os nomes do vírus são cópia de packages/checks/src/wordpress/indicadores.ts do Sentinela.
 */

defined( 'ABSPATH' ) || exit;

/** Pastas falsas em plugins/ e mu-plugins do surto (sem extensão). */
function blindagem_ioc_nomes() {
	return array(
		'bright-backup-dot', 'turbo-builder-dex', 'vivid-generator-go', 'haven-guard-edge', 'pure-router-dot',
		'byte-importer-go', 'cipher-dispatcher-io', 'crisp-compiler-jet', 'prime-proxy-edge', 'smart-launcher-rig',
		'ace-cache-plus', 'byte-profiler-ops', 'retro-optimizer-tag', 'echo-handler-fix', 'rapid-panel-edge',
		'onyx-patcher-dot', 'ultra-updater-lab', 'index-launcher-fix', 'lucid-renderer-tag', 'seo-monitor-tag',
		'byte-generator-live', 'smart-collector-box', 'swift-curator-snap', 'crux-scheduler-rig', 'ionic-agent-box',
	);
}

/** Nome do vírus: lista exata (para a quarentena automática) ou também o padrão do nome (para avisar). */
function blindagem_ioc_nome( $nome, $so_lista = false ) {
	$n = strtolower( preg_replace( '/\.php$/i', '', (string) $nome ) );
	if ( in_array( $n, blindagem_ioc_nomes(), true ) ) {
		return true;
	}
	return ! $so_lista && (bool) preg_match( '/^[a-z]{3,10}-[a-z]{3,12}-(dot|dex|go|edge|io|jet|rig|plus|ops|tag|fix|lab|live|box|snap|hub|kit|pro|net)$/', $n );
}

/** Marcadores escondidos (.gk_<hex>, .rd_<nome>…), `.<hex8>.php` e `.wp-object-cache-<hex>.dat`. */
function blindagem_ioc_escondido( $nome ) {
	return (bool) preg_match( '/^\.(?:(?:gk|kk|sc|rd|pv|bt|sd|swm)_[\w-]+|[0-9a-f]{8}\.php|wp-object-cache-[0-9a-f]+\.dat(?:\.lkg)?)$/i', basename( (string) $nome ) );
}

/** Achado da varredura que é assinatura conhecida (vai sozinho para a quarentena). */
function blindagem_ioc_achado( $achado ) {
	$arquivo = (string) $achado['arquivo'];
	if ( 0 === strpos( $arquivo, 'b64:' ) ) {
		return false; // nome com bytes inválidos: o dono decide
	}
	switch ( $achado['tipo'] ) {
		case 'mu_plugin':
		case 'plugin_casca':
			return blindagem_ioc_nome( basename( $arquivo ), true );
		case 'escondido':
			return blindagem_ioc_escondido( $arquivo );
		case 'compactado':
			return (bool) preg_match( '/^[0-9a-f]{8}\.zip$/i', basename( $arquivo ) );
	}
	return false;
}


/* ==========================================================================
   Admin criado por código vira assinante
   --------------------------------------------------------------------------
   No surto, o invasor criou "adm_<hex>" sem ninguém logado. Vale como admin só quem foi promovido por
   outro admin logado numa tela de usuários do wp-admin, por WP-CLI ou na instalação. O resto vira
   assinante, fica registrado e manda e-mail; um admin de verdade promove de novo pelo painel.
   ========================================================================== */

function blindagem_promocao_legitima() {
	if ( ( defined( 'WP_CLI' ) && WP_CLI ) || wp_installing() ) {
		return true;
	}
	global $pagenow;
	$telas = array( 'user-new.php', 'user-edit.php', 'users.php', 'profile.php' );
	return is_admin() && ! wp_doing_ajax() && ! wp_doing_cron() && in_array( $pagenow, $telas, true )
		&& 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && current_user_can( 'promote_users' );
}

function blindagem_travar_admin( $user_id, $papel ) {
	static $rebaixando = false;
	if ( $rebaixando || 'administrator' !== $papel || ! blindagem_ligado( 'trava_admin' ) || ( defined( 'BLINDAGEM_MODO_SEGURO' ) && BLINDAGEM_MODO_SEGURO ) || blindagem_promocao_legitima() ) {
		return;
	}
	$usuario = get_userdata( $user_id );
	if ( ! $usuario ) {
		return;
	}
	$rebaixando = true;
	$usuario->set_role( 'subscriber' );
	$rebaixando = false;
	blindagem_registrar_evento( 'Admin criado fora do painel — rebaixado a assinante', $usuario->user_login );
	wp_mail(
		blindagem_email_alerta(),
		sprintf( '[%s] ALERTA: tentaram criar um administrador', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
		sprintf(
			"O usuário \"%s\" ia virar administrador em %s sem ninguém promover pelo painel (robô, tarefa agendada ou backdoor).\n" .
			"O Blindagem rebaixou para assinante.\n\nIP: %s\nQuando: %s\n\n" .
			"Se foi você (ex.: plugin de migração), promova de novo em Usuários. Se não foi: apague o usuário, troque as senhas\n" .
			"e rode Verificar agora em Configurações → Blindagem.\n",
			$usuario->user_login,
			home_url( '/' ),
			blindagem_ip(),
			current_time( 'd/m/Y H:i:s' )
		)
	);
}

add_action( 'set_user_role', function ( $user_id, $papel, $antigos ) {
	if ( ! in_array( 'administrator', (array) $antigos, true ) ) {
		blindagem_travar_admin( $user_id, $papel );
	}
}, 5, 3 );
add_action( 'add_user_role', function ( $user_id, $papel ) {
	blindagem_travar_admin( $user_id, $papel );
}, 5, 2 );
add_action( 'user_register', function ( $user_id ) {
	$u = get_userdata( $user_id );
	if ( $u && in_array( 'administrator', (array) $u->roles, true ) ) {
		blindagem_travar_admin( $user_id, 'administrator' );
	}
}, 5 );


/* ==========================================================================
   mu-plugins/ a cada 5 minutos
   --------------------------------------------------------------------------
   mu-plugin roda em toda página e é onde o vírus morava. Conferir só na varredura diária deixava um
   dia de folga. Aqui: nomes e tamanhos (barato), no máximo uma vez a cada 5 minutos.
   ========================================================================== */

add_action( 'init', function () {
	if ( ! blindagem_ligado( 'vigia_mu' ) || get_transient( 'blindagem_mu_conferido' ) ) {
		return;
	}
	set_transient( 'blindagem_mu_conferido', 1, 5 * MINUTE_IN_SECONDS );

	$atual = array();
	foreach ( (array) glob( WPMU_PLUGIN_DIR . '/*.php' ) as $abs ) {
		$atual[ basename( $abs ) ] = (int) @filesize( $abs ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
	$antes = get_option( 'blindagem_mu_lista' );
	update_option( 'blindagem_mu_lista', $atual, false );
	if ( ! is_array( $antes ) ) {
		return; // primeira vez: só guarda
	}
	$novos = array_diff_key( $atual, $antes );
	foreach ( $atual as $nome => $tam ) {
		if ( isset( $antes[ $nome ] ) && $antes[ $nome ] !== $tam ) {
			$novos[ $nome ] = $tam;
		}
	}
	if ( ! $novos ) {
		return;
	}
	$linhas = array();
	foreach ( $novos as $nome => $tam ) {
		$virus    = blindagem_ioc_nome( $nome );
		$linhas[] = sprintf( '- mu-plugins/%s (%s)%s', $nome, size_format( $tam ), $virus ? ' — NOME DO VÍRUS bright-backup-dot' : '' );
		blindagem_registrar_evento( $virus ? 'mu-plugin do vírus apareceu' : 'mu-plugin novo ou alterado', 'mu-plugins/' . $nome );
	}
	wp_mail(
		blindagem_email_alerta(),
		sprintf( '[%s] ALERTA: mu-plugin novo ou alterado', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
		sprintf(
			"Em %s:\n\n%s\n\nmu-plugin roda em TODA página e não aparece em Plugins. Se não foi você nem a hospedagem,\n" .
			"abra Configurações → Blindagem → Verificar agora e ponha em quarentena.\n\n%s\n",
			home_url( '/' ),
			implode( "\n", $linhas ),
			admin_url( 'options-general.php?page=blindagem&aba=verificacao' )
		)
	);
	// Assinatura conhecida: não espera a varredura do dia seguinte.
	if ( blindagem_ligado( 'quarentena_auto' ) && array_filter( array_keys( $novos ), function ( $n ) {
		return blindagem_ioc_nome( $n, true );
	} ) && ! wp_next_scheduled( 'blindagem_varredura_ja' ) ) {
		wp_schedule_single_event( time() + 30, 'blindagem_varredura_ja' );
	}
} );

add_action( 'blindagem_varredura_ja', function () {
	blindagem_rodar( 'varredura' );
} );


/* ==========================================================================
   Quarentena automática e limpeza da quarentena
   ========================================================================== */

/** Chamado no fim da varredura: assinaturas conhecidas vão para a quarentena sozinhas. */
function blindagem_quarentena_automatica( $achados ) {
	if ( ! blindagem_ligado( 'quarentena_auto' ) ) {
		return 0;
	}
	require_once __DIR__ . '/quarentena.php';
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$movidos = array();
	foreach ( $achados as $achado ) {
		if ( blindagem_ioc_achado( $achado ) && '' === blindagem_por_em_quarentena( $achado['arquivo'] ) ) {
			$movidos[] = $achado['arquivo'];
		}
	}
	if ( ! $movidos ) {
		return 0;
	}
	// Marca o que entrou sozinho (limpa em 7 dias).
	$lista = blindagem_quarentena_lista();
	foreach ( $lista as $id => $item ) {
		if ( in_array( $item['original'], $movidos, true ) && empty( $item['auto'] ) ) {
			$lista[ $id ]['auto'] = true;
		}
	}
	update_option( 'blindagem_quarentena', $lista, false );
	blindagem_registrar_evento( 'Quarentena automática (assinatura do vírus)', implode( ', ', array_slice( $movidos, 0, 10 ) ) );
	wp_mail(
		blindagem_email_alerta(),
		sprintf( '[%s] Blindagem pôs %d arquivo(s) do vírus em quarentena', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), count( $movidos ) ),
		sprintf(
			"Em %s, assinaturas conhecidas do vírus bright-backup-dot foram tiradas do lugar:\n\n- %s\n\n" .
			"Elas não rodam mais. Ficam 7 dias na quarentena (dá para restaurar) e depois são apagadas.\n" .
			"Vírus no site = alguém entrou: troque as senhas da hospedagem e dos administradores.\n\n%s\n",
			home_url( '/' ),
			implode( "\n- ", $movidos ),
			admin_url( 'options-general.php?page=blindagem&aba=verificacao' )
		)
	);
	return count( $movidos );
}

/** Apaga de vez o que está na quarentena há mais de 30 dias (7 se entrou sozinho). */
function blindagem_quarentena_expirar() {
	if ( ! blindagem_ligado( 'quarentena_expira' ) ) {
		return;
	}
	require_once __DIR__ . '/quarentena.php';
	$agora = current_time( 'timestamp' ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested -- 'quando' é hora local
	foreach ( blindagem_quarentena_lista() as $id => $item ) {
		$t = strtotime( (string) ( $item['quando'] ?? '' ) );
		if ( $t && $agora - $t > ( empty( $item['auto'] ) ? 30 : 7 ) * DAY_IN_SECONDS ) {
			blindagem_apagar_quarentena( $id );
		}
	}
}
