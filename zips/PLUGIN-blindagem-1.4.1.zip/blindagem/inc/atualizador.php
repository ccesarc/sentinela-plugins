<?php
/**
 * Atualização dos plugins da agência pelo próprio wp-admin (docs/DECISOES.md, 2026-10-21).
 *
 * Mesmo arquivo no Sentinela Agent (includes/) e no Blindagem (inc/) — o teste confere que são iguais.
 *
 * - O WordPress pergunta por atualização (filtro `update_plugins_<host>` do `Update URI`). Aqui se lê o
 *   `versoes.json` do repositório público de zips e se oferece a versão SÓ se a entrada estiver assinada
 *   (Ed25519) pela chave da agência. A chave pública fica abaixo; a privada, só no computador do dono.
 * - Ao clicar em "Atualizar" (`upgrader_pre_download`), o zip é baixado aqui, o SHA-256 conferido com o
 *   da entrada assinada e a assinatura conferida de novo. Não bateu = a atualização é recusada.
 * - Nada vem do painel Sentinela. Atualização automática do WordPress fica desligada para estes plugins.
 * - Versão menor ou igual à instalada nunca é oferecida (sem downgrade).
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Divullg_Atualizador_1' ) ) {

	final class Divullg_Atualizador_1 {

		/** Chave pública Ed25519 (base64). Vazia = atualização pelo wp-admin desligada. */
		const CHAVE = '/xSKuiZ/o/f/bEkW+FrgZChijzN12iWqadRvbN1j5k8=';

		const MANIFESTO = 'https://raw.githubusercontent.com/ccesarc/sentinela-plugins/main/versoes.json';
		const HOST      = 'raw.githubusercontent.com';
		const PREFIXO   = 'https://raw.githubusercontent.com/ccesarc/sentinela-plugins/main/zips/';
		const CACHE     = 'divullg_atualizador_manifesto';

		/** @var array<string,string> slug => arquivo do plugin (ex.: blindagem/blindagem.php) */
		private static $plugins = array();

		public static function registrar( $slug, $arquivo ) {
			if ( '' === self::CHAVE || ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
				return;
			}
			if ( ! self::$plugins ) {
				add_filter( 'update_plugins_' . self::HOST, array( __CLASS__, 'oferecer' ), 10, 3 );
				add_filter( 'upgrader_pre_download', array( __CLASS__, 'baixar' ), 10, 3 );
				add_filter( 'auto_update_plugin', array( __CLASS__, 'sem_automatico' ), 99, 2 );
			}
			self::$plugins[ $slug ] = plugin_basename( $arquivo );
		}

		/** Entrada do manifesto já com a assinatura conferida, ou null. */
		private static function entrada( $slug ) {
			$m = get_site_transient( self::CACHE );
			if ( ! is_array( $m ) ) {
				$r = wp_remote_get(
					self::MANIFESTO,
					array(
						'timeout'             => 10,
						'redirection'         => 0,
						'limit_response_size' => 65536,
					)
				);
				$m = 200 === wp_remote_retrieve_response_code( $r ) ? json_decode( (string) wp_remote_retrieve_body( $r ), true ) : null;
				$m = is_array( $m ) && isset( $m['plugins'] ) && is_array( $m['plugins'] ) ? $m['plugins'] : array();
				set_site_transient( self::CACHE, $m, $m ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
			}
			$e = isset( $m[ $slug ] ) && is_array( $m[ $slug ] ) ? $m[ $slug ] : null;
			if ( ! $e || ! isset( $e['versao'], $e['sha256'], $e['assinatura'] ) ) {
				return null;
			}
			$versao = (string) $e['versao'];
			$sha    = strtolower( (string) $e['sha256'] );
			if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', $versao ) || ! preg_match( '/^[0-9a-f]{64}$/', $sha ) ) {
				return null;
			}
			if ( ! self::assinado( $slug, $versao, $sha, (string) $e['assinatura'] ) ) {
				return null;
			}
			return array(
				'versao'  => $versao,
				'sha256'  => $sha,
				'pacote'  => self::PREFIXO . 'PLUGIN-' . $slug . '-' . $versao . '.zip',
				'requer'  => isset( $e['requer_php'] ) && preg_match( '/^\d+\.\d+$/', (string) $e['requer_php'] ) ? (string) $e['requer_php'] : '7.4',
				'assin'   => (string) $e['assinatura'],
			);
		}

		/** Mensagem assinada: "slug\nversão\nsha256" — o mesmo que scripts/assinatura.mjs assina. */
		private static function assinado( $slug, $versao, $sha, $assinatura ) {
			$sig = base64_decode( $assinatura, true );
			$pk  = base64_decode( self::CHAVE, true );
			if ( false === $sig || false === $pk || 64 !== strlen( $sig ) || 32 !== strlen( $pk ) ) {
				return false;
			}
			try {
				return sodium_crypto_sign_verify_detached( $sig, $slug . "\n" . $versao . "\n" . $sha, $pk );
			} catch ( Exception $e ) {
				return false;
			}
		}

		public static function oferecer( $update, $dados, $arquivo ) {
			$slug = array_search( $arquivo, self::$plugins, true );
			if ( false === $slug ) {
				return $update;
			}
			$e = self::entrada( $slug );
			if ( ! $e || version_compare( $e['versao'], (string) $dados['Version'], '<=' ) ) {
				return $update;
			}
			return array(
				'slug'         => $slug,
				'version'      => $e['versao'],
				'url'          => 'https://github.com/ccesarc/sentinela-plugins',
				'package'      => $e['pacote'],
				'requires_php' => $e['requer'],
			);
		}

		/** Baixa e confere o zip antes de o WordPress instalar. Só intercepta os pacotes destes plugins. */
		public static function baixar( $reply, $pacote, $upgrader ) {
			if ( false !== $reply || ! is_string( $pacote ) || 0 !== strpos( $pacote, self::PREFIXO ) ) {
				return $reply;
			}
			if ( ! preg_match( '#/PLUGIN-([a-z0-9-]+)-(\d+(?:\.\d+){1,3})\.zip$#', $pacote, $m ) || ! isset( self::$plugins[ $m[1] ] ) ) {
				return new WP_Error( 'divullg_pacote', 'Pacote desconhecido.' );
			}
			$e = self::entrada( $m[1] );
			if ( ! $e || $e['versao'] !== $m[2] || $e['pacote'] !== $pacote ) {
				return new WP_Error( 'divullg_assinatura', 'Atualização sem assinatura válida da agência — recusada.' );
			}
			if ( ! function_exists( 'download_url' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}
			$tmp = download_url( $pacote, 120 );
			if ( is_wp_error( $tmp ) ) {
				return $tmp;
			}
			if ( ! hash_equals( $e['sha256'], (string) hash_file( 'sha256', $tmp ) ) || ! self::assinado( $m[1], $e['versao'], $e['sha256'], $e['assin'] ) ) {
				wp_delete_file( $tmp );
				return new WP_Error( 'divullg_assinatura', 'O zip baixado não é o que a agência assinou — atualização recusada.' );
			}
			return $tmp;
		}

		/** Só pelo botão: bug numa versão não chega a todos os sites de uma vez. */
		public static function sem_automatico( $atualizar, $item ) {
			return isset( $item->plugin ) && in_array( $item->plugin, self::$plugins, true ) ? false : $atualizar;
		}
	}
}
