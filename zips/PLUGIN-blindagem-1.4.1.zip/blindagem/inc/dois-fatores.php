<?php
/**
 * Segundo fator por e-mail para administradores.
 *
 * Depois da senha certa, o WordPress não entra: manda um código de 6 dígitos
 * para o e-mail do usuário e pede o código numa segunda tela. Senha vazada
 * sozinha não basta mais.
 *
 * ⚠️ Desligado por padrão: se o site não consegue mandar e-mail, ligar isto
 * tranca todo administrador do lado de fora. O painel tem um botão de e-mail
 * de teste — ligue só depois que ele chegar. Trancou? BLINDAGEM_MODO_SEGURO
 * no wp-config.php desliga.
 */

defined( 'ABSPATH' ) || exit;

if ( ! blindagem_ligado( 'dois_fatores' ) || ( defined( 'BLINDAGEM_MODO_SEGURO' ) && BLINDAGEM_MODO_SEGURO ) ) {
	return;
}

const BLINDAGEM_2FA_VALIDADE   = 10 * MINUTE_IN_SECONDS;
const BLINDAGEM_2FA_TENTATIVAS = 5;

function blindagem_2fa_hash( $codigo ) {
	return hash_hmac( 'sha256', (string) $codigo, wp_salt( 'auth' ) );
}

/**
 * Depois da senha conferida (o core autentica na prioridade 20 e o limite
 * de login roda na 30), segura o login de quem pode administrar o site.
 */
add_filter( 'authenticate', function ( $usuario ) {
	if ( ! ( $usuario instanceof WP_User ) || ! user_can( $usuario, 'manage_options' ) ) {
		return $usuario;
	}

	/*
	 * Vale para TODO login por senha, não só o wp-login.php: formulário de
	 * login do WooCommerce, de widget ou do tema chama wp_signon() e passaria
	 * direto. Cookie e senha de aplicativo na API não passam por aqui.
	 * Onde não dá para mostrar a segunda tela (XML-RPC, API, AJAX), admin
	 * não entra só com a senha.
	 */
	if ( ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || wp_doing_ajax() ) {
		return new WP_Error(
			'blindagem_2fa_formulario',
			sprintf( '<strong>Erro:</strong> administradores entram pela <a href="%s">tela de login</a> (código por e-mail).', esc_url( wp_login_url() ) )
		);
	}

	$codigo = (string) random_int( 100000, 999999 );
	$token  = wp_generate_password( 40, false );

	$enviado = wp_mail(
		$usuario->user_email,
		sprintf( '[%s] Código de acesso: %s', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), $codigo ),
		sprintf(
			"Seu código para entrar no painel de %s:\n\n    %s\n\nVale por 10 minutos.\n\n" .
			"Se não foi você, alguém tem a sua senha: troque-a agora.\nIP da tentativa: %s\n",
			home_url( '/' ),
			$codigo,
			blindagem_ip()
		)
	);

	if ( ! $enviado ) {
		return new WP_Error( 'blindagem_2fa_email', '<strong>Erro:</strong> não foi possível enviar o código de acesso por e-mail. Avise o responsável pelo site.' );
	}

	set_transient( 'blindagem_2fa_' . $token, array(
		'usuario'    => $usuario->ID,
		'hash'       => blindagem_2fa_hash( $codigo ),
		'erros'      => 0,
		'lembrar'    => ! empty( $_POST['rememberme'] ), // phpcs:ignore WordPress.Security.NonceVerification -- formulário de login do core.
		'redirecion' => isset( $_REQUEST['redirect_to'] ) ? wp_validate_redirect( wp_unslash( $_REQUEST['redirect_to'] ), '' ) : '', // phpcs:ignore WordPress.Security.NonceVerification
	), BLINDAGEM_2FA_VALIDADE );

	wp_safe_redirect( add_query_arg( array( 'action' => 'blindagem_2fa', 'token' => $token ), wp_login_url() ) );
	exit;
}, 99 );

/** A segunda tela, em wp-login.php?action=blindagem_2fa. */
add_action( 'login_form_blindagem_2fa', function () {
	$token = isset( $_REQUEST['token'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', wp_unslash( $_REQUEST['token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- o token é o segredo.
	$dados = $token ? get_transient( 'blindagem_2fa_' . $token ) : false;

	if ( ! is_array( $dados ) ) {
		wp_safe_redirect( add_query_arg( 'blindagem_2fa', 'expirou', wp_login_url() ) );
		exit;
	}

	$erro = '';

	if ( 'POST' === $_SERVER['REQUEST_METHOD'] ) {
		check_admin_referer( 'blindagem_2fa_' . $token );

		$digitado = isset( $_POST['codigo'] ) ? preg_replace( '/\D/', '', wp_unslash( $_POST['codigo'] ) ) : '';
		$usuario  = get_userdata( $dados['usuario'] );

		if ( $usuario && hash_equals( $dados['hash'], blindagem_2fa_hash( $digitado ) ) ) {
			delete_transient( 'blindagem_2fa_' . $token );

			wp_set_auth_cookie( $usuario->ID, $dados['lembrar'], is_ssl() );
			do_action( 'wp_login', $usuario->user_login, $usuario ); // registro de acesso, zera o limite

			wp_safe_redirect( $dados['redirecion'] ? $dados['redirecion'] : admin_url() );
			exit;
		}

		// Código errado conta como login errado: entra no limite por IP.
		do_action( 'wp_login_failed', $usuario ? $usuario->user_login : '', new WP_Error( 'blindagem_2fa_errado' ) );

		++$dados['erros'];
		if ( $dados['erros'] >= BLINDAGEM_2FA_TENTATIVAS ) {
			delete_transient( 'blindagem_2fa_' . $token );
			wp_safe_redirect( add_query_arg( 'blindagem_2fa', 'expirou', wp_login_url() ) );
			exit;
		}

		set_transient( 'blindagem_2fa_' . $token, $dados, BLINDAGEM_2FA_VALIDADE );
		$erro = 'Código incorreto.';
	}

	login_header( 'Código de acesso', '', $erro ? new WP_Error( 'blindagem_2fa', $erro ) : null );
	?>
	<form method="post" action="<?php echo esc_url( add_query_arg( array( 'action' => 'blindagem_2fa', 'token' => $token ), wp_login_url() ) ); ?>">
		<p class="message">Enviamos um código de 6 dígitos para o seu e-mail. Ele vale por 10 minutos.</p>
		<p>
			<label for="blindagem-codigo">Código</label>
			<input type="text" name="codigo" id="blindagem-codigo" class="input" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required autofocus>
		</p>
		<?php wp_nonce_field( 'blindagem_2fa_' . $token ); ?>
		<p class="submit"><input type="submit" class="button button-primary button-large" value="Entrar"></p>
	</form>
	<?php
	login_footer();
	exit;
} );

add_filter( 'wp_login_errors', function ( $erros ) {
	if ( isset( $_GET['blindagem_2fa'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$erros->add( 'blindagem_2fa_expirou', 'O código expirou ou foi digitado errado vezes demais. Entre de novo.' );
	}
	return $erros;
} );
