<?php
/**
 * Quarentena e reinstalação: o que fazer com um achado da verificação.
 *
 * Quarentena (em vez de apagar): o arquivo sai do lugar e vai para uma pasta
 * trancada em wp-content/, renomeado sem extensão executável. O site para de
 * usá-lo na hora, mas ele continua lá como prova — e volta com um clique se
 * for alarme falso. "Apagar de vez" é um segundo passo, consciente.
 *
 * Arquivo LEGÍTIMO que foi ALTERADO (core ou plugin) não vai para a
 * quarentena — tirá-lo derruba o site. Plugin: reinstala do wordpress.org.
 * Core: Painel → Atualizações → "Reinstalar".
 *
 * Só age sobre arquivos que estão no relatório da última verificação e que
 * não mudaram desde então (hash): o formulário nunca escolhe um caminho
 * qualquer do servidor.
 */

defined( 'ABSPATH' ) || exit;

/** Tipos de achado que podem ir para a quarentena (sem derrubar o site). */
function blindagem_quarentenaveis() {
	return array( 'php_uploads', 'compactado', 'mu_plugin', 'raiz_conteudo', 'codigo', 'core_extra', 'plugin_extra', 'foto_novo', 'nome_estranho', 'php_disfarcado', 'raiz_desconhecido', 'escondido' );
}

function blindagem_quarentena_lista() {
	$lista = get_option( 'blindagem_quarentena', array() );
	return is_array( $lista ) ? $lista : array();
}

/** O achado ainda existe? Os que apontam para um arquivo somem quando o arquivo some. */
function blindagem_achado_ainda_vale( $achado ) {
	$de_arquivo = array_merge( blindagem_quarentenaveis(), array( 'core_alterado', 'plugin_alterado', 'foto_alterado', 'foto_pasta', 'config_php', 'plugin_casca', 'plugin_escondido', 'plugin_fora_wporg' ) );
	return ! in_array( $achado['tipo'], $de_arquivo, true ) || file_exists( blindagem_absoluto( $achado['arquivo'] ) );
}

/** Caminho absoluto a partir do relativo guardado no relatório. */
function blindagem_absoluto( $relativo ) {
	if ( 0 === strpos( (string) $relativo, 'b64:' ) ) {
		$relativo = (string) base64_decode( substr( $relativo, 4 ), true );
	}
	return path_is_absolute( $relativo ) ? $relativo : ABSPATH . $relativo;
}

/**
 * Pasta da quarentena. De preferência FORA da pasta pública do site (um nível
 * acima da raiz do WordPress, ex.: a home da conta na hospedagem): aí nem um
 * servidor que ignore .htaccess entrega o arquivo. Sem permissão lá, fica em
 * wp-content/ com nome aleatório, .htaccess negando tudo e index.php vazio.
 */
function blindagem_quarentena_pasta() {
	$dir = (string) get_option( 'blindagem_quarentena_dir' );
	if ( $dir && @is_dir( $dir ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors -- open_basedir pode negar e avisar.
		return $dir;
	}

	// Versão 1.2: pasta em wp-content guardada só pelo nome.
	$antiga = (string) get_option( 'blindagem_quarentena_pasta' );
	if ( preg_match( '/^blindagem-quarentena-[a-z0-9]{16}$/', $antiga ) && is_dir( WP_CONTENT_DIR . '/' . $antiga ) ) {
		update_option( 'blindagem_quarentena_dir', WP_CONTENT_DIR . '/' . $antiga, false );
		return WP_CONTENT_DIR . '/' . $antiga;
	}

	$nome  = 'blindagem-quarentena-' . strtolower( wp_generate_password( 16, false ) );
	$fora  = dirname( untrailingslashit( ABSPATH ) );
	$bases = array();
	if ( '/' !== $fora && '.' !== $fora && @is_writable( $fora ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$bases[] = $fora;
	}
	$bases[] = WP_CONTENT_DIR;

	foreach ( $bases as $base ) {
		$pasta = $base . '/' . $nome;
		if ( @wp_mkdir_p( $pasta ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			file_put_contents( $pasta . '/.htaccess', "Require all denied\nDeny from all\n" );
			file_put_contents( $pasta . '/index.php', "<?php\n// Silêncio.\n" );
			update_option( 'blindagem_quarentena_dir', $pasta, false );
			return $pasta;
		}
	}
	return false;
}

/** A quarentena está fora da pasta pública do site? */
function blindagem_quarentena_fora() {
	$dir = (string) get_option( 'blindagem_quarentena_dir' );
	return $dir && 0 !== strpos( wp_normalize_path( $dir ), wp_normalize_path( ABSPATH ) ) && 0 !== strpos( wp_normalize_path( $dir ), wp_normalize_path( WP_CONTENT_DIR ) );
}

/**
 * Reconhece UM achado como legítimo (depois de conferir). Arquivo de
 * tema/plugin sem original: atualiza a foto daquele arquivo. Os outros: entram
 * na lista de reconhecidos com o hash — voltam a aparecer se o arquivo mudar.
 */
function blindagem_reconhecer_um( $relativo ) {
	$achou = blindagem_achado_no_relatorio( $relativo );
	if ( ! $achou ) {
		return 'Esse item não está no relatório. Rode a verificação de novo.';
	}
	list( $qual, $indice, $achado ) = $achou;

	if ( 0 === strpos( $achado['tipo'], 'foto_' ) ) {
		blindagem_foto_aceitar_arquivo( $relativo );
	} else {
		$conhecidos              = get_option( 'blindagem_reconhecidos', array() );
		$conhecidos              = is_array( $conhecidos ) ? $conhecidos : array();
		$conhecidos[ $relativo ] = $achado['hash'];
		update_option( 'blindagem_reconhecidos', $conhecidos, false );
	}

	blindagem_tirar_do_relatorio( $qual, $indice );
	update_option( 'blindagem_alertado_' . $qual, '', false );
	blindagem_registrar_evento( 'Achado reconhecido como legítimo', $relativo );
	return '';
}

/** Acha o achado no relatório atual: [ qual, índice, achado ] ou null. */
function blindagem_achado_no_relatorio( $relativo ) {
	foreach ( array( 'varredura', 'integridade' ) as $qual ) {
		$relatorio = get_option( 'blindagem_rel_' . $qual );
		if ( ! is_array( $relatorio ) ) {
			continue;
		}
		foreach ( $relatorio['achados'] as $i => $achado ) {
			if ( $achado['arquivo'] === $relativo ) {
				return array( $qual, $i, $achado );
			}
		}
	}
	return null;
}

function blindagem_tirar_do_relatorio( $qual, $indice ) {
	$relatorio = get_option( 'blindagem_rel_' . $qual );
	unset( $relatorio['achados'][ $indice ] );
	$relatorio['achados'] = array_values( $relatorio['achados'] );
	update_option( 'blindagem_rel_' . $qual, $relatorio, false );
}

/** Move um achado para a quarentena. Devolve '' ou a mensagem de erro. */
function blindagem_por_em_quarentena( $relativo ) {
	$achou = blindagem_achado_no_relatorio( $relativo );
	if ( ! $achou ) {
		return 'Esse arquivo não está no relatório. Rode a verificação de novo.';
	}
	list( $qual, $indice, $achado ) = $achou;

	if ( 'plugin_casca' === $achado['tipo'] ) {
		return blindagem_quarentena_casca( $relativo, $qual, $indice, $achado );
	}
	if ( ! in_array( $achado['tipo'], blindagem_quarentenaveis(), true ) ) {
		return 'Esse tipo de achado não vai para a quarentena (arquivo legítimo alterado: use Reinstalar; o resto: confira e use Reconhecer).';
	}

	$caminho = blindagem_absoluto( $relativo );
	$real    = realpath( $caminho );

	if ( ! $real || ! is_file( $real ) || is_link( $caminho ) ) {
		blindagem_tirar_do_relatorio( $qual, $indice );
		return 'O arquivo não existe mais.';
	}

	$base_wp       = wp_normalize_path( realpath( ABSPATH ) ) . '/';
	$base_conteudo = wp_normalize_path( realpath( WP_CONTENT_DIR ) ) . '/';
	$real_norm     = wp_normalize_path( $real );
	$proibidos     = array( 'wp-config.php', 'index.php', 'wp-load.php', 'wp-settings.php', 'wp-blog-header.php' );

	if ( ( 0 !== strpos( $real_norm, $base_wp ) && 0 !== strpos( $real_norm, $base_conteudo ) )
		|| in_array( substr( $real_norm, strlen( $base_wp ) ), $proibidos, true )
		|| 0 === strpos( $real_norm, wp_normalize_path( dirname( BLINDAGEM_ARQUIVO ) ) . '/' ) ) {
		return 'Esse arquivo não pode ser movido por aqui.';
	}

	if ( md5_file( $real ) !== $achado['hash'] ) {
		return 'O arquivo mudou depois da verificação. Rode a verificação de novo antes.';
	}

	$pasta = blindagem_quarentena_pasta();
	if ( ! $pasta ) {
		return 'Não foi possível criar a pasta da quarentena (permissão de escrita em wp-content).';
	}

	$id      = strtolower( wp_generate_password( 12, false ) );
	$destino = $pasta . '/' . $id . '.quarentena';

	if ( ! @rename( $real, $destino ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! @copy( $real, $destino ) || ! @unlink( $real ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			@unlink( $destino ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return 'Sem permissão para mover o arquivo. Mova pelo gerenciador de arquivos da hospedagem.';
		}
	}

	$lista        = blindagem_quarentena_lista();
	$lista[ $id ] = array(
		'original' => $relativo,
		'tipo'     => $achado['tipo'],
		'hash'     => $achado['hash'],
		'tamanho'  => filesize( $destino ),
		'quando'   => current_time( 'mysql' ),
	);
	update_option( 'blindagem_quarentena', $lista, false );

	blindagem_tirar_do_relatorio( $qual, $indice );
	update_option( 'blindagem_alertado_' . $qual, '', false );
	// A foto passa a saber que o arquivo saiu por aqui (senão a próxima varredura acusa "SUMIU").
	blindagem_foto_aceitar_arquivo( blindagem_relativo( $real ) );
	blindagem_registrar_evento( 'Arquivo em quarentena', $relativo );

	return '';
}

/** Sufixo dos arquivos de dentro de uma pasta em quarentena: nada ali continua executável. */
const BLINDAGEM_SUFIXO_PASTA = '.quarentena';

/** Renomeia (ou desfaz) os arquivos de dentro de uma pasta em quarentena. */
function blindagem_quarentena_renomear_dentro( $pasta, $tirar ) {
	$arquivos = array();
	blindagem_percorrer( $pasta, function ( $a ) use ( &$arquivos ) {
		$arquivos[] = $a->getPathname();
		return count( $arquivos ) < 200;
	} );
	foreach ( $arquivos as $a ) {
		$novo = $tirar ? preg_replace( '/' . preg_quote( BLINDAGEM_SUFIXO_PASTA, '/' ) . '$/', '', $a ) : $a . BLINDAGEM_SUFIXO_PASTA;
		if ( $novo !== $a ) {
			@rename( $a, $novo ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}
}

/**
 * Casca de plugin (pasta em plugins/ sem plugin dentro — vazia ou com marcadores de malware, como
 * bright-backup-dot/.pv_…): a pasta inteira vai para a quarentena. Só pasta direto em plugins/, que não
 * mudou desde a verificação e é pequena; com conteúdo de verdade, o gerenciador de arquivos decide.
 */
function blindagem_quarentena_casca( $relativo, $qual, $indice, $achado ) {
	$caminho = blindagem_absoluto( $relativo );
	$real    = realpath( $caminho );
	if ( ! $real || ! is_dir( $real ) || is_link( $caminho ) ) {
		blindagem_tirar_do_relatorio( $qual, $indice );
		return 'A pasta não existe mais.';
	}
	if ( wp_normalize_path( dirname( $real ) ) !== wp_normalize_path( (string) realpath( WP_PLUGIN_DIR ) ) || get_plugins( '/' . basename( $real ) ) ) {
		return 'Essa pasta não pode ser movida por aqui.';
	}
	if ( blindagem_casca_assinatura( $real )[0] !== $achado['hash'] ) {
		return 'A pasta mudou depois da verificação. Rode a verificação de novo antes.';
	}
	$qtd   = 0;
	$bytes = 0;
	blindagem_percorrer( $real, function ( $a ) use ( &$qtd, &$bytes ) {
		++$qtd;
		$bytes += $a->getSize();
		return $qtd <= 50;
	} );
	if ( $qtd > 50 || $bytes > 1048576 ) {
		return 'Pasta grande demais para a quarentena: confira o que tem e apague pelo gerenciador de arquivos.';
	}

	$pasta = blindagem_quarentena_pasta();
	if ( ! $pasta ) {
		return 'Não foi possível criar a pasta da quarentena (permissão de escrita em wp-content).';
	}
	$id      = strtolower( wp_generate_password( 12, false ) );
	$destino = $pasta . '/' . $id . '.quarentena-pasta';
	if ( ! blindagem_mover_pasta( $real, $destino ) ) {
		return 'Sem permissão para mover a pasta. Apague pelo gerenciador de arquivos da hospedagem.';
	}
	blindagem_quarentena_renomear_dentro( $destino, false );

	$lista        = blindagem_quarentena_lista();
	$lista[ $id ] = array(
		'original' => $relativo,
		'tipo'     => $achado['tipo'],
		'hash'     => $achado['hash'],
		'tamanho'  => $bytes,
		'quando'   => current_time( 'mysql' ),
		'pasta'    => true,
	);
	update_option( 'blindagem_quarentena', $lista, false );

	blindagem_tirar_do_relatorio( $qual, $indice );
	update_option( 'blindagem_alertado_' . $qual, '', false );
	blindagem_registrar_evento( 'Pasta em quarentena', $relativo );
	return '';
}

/** Move uma pasta; entre discos diferentes (quarentena fora da pasta pública) copia e apaga a original. */
function blindagem_mover_pasta( $de, $para ) {
	if ( @rename( $de, $para ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
		return true;
	}
	if ( ! wp_mkdir_p( $para ) ) {
		return false;
	}
	$itens = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $de, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::SELF_FIRST );
	foreach ( $itens as $item ) {
		$alvo = $para . '/' . substr( $item->getPathname(), strlen( $de ) + 1 );
		$ok   = $item->isDir() ? wp_mkdir_p( $alvo ) : ( ! $item->isLink() && @copy( $item->getPathname(), $alvo ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $ok ) {
			blindagem_apagar_pasta( $para ); // desfaz a cópia pela metade; a original continua intacta
			return false;
		}
	}
	return blindagem_apagar_pasta( $de );
}

/** Apaga uma pasta da quarentena com o que tiver dentro (já conferida: pequena, sem links). */
function blindagem_apagar_pasta( $pasta ) {
	$itens = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $pasta, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
	foreach ( $itens as $item ) {
		if ( $item->isDir() && ! $item->isLink() ) {
			@rmdir( $item->getPathname() ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		} else {
			@unlink( $item->getPathname() ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}
	return @rmdir( $pasta ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
}

function blindagem_restaurar_quarentena( $id ) {
	$lista = blindagem_quarentena_lista();
	if ( ! isset( $lista[ $id ] ) ) {
		return 'Item não encontrado na quarentena.';
	}

	$item     = $lista[ $id ];
	$guardado = blindagem_quarentena_pasta() . '/' . $id . ( empty( $item['pasta'] ) ? '.quarentena' : '.quarentena-pasta' );
	$original = blindagem_absoluto( $item['original'] );

	if ( file_exists( $original ) ) {
		return 'Já existe outro arquivo no lugar original. Nada foi sobrescrito.';
	}
	if ( ! empty( $item['pasta'] ) && is_dir( $guardado ) ) {
		blindagem_quarentena_renomear_dentro( $guardado, true );
	}
	$movido = file_exists( $guardado ) && wp_mkdir_p( dirname( $original ) ) && ( empty( $item['pasta'] )
		? ( @rename( $guardado, $original ) || ( @copy( $guardado, $original ) && @unlink( $guardado ) ) ) // phpcs:ignore WordPress.PHP.NoSilencedErrors -- quarentena em outro disco: copia e apaga
		: blindagem_mover_pasta( $guardado, $original ) );
	if ( ! $movido ) {
		return 'Não foi possível restaurar (arquivo sumiu da quarentena ou sem permissão).';
	}

	unset( $lista[ $id ] );
	update_option( 'blindagem_quarentena', $lista, false );
	blindagem_foto_aceitar_arquivo( blindagem_relativo( $original ) );
	blindagem_registrar_evento( 'Arquivo restaurado da quarentena', $item['original'] );
	return '';
}

function blindagem_apagar_quarentena( $id ) {
	$lista = blindagem_quarentena_lista();
	if ( ! isset( $lista[ $id ] ) ) {
		return 'Item não encontrado na quarentena.';
	}

	if ( ! empty( $lista[ $id ]['pasta'] ) ) {
		$guardado = blindagem_quarentena_pasta() . '/' . $id . '.quarentena-pasta';
		if ( is_dir( $guardado ) && ! blindagem_apagar_pasta( $guardado ) ) {
			return 'Sem permissão para apagar a pasta.';
		}
	} else {
		$guardado = blindagem_quarentena_pasta() . '/' . $id . '.quarentena';
		if ( file_exists( $guardado ) && ! @unlink( $guardado ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return 'Sem permissão para apagar o arquivo.';
		}
	}

	blindagem_registrar_evento( 'Arquivo apagado da quarentena', $lista[ $id ]['original'] );
	unset( $lista[ $id ] );
	update_option( 'blindagem_quarentena', $lista, false );
	return '';
}

/**
 * Reinstala um plugin do wordpress.org por cima (versão mais nova publicada).
 * Só plugin que está no relatório como alterado/com arquivo a mais.
 */
function blindagem_reinstalar_plugin( $slug ) {
	$slug = sanitize_key( $slug );

	$no_relatorio = false;
	$relatorio    = get_option( 'blindagem_rel_integridade' );
	foreach ( (array) ( $relatorio['achados'] ?? array() ) as $achado ) {
		if ( in_array( $achado['tipo'], array( 'plugin_alterado', 'plugin_extra' ), true )
			&& 0 === strpos( wp_normalize_path( blindagem_absoluto( $achado['arquivo'] ) ), wp_normalize_path( WP_PLUGIN_DIR ) . '/' . $slug . '/' ) ) {
			$no_relatorio = true;
		}
	}
	if ( ! $slug || ! $no_relatorio ) {
		return 'Esse plugin não está no relatório de integridade.';
	}

	require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';

	$info = plugins_api( 'plugin_information', array( 'slug' => $slug, 'fields' => array( 'sections' => false ) ) );
	if ( is_wp_error( $info ) || empty( $info->download_link ) ) {
		return 'Não consegui baixar o plugin do wordpress.org.';
	}

	$upgrader  = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
	$resultado = $upgrader->install( $info->download_link, array( 'overwrite_package' => true ) );

	if ( true !== $resultado ) {
		return is_wp_error( $resultado ) ? 'Falhou: ' . $resultado->get_error_message() : 'Falhou (a hospedagem pode exigir FTP para instalar).';
	}

	blindagem_registrar_evento( 'Plugin reinstalado do wordpress.org', $slug . ' ' . $info->version );
	blindagem_rodar( 'integridade' );
	return '';
}


/* ==========================================================================
   Botões
   ========================================================================== */

/** Mensagem de erro passa pelo redirect em transient curto (não na URL). */
function blindagem_voltar_com( $erro, $ok ) {
	if ( $erro ) {
		set_transient( 'blindagem_erro_' . get_current_user_id(), $erro, MINUTE_IN_SECONDS );
	}
	blindagem_voltar( 'verificacao', $erro ? 'acao_erro' : $ok );
}

add_action( 'admin_post_blindagem_quarentena', function () {
	blindagem_conferir_permissao( 'blindagem_quarentena' );
	$arquivo = isset( $_POST['arquivo'] ) ? wp_unslash( $_POST['arquivo'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- comparado literalmente com o relatório.
	blindagem_voltar_com( blindagem_por_em_quarentena( (string) $arquivo ), 'quarentena_ok' );
} );

add_action( 'admin_post_blindagem_reconhecer_um', function () {
	blindagem_conferir_permissao( 'blindagem_reconhecer_um' );
	$arquivo = isset( $_POST['arquivo'] ) ? wp_unslash( $_POST['arquivo'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- comparado literalmente com o relatório.
	blindagem_voltar_com( blindagem_reconhecer_um( (string) $arquivo ), 'reconhecido_um' );
} );

add_action( 'admin_post_blindagem_quarentena_restaurar', function () {
	blindagem_conferir_permissao( 'blindagem_quarentena_restaurar' );
	$id = isset( $_POST['id'] ) ? sanitize_key( wp_unslash( $_POST['id'] ) ) : '';
	blindagem_voltar_com( blindagem_restaurar_quarentena( $id ), 'restaurado' );
} );

add_action( 'admin_post_blindagem_quarentena_apagar', function () {
	blindagem_conferir_permissao( 'blindagem_quarentena_apagar' );
	$id = isset( $_POST['id'] ) ? sanitize_key( wp_unslash( $_POST['id'] ) ) : '';
	blindagem_voltar_com( blindagem_apagar_quarentena( $id ), 'apagado' );
} );

add_action( 'admin_post_blindagem_reinstalar_plugin', function () {
	blindagem_conferir_permissao( 'blindagem_reinstalar_plugin' );
	if ( ! current_user_can( 'install_plugins' ) ) {
		blindagem_voltar_com( 'Sem permissão para instalar plugins.', '' );
	}
	$slug = isset( $_POST['plugin'] ) ? sanitize_key( wp_unslash( $_POST['plugin'] ) ) : '';
	blindagem_voltar_com( blindagem_reinstalar_plugin( $slug ), 'reinstalado' );
} );

/** Botões da coluna "Ação" de um achado. */
function blindagem_botao_achado( $achado ) {
	blindagem_botao_achado_principal( $achado );
	blindagem_botao(
		'blindagem_reconhecer_um',
		'Reconhecer',
		'button button-small button-link',
		"Você conferiu e este item é LEGÍTIMO?\n\n" . blindagem_visivel( $achado['arquivo'] ) . "\n\nEle sai da lista e só volta se mudar de novo.",
		array( 'arquivo' => $achado['arquivo'] )
	);
}

function blindagem_botao_achado_principal( $achado ) {
	if ( in_array( $achado['tipo'], blindagem_quarentenaveis(), true ) ) {
		blindagem_botao(
			'blindagem_quarentena',
			'Pôr em quarentena',
			'button button-small',
			"Tirar este arquivo do lugar?\n\n" . blindagem_visivel( $achado['arquivo'] ) . "\n\nEle vai para a quarentena (não roda mais, mas fica guardado). Se o site quebrar, restaure na lista da quarentena.",
			array( 'arquivo' => $achado['arquivo'] )
		);
	} elseif ( 'plugin_casca' === $achado['tipo'] ) {
		blindagem_botao(
			'blindagem_quarentena',
			'Pôr pasta em quarentena',
			'button button-small',
			"Tirar esta pasta de plugins/?\n\n" . blindagem_visivel( $achado['arquivo'] ) . "\n\nEla vai para a quarentena (nada dentro roda mais). Dá para restaurar pela lista da quarentena.",
			array( 'arquivo' => $achado['arquivo'] )
		);
	} elseif ( 'plugin_alterado' === $achado['tipo'] ) {
		$caminho = wp_normalize_path( blindagem_absoluto( $achado['arquivo'] ) );
		$resto   = substr( $caminho, strlen( wp_normalize_path( WP_PLUGIN_DIR ) ) + 1 );
		$slug    = strtok( $resto, '/' );
		blindagem_botao( 'blindagem_reinstalar_plugin', 'Reinstalar plugin do original', 'button button-small', 'Reinstalar ' . $slug . ' do wordpress.org por cima (versão mais nova)?', array( 'plugin' => $slug ) );
	} elseif ( 'cron_suspeito' === $achado['tipo'] ) {
		printf( '<a class="button button-small" href="%s">Ver em Agendamentos</a>', esc_url( admin_url( 'options-general.php?page=blindagem&aba=agenda' ) ) );
	} elseif ( 'banco_script' === $achado['tipo'] && preg_match( '/ #(\d+) /', $achado['arquivo'], $m ) && get_post( (int) $m[1] ) ) {
		printf( '<a class="button button-small" href="%s">Abrir para limpar</a>', esc_url( get_edit_post_link( (int) $m[1] ) ) );
	} elseif ( 'core_alterado' === $achado['tipo'] ) {
		printf( '<a class="button button-small" href="%s">Reinstalar o WordPress</a>', esc_url( admin_url( 'update-core.php' ) ) );
	}
}

/** Lista da quarentena, no fim da aba Verificação. */
function blindagem_tabela_quarentena() {
	$lista = blindagem_quarentena_lista();
	echo '<h2>Quarentena</h2>';

	if ( ! $lista ) {
		echo '<p>Nada na quarentena.</p>';
		return;
	}

	echo '<p>Arquivos tirados do lugar. Não rodam mais. Site funcionando normal depois de alguns dias? Apague de vez.</p>';
	echo blindagem_quarentena_fora() ? '<p class="description">✔ Guardados fora da pasta pública do site: não podem ser abertos pela internet.</p>' : '<p class="description">Guardados em wp-content/ (a hospedagem não deixa gravar fora da pasta pública), numa pasta de nome aleatório com acesso negado.</p>';
	blindagem_lote_barra( 'blindagem-lote-quarentena', 'blindagem_lote_quarentena', array( 'apagar' => 'Apagar de vez', 'restaurar' => 'Restaurar para o lugar original' ) );
	echo '<table class="widefat striped"><thead><tr>';
	blindagem_lote_todos( 'blindagem-lote-quarentena' );
	echo '<th>Quando</th><th>Arquivo original</th><th>Tamanho</th><th>Ação</th></tr></thead><tbody>';
	foreach ( $lista as $id => $item ) {
		echo '<tr>';
		blindagem_lote_caixa( 'blindagem-lote-quarentena', $id );
		printf( '<td>%s</td><td><code>%s</code></td><td>%s</td><td>', esc_html( mysql2date( 'd/m/Y H:i', $item['quando'] ) ), esc_html( blindagem_visivel( $item['original'] ) ), esc_html( size_format( (int) $item['tamanho'] ) ) );
		blindagem_botao( 'blindagem_quarentena_restaurar', 'Restaurar', 'button button-small', 'Devolver o arquivo para o lugar original? Ele volta a rodar.', array( 'id' => $id ) );
		blindagem_botao( 'blindagem_quarentena_apagar', 'Apagar de vez', 'button button-small button-link-delete', 'Apagar este arquivo definitivamente? Não dá para desfazer.', array( 'id' => $id ) );
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}
