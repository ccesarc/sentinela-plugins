<?php
/**
 * Prevenção: cada bloco fecha uma porta conhecida e tem um interruptor no
 * painel (Configurações → Blindagem). Nada aqui esconde que o site é
 * WordPress — isso seria ofuscação. É endurecimento.
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. Limite de tentativas de login
   --------------------------------------------------------------------------
   N erros pelo mesmo IP fecham a porta por M minutos — inclusive para a
   senha certa, senão o atacante saberia quando acertou.
   ========================================================================== */

if ( blindagem_ligado( 'limite_login' ) && ! ( defined( 'BLINDAGEM_MODO_SEGURO' ) && BLINDAGEM_MODO_SEGURO ) ) {

	function blindagem_chave_login( $ip ) {
		return 'blindagem_login_' . md5( $ip );
	}

	/**
	 * Bloqueio progressivo: até 2× o limite de erros, o tempo configurado;
	 * a partir de 2× o limite, 4× o tempo; a partir de 4×, 16× — no máximo
	 * 24 h. Robô insistente fica de fora por horas; quem errou a senha
	 * algumas vezes espera só o tempo normal.
	 */
	function blindagem_minutos_bloqueio( $erros ) {
		$maximo  = max( 1, (int) blindagem_opcao( 'tentativas' ) );
		$minutos = max( 1, (int) blindagem_opcao( 'minutos' ) );
		$fator   = $erros >= 4 * $maximo ? 16 : ( $erros >= 2 * $maximo ? 4 : 1 );
		return min( 1440, $minutos * $fator );
	}

	add_filter( 'authenticate', function ( $usuario, $login ) {
		if ( empty( $login ) ) {
			return $usuario; // Formulário vazio: deixa o WordPress reclamar do jeito dele.
		}

		$ip = blindagem_ip();
		if ( '' === $ip ) {
			return $usuario;
		}

		$maximo = max( 1, (int) blindagem_opcao( 'tentativas' ) );

		$erros = (int) get_transient( blindagem_chave_login( $ip ) );
		if ( $erros >= $maximo ) {
			$minutos = blindagem_minutos_bloqueio( $erros );
			return new WP_Error(
				'blindagem_bloqueado',
				sprintf(
					'<strong>Acesso bloqueado.</strong> Tentativas de login demais deste endereço. Tente de novo em %s.',
					$minutos >= 120 ? round( $minutos / 60 ) . ' horas' : $minutos . ' minutos'
				)
			);
		}

		return $usuario;
	}, 30, 2 );

	add_action( 'wp_login_failed', function () {
		$ip = blindagem_ip();
		if ( '' === $ip ) {
			return;
		}

		$chave = blindagem_chave_login( $ip );
		$erros = (int) get_transient( $chave ) + 1;
		set_transient( $chave, $erros, blindagem_minutos_bloqueio( $erros ) * MINUTE_IN_SECONDS );
	} );

	add_action( 'wp_login', function () {
		$ip = blindagem_ip();
		if ( '' !== $ip ) {
			delete_transient( blindagem_chave_login( $ip ) );
		}
	} );

	/**
	 * "A senha para X está incorreta" confirma que o usuário X existe.
	 * Só trocamos os erros de credencial: avisos como "ative os cookies"
	 * passam intactos, senão o usuário caça uma senha que estava certa.
	 */
	add_filter( 'login_errors', function ( $erro ) {
		global $errors;

		if ( ! is_wp_error( $errors ) ) {
			return $erro;
		}

		$de_credencial = array( 'invalid_username', 'invalid_email', 'incorrect_password' );

		foreach ( $errors->get_error_codes() as $codigo ) {
			if ( in_array( $codigo, $de_credencial, true ) ) {
				return '<strong>Erro:</strong> usuário ou senha incorretos.';
			}
		}

		return $erro;
	} );
}


/* ==========================================================================
   2. Enumeração de usuários
   --------------------------------------------------------------------------
   Descobrir o login do admin é metade de um ataque de força bruta. O
   WordPress entrega por três caminhos: /wp-json/wp/v2/users, ?author=1 (que
   redireciona para /author/<login>/) e o oEmbed.
   ========================================================================== */

if ( blindagem_ligado( 'enumeracao' ) ) {

	add_filter( 'rest_endpoints', function ( $rotas ) {
		if ( current_user_can( 'list_users' ) ) {
			return $rotas;
		}

		unset( $rotas['/wp/v2/users'], $rotas['/wp/v2/users/(?P<id>[\d]+)'] );

		return $rotas;
	} );

	/**
	 * ⚠️ Prioridade 0 é obrigatória: o redirect_canonical do core mora no
	 * template_redirect/10 e mandaria ?author=1 para /author/<login>/ antes
	 * deste código rodar.
	 */
	add_action( 'template_redirect', function () {
		if ( is_admin() || ! is_author() || current_user_can( 'list_users' ) ) {
			return;
		}

		nocache_headers();
		wp_safe_redirect( home_url( '/' ), 302 );
		exit;
	}, 0 );

	add_filter( 'oembed_response_data', function ( $dados ) {
		unset( $dados['author_name'], $dados['author_url'] );
		return $dados;
	} );

	// Autor fora do sitemap do core: as páginas redirecionam.
	add_filter( 'wp_sitemaps_add_provider', function ( $provedor, $nome ) {
		return 'users' === $nome ? false : $provedor;
	}, 10, 2 );
}


/* ==========================================================================
   3. XML-RPC
   --------------------------------------------------------------------------
   pingback.ping e system.multicall permitem força bruta amplificada
   (centenas de senhas por requisição) e usar o site como refletor de DDoS.
   Só desligue se usar o app móvel antigo ou o Jetpack.
   ========================================================================== */

if ( blindagem_ligado( 'xmlrpc_off' ) ) {

	add_filter( 'xmlrpc_enabled', '__return_false' );
	add_filter( 'xmlrpc_methods', '__return_empty_array' );

	add_filter( 'wp_headers', function ( $cabecalhos ) {
		unset( $cabecalhos['X-Pingback'] );
		return $cabecalhos;
	} );

	// 403 seco antes de o WordPress montar o XML-RPC inteiro: num ataque de
	// volume, gasta menos servidor.
	add_action( 'plugins_loaded', function () {
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			status_header( 403 );
			exit( 'XML-RPC desativado.' );
		}
	}, 1 );
}


/* ==========================================================================
   4. Cabeçalhos de segurança
   --------------------------------------------------------------------------
   Sem Content-Security-Policy de propósito: construtores como o Elementor
   geram script e style inline em quantidade, e uma CSP que não quebrasse o
   site precisaria de 'unsafe-inline' — o que não protege nada.
   ========================================================================== */

if ( blindagem_ligado( 'cabecalhos' ) ) {

	function blindagem_enviar_cabecalhos() {
		if ( headers_sent() ) {
			return;
		}

		header_remove( 'X-Powered-By' ); // versão exata do PHP
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' ); // não DENY: o preview de construtores usa iframe
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: geolocation=(), camera=(), microphone=(), payment=()' );

		/*
		 * HSTS: um ano, SEM includeSubDomains e SEM preload. Incluir
		 * subdomínios quebraria qualquer subdomínio que ainda não tenha HTTPS,
		 * e o preload é praticamente irreversível. Só em HTTPS.
		 */
		if ( is_ssl() && blindagem_ligado( 'hsts' ) ) {
			header( 'Strict-Transport-Security: max-age=31536000' );
		}
	}

	add_action( 'send_headers', 'blindagem_enviar_cabecalhos' );
	add_action( 'login_init', 'blindagem_enviar_cabecalhos' );
	add_action( 'admin_init', 'blindagem_enviar_cabecalhos' );
}


/* ==========================================================================
   5. Versões expostas e editor de arquivos
   --------------------------------------------------------------------------
   A versão exata entrega a lista de falhas conhecidas que vale tentar. Isto
   só encurta a janela até o próximo update — atualizar é o que protege.
   ========================================================================== */

if ( blindagem_ligado( 'esconder_versao' ) ) {

	remove_action( 'wp_head', 'wp_generator' );
	add_filter( 'the_generator', '__return_empty_string' );

	/**
	 * Cada plugin imprime o próprio <meta name="generator"> (o Elementor põe
	 * versão e recursos ligados). Em vez de caçar um por um, filtramos a
	 * saída do wp_head inteira.
	 */
	add_action( 'wp_head', function () {
		ob_start();
	}, 0 );

	add_action( 'wp_head', function () {
		if ( ob_get_level() < 1 ) {
			return;
		}
		echo preg_replace( '#<meta[^>]+name=["\']generator["\'][^>]*>\s*#i', '', ob_get_clean() );
	}, PHP_INT_MAX );
}

/**
 * Editor de temas e plugins do painel: com ele, quem rouba uma sessão de
 * admin escreve PHP no servidor em dois cliques. Sempre desligado.
 */
if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}


/* ==========================================================================
   6. Comentários
   --------------------------------------------------------------------------
   Para site institucional sem blog. Fechar pelo painel só vale para posts
   novos e não bloqueia o POST direto no wp-comments-post.php — que é o que o
   robô de spam usa. Aqui fecha os dois.
   ========================================================================== */

if ( blindagem_ligado( 'comentarios_off' ) ) {

	add_filter( 'comments_open', '__return_false', 20 );
	add_filter( 'pings_open', '__return_false', 20 );
	add_filter( 'comments_array', '__return_empty_array', 20 );

	add_filter( 'pre_comment_approved', function () {
		return new WP_Error( 'blindagem_comentarios_off', 'Os comentários estão desativados.', 403 );
	}, 99 );

	add_action( 'init', function () {
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? wp_basename( wp_unslash( $_SERVER['SCRIPT_NAME'] ) ) : '';
		if ( 'wp-comments-post.php' === $script ) {
			status_header( 403 );
			exit( 'Os comentários estão desativados neste site.' );
		}
	} );

	add_action( 'wp_enqueue_scripts', function () {
		wp_dequeue_script( 'comment-reply' );
	}, 100 );

	add_action( 'admin_menu', function () {
		remove_menu_page( 'edit-comments.php' );
	} );

	add_action( 'wp_dashboard_setup', function () {
		remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
	} );

	add_action( 'wp_before_admin_bar_render', function () {
		global $wp_admin_bar;
		if ( is_object( $wp_admin_bar ) ) {
			$wp_admin_bar->remove_menu( 'comments' );
		}
	} );

	add_action( 'admin_init', function () {
		global $pagenow;

		if ( 'edit-comments.php' === $pagenow ) {
			wp_safe_redirect( admin_url() );
			exit;
		}

		foreach ( get_post_types() as $tipo ) {
			if ( post_type_supports( $tipo, 'comments' ) ) {
				remove_post_type_support( $tipo, 'comments' );
				remove_post_type_support( $tipo, 'trackbacks' );
			}
		}
	} );
}


/* ==========================================================================
   6b. Anti-spam de comentários (quando os comentários estão ABERTOS)
   --------------------------------------------------------------------------
   Quatro filtros baratos, sem serviço externo nem captcha:
     - campo-isca escondido: humano não vê, robô preenche;
     - tempo mínimo: formulário enviado em menos de 3 s é robô;
     - links: mais de 2 links é spam quase sempre;
     - limite por IP: 5 comentários a cada 10 minutos.
   Comentário de usuário logado passa direto.
   ========================================================================== */

if ( ! blindagem_ligado( 'comentarios_off' ) && blindagem_ligado( 'comentarios_antispam' ) ) {

	add_action( 'comment_form', function () {
		$agora = time();
		printf(
			'<p style="position:absolute!important;left:-9999px!important" aria-hidden="true"><label>Não preencha<input type="text" name="blindagem_site" value="" tabindex="-1" autocomplete="off"></label></p>' .
			'<input type="hidden" name="blindagem_t" value="%d"><input type="hidden" name="blindagem_h" value="%s">',
			(int) $agora,
			esc_attr( wp_hash( 'blindagem_comentario' . $agora ) )
		);
	} );

	add_filter( 'preprocess_comment', function ( $comentario ) {
		if ( is_user_logged_in() || ( isset( $comentario['comment_type'] ) && in_array( $comentario['comment_type'], array( 'pingback', 'trackback' ), true ) ) ) {
			return $comentario;
		}

		// phpcs:disable WordPress.Security.NonceVerification -- formulário público de comentário; a "assinatura" é o hash do horário.
		$isca = isset( $_POST['blindagem_site'] ) ? (string) wp_unslash( $_POST['blindagem_site'] ) : '';
		$t    = isset( $_POST['blindagem_t'] ) ? (int) $_POST['blindagem_t'] : 0;
		$h    = isset( $_POST['blindagem_h'] ) ? (string) wp_unslash( $_POST['blindagem_h'] ) : '';
		// phpcs:enable

		$recusar = function ( $motivo ) {
			wp_die( esc_html( $motivo ), 'Comentário recusado', array( 'response' => 403, 'back_link' => true ) );
		};

		if ( '' !== $isca || ! $t || ! hash_equals( wp_hash( 'blindagem_comentario' . $t ), $h ) ) {
			$recusar( 'Comentário recusado. Recarregue a página e tente de novo.' );
		}
		if ( time() - $t < 3 ) {
			$recusar( 'Rápido demais. Espere alguns segundos e envie de novo.' );
		}
		if ( preg_match_all( '#https?://|www\.#i', (string) $comentario['comment_content'] ) > 2 ) {
			$recusar( 'Comentário com links demais.' );
		}

		$ip = blindagem_ip();
		if ( $ip ) {
			$chave  = 'blindagem_coment_' . md5( $ip );
			$feitos = (int) get_transient( $chave );
			if ( $feitos >= 5 ) {
				$recusar( 'Muitos comentários em pouco tempo. Tente de novo mais tarde.' );
			}
			set_transient( $chave, $feitos + 1, 10 * MINUTE_IN_SECONDS );
		}

		return $comentario;
	}, 1 );
}


/* ==========================================================================
   7. Registro de usuários e alerta de novo administrador
   --------------------------------------------------------------------------
   Registro aberto é caminho conhecido de escalada: cria-se um assinante e
   explora-se um plugin que confia em usuário logado. O alerta é DETECÇÃO:
   criar um admin é como o invasor mantém acesso depois que o backdoor some.
   ========================================================================== */

if ( blindagem_ligado( 'registro_off' ) ) {
	add_filter( 'pre_option_users_can_register', '__return_zero' );
}

if ( blindagem_ligado( 'alerta_admin' ) ) {

	add_action( 'set_user_role', function ( $user_id, $papel, $papeis_antigos ) {
		if ( 'administrator' !== $papel || in_array( 'administrator', (array) $papeis_antigos, true ) ) {
			return;
		}

		$usuario = get_userdata( $user_id );
		if ( ! $usuario ) {
			return;
		}

		$quem = is_user_logged_in() ? wp_get_current_user()->user_login : '(ninguém logado — suspeito)';

		wp_mail(
			blindagem_email_alerta(),
			sprintf( '[%s] ALERTA: novo administrador no site', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
			sprintf(
				"Um usuário virou administrador em %s.\n\n" .
				"Login......: %s\nE-mail.....: %s\nQuem fez...: %s\nIP.........: %s\nQuando.....: %s\n\n" .
				"Se não foi você, é sinal de invasão: remova o usuário, troque as senhas\n" .
				"e rode `wp config shuffle-salts` (derruba toda sessão aberta).\n",
				home_url( '/' ),
				$usuario->user_login,
				$usuario->user_email,
				$quem,
				blindagem_ip(),
				current_time( 'd/m/Y H:i:s' )
			)
		);
	}, 10, 3 );
}


/* ==========================================================================
   8. Upload
   --------------------------------------------------------------------------
   Três camadas, porque cada uma falha num cenário diferente:
     - lista BRANCA de tipos (lista negra sempre esquece um: .phar, .pht…);
     - recusa extensão perigosa em QUALQUER segmento do nome (foto.php.jpg);
     - .htaccess em uploads/ que impede PHP de rodar ali (Apache/LiteSpeed).
   ========================================================================== */

if ( blindagem_ligado( 'upload_restrito' ) ) {

	add_filter( 'upload_mimes', function () {
		/** Filtro para um site específico liberar outro tipo sem editar o plugin. */
		return apply_filters( 'blindagem_tipos_upload', array(
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png'          => 'image/png',
			'gif'          => 'image/gif',
			'webp'         => 'image/webp',
			'avif'         => 'image/avif',
			'svg'          => 'image/svg+xml',
			'ico'          => 'image/x-icon',
			'pdf'          => 'application/pdf',
			'doc'          => 'application/msword',
			'docx'         => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'xls'          => 'application/vnd.ms-excel',
			'xlsx'         => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'ppt'          => 'application/vnd.ms-powerpoint',
			'pptx'         => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
			'odt'          => 'application/vnd.oasis.opendocument.text',
			'mp3'          => 'audio/mpeg',
			'mp4|m4v'      => 'video/mp4',
			'webm'         => 'video/webm',
		) );
	}, 99 );

	add_filter( 'wp_handle_upload_prefilter', function ( $arquivo ) {
		$proibidas = array(
			'php', 'php2', 'php3', 'php4', 'php5', 'php6', 'php7', 'php8',
			'phtml', 'pht', 'phar', 'phps', 'cgi', 'pl', 'py', 'sh', 'bash',
			'htaccess', 'htpasswd', 'user', 'ini', 'exe', 'dll', 'so', 'jsp', 'asp', 'aspx',
		);

		foreach ( explode( '.', strtolower( $arquivo['name'] ) ) as $pedaco ) {
			if ( in_array( $pedaco, $proibidas, true ) ) {
				$arquivo['error'] = 'Este tipo de arquivo não pode ser enviado.';
				return $arquivo;
			}
		}

		return $arquivo;
	} );

	/**
	 * SVG é XML e pode carregar <script> — vira XSS no painel. Fica liberado
	 * porque logo costuma ser SVG, mas só para admin e sem nada executável.
	 */
	add_filter( 'wp_handle_upload_prefilter', function ( $arquivo ) {
		if ( ! empty( $arquivo['error'] ) || 'svg' !== strtolower( pathinfo( $arquivo['name'], PATHINFO_EXTENSION ) ) ) {
			return $arquivo;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			$arquivo['error'] = 'Apenas administradores podem enviar SVG.';
			return $arquivo;
		}

		$svg = file_get_contents( $arquivo['tmp_name'] );

		if ( false === $svg || blindagem_svg_perigoso( $svg ) ) {
			$arquivo['error'] = 'Este SVG contém script ou conteúdo ativo e foi recusado.';
		}

		return $arquivo;
	} );
}

/**
 * O SVG tem algo que executa? Confere o texto como está e também "desmontado"
 * do jeito que o navegador lê: entidades decodificadas (&#106;avascript:
 * vira javascript:) e sem espaço/tab/quebra de linha dentro do esquema do
 * link (java&#9;script: também funciona no navegador).
 * Imagem embutida (data:image/png…) é comum em logo exportado e continua
 * aceita; qualquer outro data: é recusado.
 */
function blindagem_svg_perigoso( $svg ) {
	$tags = '/<script|<foreignObject|<!ENTITY|<iframe|<embed|<object|<handler|<listener|\son[a-z]+\s*=/i';
	if ( preg_match( $tags, $svg ) ) {
		return true;
	}

	// O navegador aceita entidade numérica sem o ";" final; o PHP não. Completa antes de decodificar.
	$decodificado = preg_replace( '/&#(x[0-9a-f]+|[0-9]+);?/i', '&#$1;', $svg );
	$decodificado = html_entity_decode( $decodificado, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

	if ( preg_match( $tags, $decodificado ) ) {
		return true;
	}

	$compacto = strtolower( preg_replace( '/[\x00-\x20]+/', '', $decodificado ) );

	return (bool) preg_match( '/(javascript|vbscript|livescript):|data:(?!image\/(png|jpe?g|gif|webp)[;,])/', $compacto );
}

/**
 * Escreve (ou remove) o bloco do plugin no uploads/.htaccess. Usa os
 * marcadores do próprio WordPress, então não encosta em regra de terceiros.
 * Só tem efeito em Apache/LiteSpeed; em nginx a regra vai na config do
 * servidor — ver o LEIA-ME.
 */
function blindagem_htaccess_uploads( $ligar ) {
	if ( ! function_exists( 'insert_with_markers' ) ) {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
	}

	$dir = wp_get_upload_dir();
	$dir = $dir['basedir'];

	if ( ! wp_mkdir_p( $dir ) ) {
		return false;
	}

	$linhas = $ligar ? array(
		'# Nenhum arquivo enviado pode rodar como código.',
		'<FilesMatch "\.(php[0-9]?|pht|phtml|phar|phps|cgi|pl|py|sh)$">',
		'    Require all denied',
		'</FilesMatch>',
	) : array();

	// Desligando e sem arquivo: nada a remover.
	if ( ! $ligar && ! file_exists( $dir . '/.htaccess' ) ) {
		return true;
	}

	return insert_with_markers( $dir . '/.htaccess', 'Blindagem', $linhas );
}


/* ==========================================================================
   9. Atualização automática
   --------------------------------------------------------------------------
   Plugin desatualizado é o vetor número um de invasão em WordPress. Plugins,
   temas e versões menores do core se atualizam sozinhos; versão MAIOR do
   core (7.x → 8.x) não, porque costuma quebrar plugin. O WordPress manda
   e-mail a cada atualização automática.
   ========================================================================== */

if ( blindagem_ligado( 'autoupdate' ) ) {
	add_filter( 'allow_minor_auto_core_updates', '__return_true' );
	add_filter( 'allow_major_auto_core_updates', '__return_false' );
	add_filter( 'auto_update_plugin', '__return_true' );
	add_filter( 'auto_update_theme', '__return_true' );
}


/* ==========================================================================
   10. Recuperação de senha
   --------------------------------------------------------------------------
   O "esqueci a senha" dispara e-mail: sem limite, vira ferramenta de spam
   contra o dono da conta e de descoberta de usuário. Mesmo contador do
   login, chave separada.
   ========================================================================== */

if ( blindagem_ligado( 'limite_senha' ) ) {

	add_action( 'lostpassword_post', function ( $erros ) {
		$ip = blindagem_ip();
		if ( '' === $ip ) {
			return;
		}

		$chave  = 'blindagem_senha_' . md5( $ip );
		$pedido = (int) get_transient( $chave );

		if ( $pedido >= 3 ) {
			$erros->add( 'blindagem_senha', '<strong>Erro:</strong> pedidos demais. Tente de novo em uma hora.' );
			return;
		}

		set_transient( $chave, $pedido + 1, HOUR_IN_SECONDS );
	} );
}


/* ==========================================================================
   11. Senha forte
   --------------------------------------------------------------------------
   O medidor do WordPress só avisa; aqui a senha fraca é recusada ao criar
   usuário, editar perfil e redefinir senha. Regra simples de explicar:
   12 caracteres, com letras e números.
   ========================================================================== */

if ( blindagem_ligado( 'senha_forte' ) ) {

	function blindagem_senha_fraca( $senha ) {
		return strlen( $senha ) < 12 || ! preg_match( '/[a-z]/i', $senha ) || ! preg_match( '/[0-9]/', $senha );
	}

	$mensagem_senha = '<strong>Erro:</strong> a senha precisa ter pelo menos 12 caracteres, com letras e números.';

	add_action( 'user_profile_update_errors', function ( $erros ) use ( $mensagem_senha ) {
		$senha = isset( $_POST['pass1'] ) ? (string) wp_unslash( $_POST['pass1'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- o core já validou o nonce.
		if ( '' !== $senha && blindagem_senha_fraca( $senha ) ) {
			$erros->add( 'blindagem_senha_fraca', $mensagem_senha );
		}
	} );

	add_action( 'validate_password_reset', function ( $erros ) use ( $mensagem_senha ) {
		$senha = isset( $_POST['pass1'] ) ? (string) wp_unslash( $_POST['pass1'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- o core já validou a chave.
		if ( '' !== $senha && blindagem_senha_fraca( $senha ) ) {
			$erros->add( 'blindagem_senha_fraca', $mensagem_senha );
		}
	} );
}


/* ==========================================================================
   12. Senhas de aplicativo e sessão
   --------------------------------------------------------------------------
   Senha de aplicativo dá acesso à API sem passar pelo limite de login nem
   pelo formulário — é porta que ninguém lembra que está aberta. Religue se
   usar app móvel ou integração externa.

   Sessão: "lembrar de mim" passa de 14 para 7 dias; sem ele, 12 horas.
   Cookie roubado vale menos tempo.
   ========================================================================== */

if ( blindagem_ligado( 'app_passwords' ) ) {
	add_filter( 'wp_is_application_passwords_available', '__return_false' );
}

if ( blindagem_ligado( 'sessao_curta' ) ) {
	add_filter( 'auth_cookie_expiration', function ( $segundos, $user_id, $lembrar ) {
		return $lembrar ? 7 * DAY_IN_SECONDS : 12 * HOUR_IN_SECONDS;
	}, 10, 3 );
}


/* ==========================================================================
   13. API REST só para usuários logados (desligado por padrão)
   --------------------------------------------------------------------------
   Fecha a API inteira para anônimos. Desligado por padrão porque formulário
   de contato, busca e alguns construtores usam a API pelo lado do visitante.
   Ligue e teste o site.
   ========================================================================== */

if ( blindagem_ligado( 'rest_privada' ) ) {
	add_filter( 'rest_authentication_errors', function ( $resultado ) {
		if ( ! empty( $resultado ) || is_user_logged_in() ) {
			return $resultado;
		}
		return new WP_Error( 'blindagem_rest_privada', 'API disponível só para usuários logados.', array( 'status' => 401 ) );
	} );
}


/* ==========================================================================
   14. Registro de acessos
   --------------------------------------------------------------------------
   Os últimos 200 logins (certos, errados e bloqueados), com IP e hora. É o
   que responde "alguém entrou no painel?" depois de um susto. Fica numa
   opção, sem tabela nova; não guarda senha.
   ========================================================================== */

if ( blindagem_ligado( 'registro_acesso' ) ) {

	function blindagem_registrar_acesso( $evento, $login ) {
		$log = get_option( 'blindagem_acessos', array() );
		$log = is_array( $log ) ? $log : array();

		array_unshift( $log, array(
			'quando' => current_time( 'mysql' ),
			'evento' => $evento,
			'login'  => mb_substr( sanitize_user( (string) $login ), 0, 60 ),
			'ip'     => blindagem_ip(),
			'ua'     => isset( $_SERVER['HTTP_USER_AGENT'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 200 ) : '',
		) );

		update_option( 'blindagem_acessos', array_slice( $log, 0, 200 ), false );
	}

	add_action( 'wp_login', function ( $login ) {
		blindagem_registrar_acesso( 'entrou', $login );
	} );

	add_action( 'wp_login_failed', function ( $login, $erro = null ) {
		$bloqueado = is_wp_error( $erro ) && in_array( 'blindagem_bloqueado', $erro->get_error_codes(), true );
		blindagem_registrar_acesso( $bloqueado ? 'bloqueado' : 'falhou', $login );
	}, 10, 2 );
}


/* ==========================================================================
   15. Limpeza do <head>
   --------------------------------------------------------------------------
   RSD e wlwmanifest servem a editores de desktop que ninguém usa mais e só
   anunciam o endpoint do XML-RPC.
   ========================================================================== */

remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
