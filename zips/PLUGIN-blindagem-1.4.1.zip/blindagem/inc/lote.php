<?php
/**
 * Ações em lote: marcar vários itens e aplicar de uma vez (achados da verificação, quarentena e agendamentos).
 *
 * As linhas das tabelas já têm formulários próprios (botões de cada item) e formulário não pode ficar dentro de
 * outro: a caixinha de cada linha aponta para o formulário do lote pelo atributo HTML form="…".
 * Cada item passa pela MESMA função da ação individual — as mesmas travas (quarentena só do que pode sair,
 * agendamento do WordPress protegido, órfã só sem dono) valem no lote.
 */

defined( 'ABSPATH' ) || exit;

const BLINDAGEM_LOTE_MAX = 500; // Por envio: protege do tempo limite do PHP em hospedagem compartilhada.

/**
 * Barra do lote (antes da tabela): escolha da ação + botão. $opcoes = [ valor => rótulo ].
 * $grupos = [ grupo => [ rótulo, quantidade ] ] vira atalhos "Marcar só: …" (ex.: todos os "SUMIU" de uma vez).
 */
function blindagem_lote_barra( $form, $acao, array $opcoes, array $grupos = array() ) {
	printf( '<form id="%s" method="post" action="%s" style="margin:.5em 0">', esc_attr( $form ), esc_url( admin_url( 'admin-post.php' ) ) );
	printf( '<input type="hidden" name="action" value="%s">', esc_attr( $acao ) );
	wp_nonce_field( $acao );
	echo '<select name="op">';
	foreach ( $opcoes as $valor => $rotulo ) {
		printf( '<option value="%s">%s</option>', esc_attr( $valor ), esc_html( $rotulo ) );
	}
	echo '</select> ';
	printf(
		'<button type="submit" class="button" onclick="%s">Aplicar aos marcados</button>',
		esc_attr( "var n=document.querySelectorAll('input[form=\"" . $form . "\"][name=\"itens[]\"]:checked').length;if(!n){alert('Marque pelo menos um item.');return false;}return confirm(this.form.op.options[this.form.op.selectedIndex].text+' — '+n+' item(ns). Confirmar?');" )
	);
	if ( count( $grupos ) > 1 ) {
		echo ' <span class="description" style="margin-left:1em">Marcar só:</span> ';
		foreach ( $grupos as $grupo => [ $rotulo, $qtd ] ) {
			printf(
				'<button type="button" class="button-link" style="margin:0 .6em" onclick="%s">%s (%d)</button>',
				esc_attr( "document.querySelectorAll('input[form=\"" . $form . "\"][name=\"itens[]\"]').forEach(function(x){x.checked=x.dataset.grupo==='" . $grupo . "';});" ),
				esc_html( $rotulo ),
				(int) $qtd
			);
		}
	}
	echo '</form>';
}

/** Caixinha "marcar todos" do cabeçalho da tabela. */
function blindagem_lote_todos( $form ) {
	printf(
		'<th style="width:2em"><input type="checkbox" aria-label="Marcar todos" onclick="%s"></th>',
		esc_attr( "var c=this.checked;document.querySelectorAll('input[form=\"" . $form . "\"][name=\"itens[]\"]').forEach(function(x){x.checked=c;});" )
	);
}

/** Caixinha de uma linha (vazia = linha sem ação em lote). */
function blindagem_lote_caixa( $form, $valor = null, $grupo = '' ) {
	if ( null === $valor ) {
		echo '<td></td>';
		return;
	}
	printf( '<td><input type="checkbox" name="itens[]" value="%s" form="%s" data-grupo="%s" aria-label="Marcar"></td>', esc_attr( $valor ), esc_attr( $form ), esc_attr( sanitize_key( $grupo ) ) );
}

/** Itens marcados (texto, sem repetir, até o máximo). */
function blindagem_lote_itens() {
	$itens = isset( $_POST['itens'] ) && is_array( $_POST['itens'] ) ? wp_unslash( $_POST['itens'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- nonce conferido antes; cada item é comparado com o relatório ou validado na ação.
	$itens = array_values( array_unique( array_filter( array_map( 'strval', $itens ), 'strlen' ) ) );
	return array_slice( $itens, 0, BLINDAGEM_LOTE_MAX );
}

function blindagem_lote_op( array $permitidas ) {
	$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- conferido antes.
	return in_array( $op, $permitidas, true ) ? $op : '';
}

/** Volta para a aba com o resumo: "12 feitos; 2 não (motivo)". */
function blindagem_lote_voltar( $aba, $feitos, array $erros ) {
	$texto = sprintf( '%d item(ns) feito(s).', $feitos );
	if ( $erros ) {
		$contagem = array_count_values( $erros );
		$partes   = array();
		foreach ( $contagem as $motivo => $qtd ) {
			$partes[] = $qtd . ' × ' . $motivo;
		}
		$texto .= ' Não deu: ' . implode( ' · ', $partes );
	}
	set_transient( 'blindagem_lote_' . get_current_user_id(), array( $erros ? 'warning' : 'success', $texto ), MINUTE_IN_SECONDS );
	blindagem_voltar( $aba, 'lote' );
}

/* Achados da verificação: pôr em quarentena ou reconhecer. */
add_action( 'admin_post_blindagem_lote_achados', function () {
	blindagem_conferir_permissao( 'blindagem_lote_achados' );
	$op     = blindagem_lote_op( array( 'quarentena', 'reconhecer' ) );
	$feitos = 0;
	$erros  = array();
	foreach ( $op ? blindagem_lote_itens() : array() as $arquivo ) {
		$erro = 'quarentena' === $op ? blindagem_por_em_quarentena( $arquivo ) : blindagem_reconhecer_um( $arquivo );
		if ( $erro ) {
			$erros[] = $erro;
		} else {
			++$feitos;
		}
	}
	blindagem_lote_voltar( 'verificacao', $feitos, $erros );
} );

/* Quarentena: apagar de vez ou restaurar. */
add_action( 'admin_post_blindagem_lote_quarentena', function () {
	blindagem_conferir_permissao( 'blindagem_lote_quarentena' );
	$op     = blindagem_lote_op( array( 'apagar', 'restaurar' ) );
	$feitos = 0;
	$erros  = array();
	foreach ( $op ? blindagem_lote_itens() : array() as $id ) {
		$id   = sanitize_key( $id );
		$erro = 'apagar' === $op ? blindagem_apagar_quarentena( $id ) : blindagem_restaurar_quarentena( $id );
		if ( $erro ) {
			$erros[] = $erro;
		} else {
			++$feitos;
		}
	}
	blindagem_lote_voltar( 'verificacao', $feitos, $erros );
} );

/* Agendamentos: remover órfãs ou pausar as de plugin/tema (as do WordPress continuam protegidas). */
add_action( 'admin_post_blindagem_lote_cron', function () {
	blindagem_conferir_permissao( 'blindagem_lote_cron' );
	$op     = blindagem_lote_op( array( 'remover', 'pausar' ) );
	$feitos = 0;
	$erros  = array();
	foreach ( $op ? blindagem_lote_itens() : array() as $hook ) {
		$hook = blindagem_hook_valido( sanitize_text_field( $hook ) );
		$ok   = $hook && ( 'remover' === $op ? blindagem_cron_remover_hook( $hook ) : blindagem_cron_pausar_hook( $hook ) );
		if ( $ok ) {
			++$feitos;
		} else {
			$erros[] = 'remover' === $op ? 'não é órfã (tem dono) ou é do WordPress' : 'protegida ou já parada';
		}
	}
	blindagem_lote_voltar( 'agenda', $feitos, $erros );
} );
