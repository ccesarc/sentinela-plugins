<?php
/**
 * Remoção completa ao apagar o plugin pelo painel (desativar não apaga nada).
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'blindagem_opcoes', 'blindagem_acessos', 'blindagem_reconhecidos', 'blindagem_sem_checksum',
	'blindagem_rel_varredura', 'blindagem_rel_integridade', 'blindagem_alertado_varredura', 'blindagem_alertado_integridade', 'blindagem_alertado_diagnostico', 'blindagem_cron_pausadas', 'blindagem_eventos', 'blindagem_quarentena', 'blindagem_quarentena_pasta', 'blindagem_quarentena_dir', 'blindagem_foto' ) as $opcao ) {
	delete_option( $opcao );
}

wp_clear_scheduled_hook( 'blindagem_varredura' );
wp_clear_scheduled_hook( 'blindagem_integridade' );
