<?php
/**
 * Plugin Name:       Blindagem — Segurança
 * Description:       Endurece o WordPress (login, XML-RPC, enumeração de usuários, upload, cabeçalhos) e vigia arquivos suspeitos e a integridade do core e dos plugins contra o oficial do wordpress.org. Genérico: tudo se configura em Configurações → Blindagem.
 * Version:           1.4.1
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Caio
 * License:           GPL-2.0-or-later
 * Text Domain:       blindagem
 * Update URI:        https://raw.githubusercontent.com/ccesarc/sentinela-plugins
 *
 * Trancou-se fora do painel? Coloque no wp-config.php:
 *     define( 'BLINDAGEM_MODO_SEGURO', true );
 * (desliga o limite de login) — ou apague a pasta deste plugin: o WordPress
 * desativa sozinho o plugin que sumiu.
 */

defined( 'ABSPATH' ) || exit;

define( 'BLINDAGEM_VERSAO', '1.4.1' );
define( 'BLINDAGEM_ARQUIVO', __FILE__ );

require_once __DIR__ . '/inc/opcoes.php';
require_once __DIR__ . '/inc/seguranca.php';
require_once __DIR__ . '/inc/deteccao.php';
require_once __DIR__ . '/inc/foto.php';
require_once __DIR__ . '/inc/diagnostico.php';
require_once __DIR__ . '/inc/dois-fatores.php';
require_once __DIR__ . '/inc/eventos.php';
require_once __DIR__ . '/inc/vigia.php';
require_once __DIR__ . '/inc/atualizador.php';

Divullg_Atualizador_1::registrar( 'blindagem', __FILE__ );

if ( is_admin() ) {
	require_once __DIR__ . '/inc/painel.php';
	require_once __DIR__ . '/inc/quarentena.php';
	require_once __DIR__ . '/inc/lote.php';
	require_once __DIR__ . '/inc/sessoes.php';
}

register_activation_hook( __FILE__, 'blindagem_ativar' );
register_deactivation_hook( __FILE__, 'blindagem_desativar' );

function blindagem_ativar() {
	blindagem_agendar();
	blindagem_htaccess_uploads( blindagem_ligado( 'upload_restrito' ) );
}

function blindagem_desativar() {
	wp_clear_scheduled_hook( 'blindagem_varredura' );
	wp_clear_scheduled_hook( 'blindagem_integridade' );
	wp_clear_scheduled_hook( 'blindagem_varredura_ja' );
	blindagem_htaccess_uploads( false );
}
