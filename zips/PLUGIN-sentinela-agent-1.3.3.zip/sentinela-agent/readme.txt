=== Sentinela Agent ===
Stable tag: 1.3.3
Requires at least: 6.0
Requires PHP: 7.4

Agente SOMENTE LEITURA do painel Sentinela (uso interno).

== O que faz ==
A cada 6 horas (e logo depois de login de admin, usuário novo, plugin/tema/core
atualizado) envia ao painel: versões do WordPress, plugins, temas e PHP;
atualizações disponíveis; logins dos administradores e a rede (nunca o IP
inteiro) de onde entraram; se o WP-Cron está em dia; arquivos do core que
diferem do oficial; PHP dentro de uploads; assinaturas de código malicioso;
hash dos arquivos de cada plugin/tema; algumas constantes de configuração.

== O que NÃO faz ==
* Não altera nada no site.
* Não recebe comandos: a resposta do painel é ignorada.
* Não cria rota REST, AJAX nem página pública.
* Não envia conteúdo de arquivos, senhas, e-mails ou dados de clientes.

== Instalação ==
1. No painel Sentinela: site → Agente → "Gerar segredo" (pede 2FA).
2. Copie as três linhas para o wp-config.php (acima de "That's all, stop editing"):
   define( 'SENTINELA_SITE_ID', '...' );
   define( 'SENTINELA_SECRET', '...' );
   define( 'SENTINELA_ENDPOINT', 'https://.../api/v1/agent/report' );
3. Envie esta pasta para wp-content/plugins/ e ative.
4. Recomendado: cron real do servidor (WP-Cron só roda com visita):
   */15 * * * * wp --path=/caminho/do/site cron event run --due-now >/dev/null
