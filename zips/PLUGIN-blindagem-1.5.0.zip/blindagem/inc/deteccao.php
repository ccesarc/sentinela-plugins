<?php
/**
 * Detecção: parte do princípio de que uma porta foi aberta assim mesmo e
 * procura o rastro.
 *
 *   Varredura (diária)   — arquivo que não deveria existir: PHP em uploads/,
 *                          compactado de nome aleatório, mu-plugin, drop-in,
 *                          código com cara de backdoor.
 *   Integridade (semanal) — arquivo LEGÍTIMO que foi ALTERADO, comparando o
 *                          core e os plugins com o oficial do wordpress.org.
 *
 * Achado que o admin conferiu e sabe que é legítimo pode ser "reconhecido":
 * guardamos o hash e ele só volta a aparecer se o arquivo mudar.
 *
 * Não é antimalware: não tem base de assinaturas nem limpa nada. Avisa.
 */

defined( 'ABSPATH' ) || exit;

/** Rótulos dos tipos de achado — usados no e-mail e no painel. */
function blindagem_tipos_achado() {
	return array(
		'php_uploads'     => 'PHP dentro de uploads/ (nunca deveria existir)',
		'compactado'      => 'Compactado de nome aleatório em wp-content/',
		'mu_plugin'       => 'mu-plugin (executa sempre e não aparece na lista de plugins)',
		'raiz_conteudo'   => 'PHP solto em wp-content/ (drop-in ou arquivo estranho)',
		'codigo'          => 'Código com cara de backdoor',
		'assinatura'      => 'Bate com assinatura aberta de vírus (php-malware-finder) — confira; só aviso, não vai para a quarentena',
		'core_alterado'   => 'Arquivo do WordPress ALTERADO (não bate com o oficial)',
		'core_extra'      => 'Arquivo que não faz parte do WordPress, dentro do core',
		'plugin_alterado' => 'Arquivo de plugin ALTERADO (não bate com o wordpress.org)',
		'plugin_extra'    => 'Arquivo PHP a mais dentro de plugin do wordpress.org',
		'banco_script'    => 'Script suspeito gravado no banco (post, página ou opção)',
		'cron_suspeito'   => 'Tarefa agendada (WP-Cron) suspeita',
		'foto_novo'       => 'Arquivo NOVO em tema/plugin sem original oficial (não estava na foto)',
		'foto_alterado'   => 'Arquivo ALTERADO em tema/plugin sem original oficial (diferente da foto)',
		'foto_pasta'      => 'Tema/plugin instalado ou atualizado por fora do painel (muitos arquivos de uma vez, nenhum com código suspeito)',
		'foto_apagado'    =>'Arquivo SUMIU (existia na última foto). Aviso de que foi apagado — se foi você, clique Reconhecer',
		'nome_estranho'   => 'Arquivo com nome inválido (bytes que não são texto) — comum em sobra de invasão',
		'php_disfarcado'  => 'Código PHP dentro de arquivo que não é .php (imagem, texto, sem extensão)',
		'raiz_desconhecido' => 'Arquivo desconhecido na raiz do site',
		'escondido'       => 'Arquivo ESCONDIDO (nome começa com ponto) em wp-content — marcador ou carga guardada por malware',
		'config_php'      => 'Configuração do servidor que executa PHP de outro jeito (.htaccess / .user.ini)',
		'plugin_casca'    => 'Pasta em plugins/ que NÃO é plugin (sem cabeçalho: vazia, quebrada ou casca de malware)',
		'plugin_escondido' => 'Plugin ATIVO que se esconde da lista de plugins do painel (técnica de malware)',
		'plugin_fora_wporg' => 'Plugin que não está no wordpress.org (pago, próprio… ou falso) — confira se você instalou',
	);
}


/* ==========================================================================
   Agenda
   ========================================================================== */

add_filter( 'cron_schedules', function ( $agendas ) {
	if ( ! isset( $agendas['weekly'] ) ) {
		$agendas['weekly'] = array( 'interval' => WEEK_IN_SECONDS, 'display' => 'Uma vez por semana' );
	}
	return $agendas;
} );

function blindagem_agendar() {
	if ( ! wp_next_scheduled( 'blindagem_varredura' ) ) {
		wp_schedule_event( time() + 300, 'daily', 'blindagem_varredura' );
	}
	if ( ! wp_next_scheduled( 'blindagem_integridade' ) ) {
		wp_schedule_event( time() + 900, 'weekly', 'blindagem_integridade' );
	}
}

// Rede de segurança: se o agendamento sumir (cron limpo, migração), recria.
add_action( 'admin_init', 'blindagem_agendar' );

/** Tarefas de plugin/tema pausadas na aba Agendamentos: hook => eventos guardados para retomar. */
function blindagem_cron_pausadas() {
	$pausadas = get_option( 'blindagem_cron_pausadas', array() );
	return is_array( $pausadas ) ? $pausadas : array();
}

// Plugin com tarefa pausada tenta reagendar a cada carregamento: recusa.
add_filter( 'schedule_event', function ( $evento ) {
	if ( $evento && isset( blindagem_cron_pausadas()[ $evento->hook ] ) ) {
		return false;
	}
	return $evento;
} );

add_action( 'blindagem_varredura', function () {
	if ( blindagem_ligado( 'varredura' ) ) {
		blindagem_rodar( 'varredura' );
	}
} );

add_action( 'blindagem_integridade', function () {
	if ( blindagem_ligado( 'integridade' ) ) {
		blindagem_rodar( 'integridade' );
	}
} );


/* ==========================================================================
   Utilitários
   ========================================================================== */

/** Caminho relativo à raiz do WordPress, para caber no e-mail e no painel. */
/**
 * Caminho como guardado no relatório. Nome com bytes que não são UTF-8 quebraria o banco (o texto é cortado),
 * o JSON e o formulário do botão — vai codificado como "b64:…". blindagem_absoluto() decodifica.
 */
function blindagem_guardavel( $relativo ) {
	return mb_check_encoding( $relativo, 'UTF-8' ) ? $relativo : 'b64:' . base64_encode( $relativo );
}

/** Caminho para mostrar na tela e no e-mail: bytes inválidos viram \xNN. */
function blindagem_visivel( $guardado ) {
	if ( 0 !== strpos( (string) $guardado, 'b64:' ) ) {
		return (string) $guardado;
	}
	$bruto = (string) base64_decode( substr( $guardado, 4 ), true );
	$saida = '';
	$n     = strlen( $bruto );
	for ( $i = 0; $i < $n; $i++ ) {
		$c = $bruto[ $i ];
		$o = ord( $c );
		$saida .= ( $o < 32 || $o > 126 ) ? sprintf( '\\x%02X', $o ) : $c;
	}
	return $saida . '  (nome inválido)';
}

/** Nome com bytes que não são texto, caracteres de controle ou símbolos que nenhum arquivo legítimo usa. */
function blindagem_nome_estranho( $nome ) {
	return ! mb_check_encoding( $nome, 'UTF-8' ) || (bool) preg_match( '/[\x00-\x1F\x7F<>"|*?\\\\]/', $nome );
}

/** Arquivo (não .php) com abertura de código PHP no começo ou no fim — lê só 64 KB de cada ponta. */
function blindagem_tem_php( $caminho ) {
	$tamanho = (int) @filesize( $caminho ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	if ( $tamanho < 5 ) {
		return false;
	}
	$h = @fopen( $caminho, 'rb' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
	if ( ! $h ) {
		return false;
	}
	$texto = (string) fread( $h, min( $tamanho, 65536 ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( $tamanho > 65536 ) {
		fseek( $h, -65536, SEEK_END );
		$texto .= (string) fread( $h, 65536 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	fclose( $h ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	// "<?php" + espaço, ou "<?=" seguido de variável/função: em imagem comprimida "<?=" sozinho aparece por acaso
	// (3 bytes em centenas de milhares de bytes aleatórios — 14 falsos alarmes em PNG no site da Caruaru Joias).
	return (bool) preg_match( '/<\?php[\s\/]|<\?=\s*\$?[A-Za-z_]\w*\s*[\(\[;]/i', $texto );
}

/** Arquivos que costumam existir na raiz de um WordPress (além dos .php, que a integridade confere). */
function blindagem_raiz_conhecido( $nome ) {
	return (bool) preg_match( '/^(readme\.html|license\.txt|\.htaccess(\.bk|\.bak|\.old)?|\.user\.ini|php\.ini|robots\.txt|favicon\.ico|ads\.txt|app-ads\.txt|llms\.txt|security\.txt|error_log|__HB__|\.ftpquota|\.DS_Store|google[0-9a-f]+\.html|BingSiteAuth\.xml|yandex_[0-9a-f]+\.html|sitemap[\w-]*\.xml(\.gz)?|.+\.php)$/i', $nome );
}

/** Linha de configuração que faz o servidor rodar PHP por fora (prepend, handler para outra extensão). */
function blindagem_config_suspeita( $caminho ) {
	$texto = (string) @file_get_contents( $caminho, false, null, 0, 262144 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
	foreach ( preg_split( '/\R/', $texto ) as $n => $linha ) {
		$limpa = trim( $linha );
		if ( '' === $limpa || '#' === $limpa[0] || ';' === $limpa[0] ) {
			continue;
		}
		if ( preg_match( '/auto_(prepend|append)_file/i', $limpa ) && ! preg_match( '/wordfence-waf\.php["\']?\s*$/i', $limpa ) ) {
			return 'linha ' . ( $n + 1 ) . ': ' . mb_substr( $limpa, 0, 160 );
		}
		// Handler de PHP ligado a extensão que não é de código (".jpg" vira programa). O ".php" da Hostinger é normal.
		if ( preg_match( '/^(AddHandler|SetHandler|AddType|ForceType)\b.*(php|x-httpd)/i', $limpa ) && preg_match( '/\.(jpe?g|png|gif|ico|bmp|webp|svg|txt|html?|css|js|pdf|zip|log)\b/i', $limpa ) ) {
			return 'linha ' . ( $n + 1 ) . ': ' . mb_substr( $limpa, 0, 160 );
		}
	}
	return '';
}

function blindagem_relativo( $caminho ) {
	$caminho = wp_normalize_path( $caminho );
	$raiz    = wp_normalize_path( ABSPATH );
	return 0 === strpos( $caminho, $raiz ) ? substr( $caminho, strlen( $raiz ) ) : $caminho;
}

/**
 * Percorre uma pasta e chama $callback( SplFileInfo ) em cada arquivo.
 * Devolve false no callback para parar. Pula links simbólicos e pastas
 * .git/node_modules, que só gastam tempo.
 */
function blindagem_percorrer( $pasta, $callback ) {
	if ( ! is_dir( $pasta ) ) {
		return;
	}

	try {
		$diretorio = new RecursiveDirectoryIterator( $pasta, FilesystemIterator::SKIP_DOTS );
		$filtro    = new RecursiveCallbackFilterIterator( $diretorio, function ( $atual ) {
			if ( $atual->isLink() ) {
				return false;
			}
			return ! ( $atual->isDir() && in_array( $atual->getFilename(), array( '.git', 'node_modules' ), true ) );
		} );

		foreach ( new RecursiveIteratorIterator( $filtro ) as $arquivo ) {
			if ( $arquivo->isFile() && false === $callback( $arquivo ) ) {
				return;
			}
		}
	} catch ( Exception $e ) {
		return; // Pasta sem permissão de leitura: segue com o resto.
	}
}

/**
 * Padrões de backdoor. Escolhidos por serem raros em código legítimo:
 * execução de texto decodificado, execução direta de dado vindo da
 * requisição, e as assinaturas de webshell mais comuns.
 */
function blindagem_padroes_codigo() {
	// regex => nome da regra (aparece como evidência no painel e no e-mail).
	return array(
		'/\b(eval|assert)\s*\(\s*(base64_decode|gzinflate|gzuncompress|gzdecode|str_rot13|strrev|hex2bin)\s*\(/i' => 'executa texto escondido (eval de texto decodificado)',
		'/\b(eval|assert|system|shell_exec|passthru|exec|popen|proc_open)\s*\(\s*\$_(GET|POST|REQUEST|COOKIE|SERVER)\b/i' => 'executa direto o que vem da requisição',
		'/\bpreg_replace\s*\(\s*[\'"](.).*\1[a-z]*e[a-z]*[\'"]\s*,/i' => 'preg_replace com /e (executa código)',
		'/\bcreate_function\s*\(.*\$_(GET|POST|REQUEST|COOKIE)/i' => 'create_function com dado da requisição',
		// Nomes partidos com ' . ': assim este arquivo não "contém" as assinaturas e a varredura não acusa a si mesma.
		'/(Files' . 'Man|WSO' . 'setcookie|c99' . 'shell|r57' . 'shell|b37' . '4k|Indo' . 'Xploit|Uname:\s*<)/' => 'assinatura de webshell conhecida',
		'/\$\w+\s*=\s*[\'"](?:[A-Za-z0-9+\/]{400,}={0,2})[\'"]\s*;\s*(?:@?eval|\$\w+\s*\()/' => 'bloco base64 enorme executado',
	);
}

/**
 * Assinaturas abertas (1.5.0): regras traduzidas do php-malware-finder (jvoisin/php-malware-finder,
 * LGPL-3.0, commit 87b6d7f, data/php.yar). Só as de pouco alarme falso; ficaram de fora as que contam
 * funções comuns (DangerousPhp), a de caractere não ASCII (pegaria todo "ção" de plugin em português) e
 * as listas de palavras soltas. Achado `assinatura`: só AVISA, nunca vai para a quarentena.
 * Nomes partidos com ' . ' para este arquivo não "conter" as assinaturas (outros antivírus acusariam).
 */
function blindagem_padroes_assinaturas() {
	$entrada = '\$_(GET|POST|REQUEST|COOKIE|SERVER)\b';
	$escondido = '(base64_decode|php:\/\/input|str_rot13|gzinflate|gzuncompress|' . $entrada . ')';
	return array(
		'/\b(md5|sha1)\s*\(\s*' . $entrada . '[^)]*\)\s*===?\s*[\'"][0-9a-f]{32,40}[\'"]/i' => 'porta protegida por senha (webshell)',
		'/\$\w=\$[a-zA-Z]\(\'\',\$\w\);\$\w\(\);/' => 'lançador do weev' . 'ely (webshell)',
		'/[\'"]ev[\'"]\s*\.\s*[\'"]al[\'"]/i' => 'nome de função partido para esconder',
		'/' . $entrada . '\s*\[[^\]]{1,40}\]\s*\(/' => 'executa a função cujo nome vem da requisição',
		'/\b(eval|assert|passthru|system|shell_exec|popen|array_map|call_user_func(_array)?)\s*\(\s*' . $escondido . '/i' => 'executa dado escondido ou da requisição',
		'/\b(array_filter|array_reduce|array_walk(_recursive)?|uasort|uksort|usort|preg_replace_callback|iterator_apply)\s*\(\s*[^,]{1,120},\s*' . $escondido . '/i' => 'função de retorno com dado escondido ou da requisição',
		'/(?<![\w\/$>:-])(include|require)(_once)?\s*\(?\s*[\'"][^\'";\n]{0,80}\.(png|jpe?g|gif|bmp|ico)[\'"]/i' => 'inclui imagem como se fosse código',
		'/\bregister_[a-z]+_function\s*\(\s*[\'"]\s*(eval|assert|passthru|exec|system|shell_exec)\b/i' => 'registra execução de código para depois',
		'/\bextract\s*\(\s*' . $entrada . '/i' => 'transforma a requisição em variáveis (extract)',
		'/\b(eval|assert|system|passthru|shell_exec)\s*\/\*[^*]*\*\/\s*\(/i' => 'comentário escondendo uma execução',
		'/(noitcnuf_' . 'etaerc|\bmet' . 'sys\b|urht' . 'ssap|etucexe_' . 'llehs|edoced_46' . 'esab|etalf' . 'nizg|ecalper_' . 'gerp)/i' => 'nome de função escrito ao contrário',
		'/(ZXZh' . 'bCg|c3lz' . 'dGVt|cHJlZ19y' . 'ZXBsYWNl|YmFzZTY0X2' . 'RlY29kZ)/' => 'função perigosa codificada em base64',
		'/(\\\\x65\\\\x76\\\\x61\\\\x6c\\\\x28|\\\\x73\\\\x79\\\\x73\\\\x74\\\\x65\\\\x6d|\\\\x47\\\\x4c\\\\x4f\\\\x42\\\\x41\\\\x4c\\\\x53)/i' => 'função perigosa escrita em código hexadecimal',
		'/(65766' . '16c28|7379737' . '4656d|474c4f4' . '2414c53)/i' => 'função perigosa empacotada em hexadecimal',
		// Aprendidas do bright-backup-dot real (Tech Marketing, 23/10/2026): funções chamadas por apelido em $GLOBALS.
		'/\$GLOBALS\[[\'"][^\'"]{1,60}[\'"]\]\s*\(/' => 'chama função escondida em $GLOBALS (truque de vírus)',
		'/(SC_CORE_' . 'BOOT_VER|sc_boot' . '_ver|__scf' . '_[a-z0-9_]{6,})/' => 'marca da família bright-' . 'backup-dot (vírus visto nos sites em out/2026)',
		'/chk_' . 'jschl.{0,2000}jschl_' . '(vc|answer)/s' => 'contorna a proteção da Cloudflare',
		'/(1337' . 'day\.com|anti' . 'chat\.ru|cc' . 'team\.ru|dark' . 'c0de|egy' . 'spider\.eu|fopo\.com' . '\.ar|milw0' . 'r?m\.com|php' . 'jiami\.com|muma' . 'asp\.com)/i' => 'endereço de site de ferramentas de invasão',
	);
}

/** Evidência de assinatura aberta: "regra — linha N: trecho", ou ''. */
function blindagem_assinatura( $caminho ) {
	$conteudo = @file_get_contents( $caminho, false, null, 0, 512 * KB_IN_BYTES ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	if ( false === $conteudo || '' === $conteudo ) {
		return '';
	}
	foreach ( blindagem_padroes_assinaturas() as $regex => $regra ) {
		if ( preg_match( $regex, $conteudo, $m, PREG_OFFSET_CAPTURE ) ) {
			$linha  = substr_count( $conteudo, "\n", 0, $m[0][1] ) + 1;
			$trecho = preg_replace( '/\s+/', ' ', substr( $conteudo, $m[0][1], 90 ) );
			return sprintf( '%s — linha %d: %s…', $regra, $linha, wp_check_invalid_utf8( $trecho, true ) );
		}
	}
	return '';
}

/**
 * Evidência de código suspeito: "regra — linha N: trecho", ou '' se limpo.
 * Arquivo gigante não é lido inteiro: backdoor costuma ser pequeno ou vir no
 * começo do arquivo injetado.
 */
function blindagem_codigo_suspeito( $caminho ) {
	$conteudo = @file_get_contents( $caminho, false, null, 0, 512 * KB_IN_BYTES ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	if ( false === $conteudo ) {
		return '';
	}

	foreach ( blindagem_padroes_codigo() as $regex => $regra ) {
		if ( preg_match( $regex, $conteudo, $m, PREG_OFFSET_CAPTURE ) ) {
			$linha  = substr_count( $conteudo, "\n", 0, $m[0][1] ) + 1;
			$trecho = preg_replace( '/\s+/', ' ', substr( $conteudo, $m[0][1], 90 ) );
			return sprintf( '%s — linha %d: %s…', $regra, $linha, wp_check_invalid_utf8( $trecho, true ) );
		}
	}

	return '';
}

function blindagem_tem_codigo_suspeito( $caminho ) {
	return '' !== blindagem_codigo_suspeito( $caminho );
}

/** Evidência básica de um arquivo: tamanho e quando mudou. */
function blindagem_dados_arquivo( $caminho ) {
	if ( ! is_file( $caminho ) ) {
		return '';
	}
	return sprintf( '%s, modificado em %s', size_format( filesize( $caminho ) ), wp_date( 'd/m/Y H:i', filemtime( $caminho ) ) );
}


/* ==========================================================================
   Varredura
   ========================================================================== */

/**
 * index.php que plugin põe em pasta de uploads para não listar: vazio, "Silence is golden" ou só
 * mandando 404 (WPForms em uploads/wpforms/cache). Qualquer outra linha = suspeito.
 */
function blindagem_index_inofensivo( $arquivo ) {
	if ( 'index.php' !== $arquivo->getFilename() || $arquivo->getSize() > 300 ) {
		return false;
	}
	$codigo = (string) @file_get_contents( $arquivo->getPathname() ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
	$codigo = preg_replace( '/^\s*header\(\s*\$_SERVER\[\s*[\'"]SERVER_PROTOCOL[\'"]\s*\]\s*\.\s*[\'"] 404 Not Found[\'"]\s*\);\s*$|^\s*header\(\s*[\'"]Status: 404 Not Found[\'"]\s*\);\s*$/m', '', $codigo );
	return (bool) preg_match( '/^<\?php\s*(\/\/\s*Silence is golden\.?)?\s*$/i', (string) $codigo );
}

/** default.php da Hostinger ("Está tudo pronto!"): HTML puro, sem PHP. Não é backdoor. */
function blindagem_pagina_padrao_hostinger( $caminho ) {
	if ( 'default.php' !== basename( $caminho ) || filesize( $caminho ) > 65536 ) {
		return false;
	}
	$texto = (string) @file_get_contents( $caminho ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
	return false !== strpos( $texto, 'hpanel.hostinger.com' ) && ! preg_match( '/<\?(php|=)?/i', $texto );
}

function blindagem_varrer() {
	$achados = array();
	$limite  = 200; // Num site tomado a lista seria enorme; as primeiras já provam.

	$uploads = wp_get_upload_dir();
	$uploads = wp_normalize_path( $uploads['basedir'] );

	// 1. PHP em uploads/.
	blindagem_percorrer( $uploads, function ( $arquivo ) use ( &$achados, $limite ) {
		if ( preg_match( '/\.(php\d?|phtml|pht|phar|phps)$/i', $arquivo->getFilename() ) && ! blindagem_index_inofensivo( $arquivo ) ) {
			$achados[] = array( 'php_uploads', $arquivo->getPathname() );
		}
		return count( $achados ) < $limite;
	} );

	// 2. Compactado de nome hexadecimal/aleatório em wp-content/ — é como
	//    kits de invasão costumam ser largados (ex.: ef04646d.zip). E nome com
	//    bytes inválidos em qualquer lugar de wp-content/.
	blindagem_percorrer( WP_CONTENT_DIR, function ( $arquivo ) use ( &$achados, $limite ) {
		if ( blindagem_nome_estranho( $arquivo->getFilename() ) ) {
			$achados[] = array( 'nome_estranho', $arquivo->getPathname() );
		} elseif ( preg_match( '/^[0-9a-f]{6,40}\.(zip|tar|gz|tgz|rar|7z)$/i', $arquivo->getFilename() ) ) {
			$achados[] = array( 'compactado', $arquivo->getPathname() );
		}
		return count( $achados ) < $limite;
	} );

	// 2b. Raiz do site e raiz de wp-content: nome inválido, PHP disfarçado (sem .php) e, na raiz do site,
	//     arquivo que não costuma estar lá. Antes só os .php da raiz eram olhados — um arquivo de nome
	//     quebrado e 6 MB passava direto (visto na Caruaru Joias em 15/10/2026).
	foreach ( array( ABSPATH, trailingslashit( WP_CONTENT_DIR ) ) as $n_pasta => $pasta ) {
		foreach ( (array) @scandir( $pasta ) as $nome ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			$caminho = $pasta . $nome;
			if ( '.' === $nome || '..' === $nome || ! is_file( $caminho ) || is_link( $caminho ) ) {
				continue;
			}
			$eh_php = (bool) preg_match( '/\.(php\d?|phtml|pht|phar)$/i', $nome );
			if ( blindagem_nome_estranho( $nome ) ) {
				if ( 1 === $n_pasta ) {
					continue; // wp-content já passou pelo item 2
				}
				$achados[] = array( 'nome_estranho', $caminho, null, blindagem_dados_arquivo( $caminho ) . ( blindagem_tem_php( $caminho ) ? '. TEM CÓDIGO PHP' : '' ) );
			} elseif ( ! $eh_php && blindagem_tem_php( $caminho ) && ! preg_match( '/^(\.htaccess|\.user\.ini|php\.ini)$/i', $nome ) ) {
				$achados[] = array( 'php_disfarcado', $caminho );
			} elseif ( 0 === $n_pasta && ! blindagem_raiz_conhecido( $nome ) ) {
				$achados[] = array( 'raiz_desconhecido', $caminho );
			}
		}
	}

	// 2b'. Arquivo escondido (nome com ponto na frente) no 1º nível de wp-content, plugins, mu-plugins, themes e
	//      uploads. O malware do Perfil Portas (20/10/2026) deixou ali .4111357d.php (o glob *.php não vê
	//      arquivo com ponto), marcadores vazios (.gk_…, .kk_…, .sc_…, .rd_<plugin falso>) e a carga cifrada
	//      em .wp-object-cache-<hex>.dat / .dat.lkg. Nenhum plugin legítimo conhecido guarda nada assim.
	foreach ( array_unique( array( WP_CONTENT_DIR, WP_PLUGIN_DIR, WPMU_PLUGIN_DIR, get_theme_root(), $uploads ) ) as $pasta ) {
		$pasta = trailingslashit( wp_normalize_path( $pasta ) );
		foreach ( (array) @scandir( $pasta ) as $nome ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( '.' !== substr( (string) $nome, 0, 1 ) || '.' === $nome || '..' === $nome || ! is_file( $pasta . $nome ) || is_link( $pasta . $nome ) ) {
				continue;
			}
			if ( preg_match( '/^\.(htaccess|user\.ini|DS_Store|litespeed_conf\.dat|gitignore|gitkeep)$/i', $nome ) ) {
				continue; // legítimos conhecidos (LiteSpeed Cache guarda a config em .litespeed_conf.dat)
			}
			$achados[] = array( 'escondido', $pasta . $nome, null, blindagem_dados_arquivo( $pasta . $nome ) . ( blindagem_tem_php( $pasta . $nome ) ? '. TEM CÓDIGO PHP' : '' ) );
		}
	}

	// 2c. Configuração que roda PHP por fora: auto_prepend_file (carrega um arquivo antes de toda página)
	//     e handler de PHP para outra extensão (faz .jpg/.txt virar programa).
	$uploads_ht = $uploads . '/.htaccess';
	foreach ( array( ABSPATH . '.htaccess', ABSPATH . '.user.ini', ABSPATH . 'php.ini', WP_CONTENT_DIR . '/.htaccess', $uploads_ht ) as $config ) {
		if ( is_file( $config ) ) {
			$evidencia = blindagem_config_suspeita( $config );
			if ( $evidencia ) {
				$achados[] = array( 'config_php', $config, null, $evidencia );
			}
		}
	}

	// 2d. Uploads: imagem/arquivo com código PHP escondido (até 20 MB; lê só as pontas).
	blindagem_percorrer( $uploads, function ( $arquivo ) use ( &$achados, $limite ) {
		if ( $arquivo->getSize() <= 20971520 && ! preg_match( '/\.(php\d?|phtml|pht|phar|phps)$/i', $arquivo->getFilename() ) && blindagem_tem_php( $arquivo->getPathname() ) ) {
			$achados[] = array( 'php_disfarcado', $arquivo->getPathname() );
		}
		return count( $achados ) < $limite;
	} );

	// 3. mu-plugins: carregam sozinhos e não aparecem na lista de plugins.
	blindagem_percorrer( WPMU_PLUGIN_DIR, function ( $arquivo ) use ( &$achados, $limite ) {
		if ( preg_match( '/\.php$/i', $arquivo->getFilename() ) ) {
			$achados[] = array( 'mu_plugin', $arquivo->getPathname() );
		}
		return count( $achados ) < $limite;
	} );

	// 4. PHP solto na raiz de wp-content: drop-ins (advanced-cache.php,
	//    db.php…) também carregam sozinhos. Legítimos com plugin de cache —
	//    por isso dá para reconhecer.
	foreach ( (array) glob( WP_CONTENT_DIR . '/*.php' ) as $arquivo ) {
		if ( 'index.php' !== basename( $arquivo ) ) {
			$achados[] = array( 'raiz_conteudo', $arquivo );
		}
	}

	// 5. Código com cara de backdoor em temas, mu-plugins e uploads. Plugins
	//    do wordpress.org ficam com a checagem de integridade, que é exata;
	//    aqui entram os que não têm como ser comparados.
	if ( blindagem_ligado( 'codigo_suspeito' ) ) {
		$pastas = array( get_theme_root(), WPMU_PLUGIN_DIR, $uploads );

		// A própria Blindagem fica de fora: o código dela contém, de propósito,
		// os nomes de webshell que ela procura.
		$propria = wp_normalize_path( dirname( BLINDAGEM_ARQUIVO ) );
		foreach ( blindagem_plugins_sem_checksum() as $pasta_plugin ) {
			if ( wp_normalize_path( $pasta_plugin ) !== $propria ) {
				$pastas[] = $pasta_plugin;
			}
		}

		foreach ( $pastas as $pasta ) {
			blindagem_percorrer( $pasta, function ( $arquivo ) use ( &$achados, $limite ) {
				if ( preg_match( '/\.(php\d?|phtml|pht|inc)$/i', $arquivo->getFilename() ) ) {
					$evidencia = blindagem_codigo_suspeito( $arquivo->getPathname() );
					if ( $evidencia ) {
						$achados[] = array( 'codigo', $arquivo->getPathname(), null, $evidencia );
					} else {
						$assinatura = blindagem_assinatura( $arquivo->getPathname() );
						if ( $assinatura ) {
							$achados[] = array( 'assinatura', $arquivo->getPathname(), null, $assinatura );
						}
					}
				}
				return count( $achados ) < $limite;
			} );
		}
	}

	// 6. Banco e agendamentos: infecção que não é arquivo.
	if ( blindagem_ligado( 'codigo_suspeito' ) ) {
		$achados = array_merge( $achados, blindagem_varrer_banco(), blindagem_varrer_cron() );
	}

	// 7. Foto: arquivo novo/alterado/apagado em tema e plugin sem original oficial.
	if ( blindagem_ligado( 'foto' ) ) {
		$observacao = '';
		$achados    = array_merge( $achados, blindagem_foto_comparar( $observacao ) );
		$GLOBALS['blindagem_observacao_varredura'] = $observacao;
	}

	return $achados;
}

/**
 * Script injetado no banco: o tipo de infecção mais comum hoje em
 * WordPress — não cria arquivo nenhum, grava <script> em post ou opção e
 * redireciona o visitante para golpe. Só vira achado o script que carrega de
 * domínio fora da lista conhecida ou que vem ofuscado.
 */
/** Devolve a evidência (string) ou false. */
function blindagem_script_suspeito( $texto ) {
	if ( ! preg_match_all( '#<script\b([^>]*)>(.*?)</script>#is', $texto, $scripts, PREG_SET_ORDER ) ) {
		return false;
	}

	$meu       = wp_parse_url( home_url(), PHP_URL_HOST );
	$conhecidos = apply_filters( 'blindagem_dominios_script', array(
		$meu, 'googletagmanager.com', 'google-analytics.com', 'google.com', 'gstatic.com', 'googleapis.com',
		'facebook.net', 'facebook.com', 'instagram.com', 'youtube.com', 'vimeo.com', 'hotjar.com', 'clarity.ms',
		'cloudflare.com', 'jsdelivr.net', 'unpkg.com', 'jquery.com', 'tiktok.com', 'linkedin.com', 'pinterest.com',
		'doubleclick.net', 'hubspot.com', 'rdstation.com.br', 'rdstation.com', 'wp.com', 'wordpress.com',
	) );

	foreach ( $scripts as $s ) {
		if ( preg_match( '#\bsrc\s*=\s*["\']?(?:https?:)?//([^/"\'\s>]+)#i', $s[1], $m ) ) {
			$host = strtolower( $m[1] );
			$ok   = false;
			foreach ( $conhecidos as $d ) {
				if ( $host === $d || substr( $host, -strlen( '.' . $d ) ) === '.' . $d ) {
					$ok = true;
					break;
				}
			}
			if ( ! $ok ) {
				return 'script carregado de domínio desconhecido: ' . $host;
			}
		}
		if ( preg_match( '#\b(eval|atob)\s*\(|String\.fromCharCode\s*\(|document\.write\s*\(\s*unescape|\\x[0-9a-f]{2}\\x[0-9a-f]{2}\\x[0-9a-f]{2}#i', $s[2], $m ) ) {
			return 'script com código escondido: ' . mb_substr( preg_replace( '/\s+/', ' ', $s[2] ), 0, 80 ) . '…';
		}
	}
	return false;
}

function blindagem_varrer_banco() {
	global $wpdb;
	$achados = array();

	$posts = $wpdb->get_results( "SELECT ID, post_title, post_type, post_content FROM {$wpdb->posts} WHERE post_status NOT IN ('auto-draft','inherit') AND post_content LIKE '%<script%' LIMIT 500" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $posts as $p ) {
		$evidencia = blindagem_script_suspeito( $p->post_content );
		if ( $evidencia ) {
			$achados[] = array( 'banco_script', sprintf( 'banco: %s #%d "%s"', $p->post_type, $p->ID, mb_substr( $p->post_title, 0, 60 ) ), md5( $p->post_content ), $evidencia );
		}
	}

	$opcoes = $wpdb->get_results( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_value LIKE '%<script%' AND option_name NOT LIKE '\\_%transient%' LIMIT 500" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $opcoes as $o ) {
		$evidencia = blindagem_script_suspeito( $o->option_value );
		if ( $evidencia ) {
			$achados[] = array( 'banco_script', 'banco: opção ' . $o->option_name, md5( $o->option_value ), $evidencia );
		}
	}

	return $achados;
}

/**
 * Tarefa agendada suspeita. Malware usa o WP-Cron para se reinstalar depois
 * da limpeza: o código fica num lugar estranho e a tarefa o chama todo dia.
 */
function blindagem_varrer_cron() {
	global $wp_filter;
	$achados = array();
	$uploads = wp_normalize_path( wp_get_upload_dir()['basedir'] ) . '/';

	foreach ( (array) _get_cron_array() as $quando => $hooks ) {
		foreach ( (array) $hooks as $hook => $eventos ) {
			$motivos = array();

			// Nome aleatório (só hex ou letra+número sem sentido).
			if ( preg_match( '/^[0-9a-f]{8,}$/i', $hook ) || preg_match( '/^(?=.*\d)[a-z0-9]{16,}$/i', $hook ) ) {
				$motivos[] = 'nome aleatório';
			}

			// Argumentos com código.
			$args = wp_json_encode( wp_list_pluck( (array) $eventos, 'args' ) );
			if ( preg_match( '/[A-Za-z0-9+\/]{300,}={0,2}|<\?php|\beval\s*\(|base64_decode/i', (string) $args ) ) {
				$motivos[] = 'argumentos com código';
			}

			// Quem responde: arquivo em uploads/ ou código criado em tempo de execução.
			if ( ! empty( $wp_filter[ $hook ] ) ) {
				foreach ( $wp_filter[ $hook ]->callbacks as $por_prioridade ) {
					foreach ( $por_prioridade as $cb ) {
						try {
							$f   = $cb['function'];
							$ref = is_array( $f ) ? new ReflectionMethod( $f[0], $f[1] ) : ( is_string( $f ) && strpos( $f, '::' ) ? new ReflectionMethod( $f ) : new ReflectionFunction( $f ) );
							$arq = wp_normalize_path( (string) $ref->getFileName() );
						} catch ( ReflectionException $e ) {
							continue;
						}
						if ( 0 === strpos( $arq, $uploads ) ) {
							$motivos[] = 'código em uploads/ (' . blindagem_relativo( $arq ) . ')';
						} elseif ( preg_match( "/eval\(\)'d code|runtime-created/", $arq ) ) {
							$motivos[] = 'código criado por eval';
						}
					}
				}
			}

			if ( $motivos ) {
				$achados[ $hook ] = array( 'cron_suspeito', 'agendamento: ' . $hook, md5( $hook . $args ), implode( '; ', array_unique( $motivos ) ) );
			}
		}
	}

	return array_values( $achados );
}


/* ==========================================================================
   Integridade — core e plugins contra o wordpress.org
   ========================================================================== */

function blindagem_integridade_core() {
	global $wp_version, $wp_local_package;

	$locale   = empty( $wp_local_package ) ? 'en_US' : $wp_local_package;
	$resposta = wp_remote_get(
		add_query_arg( array( 'version' => $wp_version, 'locale' => $locale ), 'https://api.wordpress.org/core/checksums/1.0/' ),
		array( 'timeout' => 30 )
	);

	if ( is_wp_error( $resposta ) || 200 !== wp_remote_retrieve_response_code( $resposta ) ) {
		return null; // Sem a lista oficial não dá para concluir nada. Silêncio é melhor que alarme falso.
	}

	$dados = json_decode( wp_remote_retrieve_body( $resposta ), true );
	$lista = isset( $dados['checksums'][ $wp_version ] ) ? $dados['checksums'][ $wp_version ] : ( $dados['checksums'] ?? null );

	if ( ! is_array( $lista ) || ! $lista ) {
		return null;
	}

	$achados = array();

	foreach ( $lista as $arquivo => $md5 ) {
		if ( 0 === strpos( $arquivo, 'wp-content/' ) ) {
			continue; // Não é core: tema, plugin e uploads mudam o tempo todo.
		}

		$caminho = ABSPATH . $arquivo;

		// Arquivo faltando não é alerta: readme.html e license.txt são
		// apagados de propósito em muito site.
		if ( file_exists( $caminho ) && md5_file( $caminho ) !== $md5 ) {
			$achados[] = array( 'core_alterado', $caminho );
		}
	}

	// Arquivo NOVO dentro de wp-admin/ e wp-includes/, ou PHP novo na raiz:
	// é onde backdoor se esconde para parecer core.
	$candidatos = array();
	foreach ( array( 'wp-admin', 'wp-includes' ) as $pasta ) {
		blindagem_percorrer( ABSPATH . $pasta, function ( $arquivo ) use ( &$candidatos ) {
			$candidatos[] = $arquivo->getPathname();
		} );
	}
	foreach ( (array) glob( ABSPATH . '*.php' ) as $arquivo ) {
		$candidatos[] = $arquivo;
	}

	foreach ( $candidatos as $caminho ) {
		$relativo = blindagem_relativo( $caminho );
		if ( ! isset( $lista[ $relativo ] ) && ! in_array( $relativo, array( 'wp-config.php' ), true ) && ! blindagem_pagina_padrao_hostinger( $caminho ) ) {
			$achados[] = array( 'core_extra', $caminho );
		}
	}

	return $achados;
}

/**
 * Pastas de plugin que não estão no wordpress.org (pagos, próprios) — sem
 * checksum oficial, vão para a busca por código suspeito. Guardado da
 * última checagem de integridade.
 */
function blindagem_plugins_sem_checksum() {
	$lista = get_option( 'blindagem_sem_checksum', array() );
	$lista = is_array( $lista ) ? $lista : array();

	return array_filter( array_map( function ( $slug ) {
		return WP_PLUGIN_DIR . '/' . $slug;
	}, $lista ), 'is_dir' );
}

function blindagem_integridade_plugins() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$achados       = array();
	$sem_checksum  = array();

	foreach ( get_plugins() as $arquivo_principal => $info ) {
		$slug = dirname( $arquivo_principal );
		if ( '.' === $slug ) {
			continue; // Plugin de um arquivo só, fora de pasta.
		}

		$resposta = wp_remote_get(
			sprintf( 'https://downloads.wordpress.org/plugin-checksums/%s/%s.json', rawurlencode( $slug ), rawurlencode( $info['Version'] ) ),
			array( 'timeout' => 20 )
		);

		$dados = is_wp_error( $resposta ) || 200 !== wp_remote_retrieve_response_code( $resposta )
			? null
			: json_decode( wp_remote_retrieve_body( $resposta ), true );

		if ( empty( $dados['files'] ) || ! is_array( $dados['files'] ) ) {
			$sem_checksum[] = $slug;
			continue;
		}

		$base = WP_PLUGIN_DIR . '/' . $slug . '/';

		foreach ( $dados['files'] as $relativo => $somas ) {
			$caminho = $base . $relativo;
			if ( ! file_exists( $caminho ) || empty( $somas['md5'] ) ) {
				continue;
			}
			// O wordpress.org manda uma soma ou uma lista (arquivo que mudou
			// entre builds da mesma versão).
			if ( ! in_array( md5_file( $caminho ), (array) $somas['md5'], true ) ) {
				$achados[] = array( 'plugin_alterado', $caminho );
			}
		}

		blindagem_percorrer( $base, function ( $arquivo ) use ( $base, $dados, &$achados ) {
			$relativo = substr( wp_normalize_path( $arquivo->getPathname() ), strlen( wp_normalize_path( $base ) ) );
			if ( preg_match( '/\.(php\d?|phtml|pht|phar)$/i', $relativo ) && ! isset( $dados['files'][ $relativo ] ) ) {
				$achados[] = array( 'plugin_extra', $arquivo->getPathname() );
			}
		} );
	}

	update_option( 'blindagem_sem_checksum', $sem_checksum, false );

	return array_merge( $achados, blindagem_plugins_estranhos( $sem_checksum ) );
}

/** Hash e lista (até 8 arquivos, "nome (tamanho)") de uma pasta em plugins/ que não é plugin. */
function blindagem_casca_assinatura( $pasta ) {
	$lista = array();
	blindagem_percorrer( $pasta, function ( $arquivo ) use ( &$lista ) {
		$lista[] = $arquivo->getFilename() . ' (' . size_format( $arquivo->getSize() ) . ')';
		return count( $lista ) < 8;
	} );
	return array( md5( implode( '|', $lista ) ), $lista );
}

/**
 * Plugins que a foto não pega por já existirem antes dela (visto na Caruaru Joias: 5 pastas de nome sorteado,
 * "turbo-builder-dex" e cia., com o PHP principal vazio e marcadores .bt_/.rd_/.sd_):
 * pasta que não é plugin, plugin ativo escondido da lista e plugin fora do wordpress.org.
 */
function blindagem_plugins_estranhos( $sem_checksum ) {
	$achados    = array();
	$todos      = get_plugins();
	$registradas = array();
	foreach ( array_keys( $todos ) as $principal ) {
		$registradas[ dirname( $principal ) ] = true;
	}
	$propria = basename( dirname( BLINDAGEM_ARQUIVO ) );

	// Pasta sem plugin dentro.
	foreach ( (array) glob( WP_PLUGIN_DIR . '/*', GLOB_ONLYDIR ) as $pasta ) {
		if ( isset( $registradas[ basename( $pasta ) ] ) || is_link( $pasta ) ) {
			continue;
		}
		list( $hash, $lista ) = blindagem_casca_assinatura( $pasta );
		$achados[] = array( 'plugin_casca', $pasta, $hash, $lista ? 'tem: ' . implode( ', ', $lista ) : 'pasta vazia' );
	}

	// Ativo mas escondido: some de apply_filters( 'all_plugins' ), que é o que a tela de plugins mostra.
	$visiveis = (array) apply_filters( 'all_plugins', $todos );
	foreach ( (array) get_option( 'active_plugins', array() ) as $ativo ) {
		if ( isset( $todos[ $ativo ] ) && ! isset( $visiveis[ $ativo ] ) ) {
			$caminho   = WP_PLUGIN_DIR . '/' . $ativo;
			$achados[] = array( 'plugin_escondido', $caminho, is_file( $caminho ) ? md5_file( $caminho ) : '', 'ativo, mas não aparece em Plugins → Plugins instalados' );
		}
	}

	// Fora do wordpress.org (a própria Blindagem fica de fora).
	$ativos = (array) get_option( 'active_plugins', array() );
	foreach ( $todos as $principal => $info ) {
		$slug = dirname( $principal );
		if ( '.' === $slug || $slug === $propria || ! in_array( $slug, $sem_checksum, true ) ) {
			continue;
		}
		$achados[] = array(
			'plugin_fora_wporg',
			WP_PLUGIN_DIR . '/' . $slug,
			md5( $slug . '|' . $info['Version'] . '|' . $info['Author'] ),
			sprintf( '%s %s, de %s; %s', $info['Name'], $info['Version'], $info['Author'] ? wp_strip_all_tags( $info['Author'] ) : 'autor desconhecido', in_array( $principal, $ativos, true ) ? 'ATIVO' : 'desativado' ),
		);
	}

	return $achados;
}


/* ==========================================================================
   Relatório, reconhecimento e alerta
   ========================================================================== */

/** Tira os achados que o admin já reconheceu e cujo arquivo não mudou. */
function blindagem_filtrar_reconhecidos( $achados ) {
	$conhecidos = get_option( 'blindagem_reconhecidos', array() );
	$saida      = array();

	foreach ( $achados as $achado ) {
		list( $tipo, $caminho ) = $achado;
		$relativo = blindagem_guardavel( blindagem_relativo( $caminho ) );
		$hash     = $achado[2] ?? ( is_readable( $caminho ) ? md5_file( $caminho ) : '' );
		$hash     = (string) $hash;

		if ( isset( $conhecidos[ $relativo ] ) && $conhecidos[ $relativo ] === $hash ) {
			continue;
		}

		$saida[] = array(
			'tipo'      => $tipo,
			'arquivo'   => $relativo,
			'hash'      => $hash,
			'evidencia' => $achado[3] ?? blindagem_dados_arquivo( $caminho ),
		);
	}

	return $saida;
}

/**
 * Roda 'varredura' ou 'integridade', guarda o relatório e avisa por e-mail
 * se o resultado mudou. E-mail diário de "continua igual" vira ruído e
 * ninguém lê; tudo limpo também não manda nada.
 */
function blindagem_rodar( $qual ) {
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}

	if ( 'integridade' === $qual ) {
		$core = blindagem_integridade_core();
		$brutos = array_merge( (array) $core, blindagem_integridade_plugins() );
		$observacao = null === $core ? 'Não foi possível baixar a lista oficial do core — verificação do core pulada.' : '';
	} else {
		$GLOBALS['blindagem_observacao_varredura'] = '';
		$brutos = blindagem_varrer();
		$observacao = $GLOBALS['blindagem_observacao_varredura'];
	}

	$achados = blindagem_filtrar_reconhecidos( $brutos );

	$relatorio = array(
		'quando'     => current_time( 'mysql' ),
		'achados'    => $achados,
		'observacao' => $observacao,
	);

	update_option( 'blindagem_rel_' . $qual, $relatorio, false );

	// Assinatura conhecida do vírus vai sozinha para a quarentena (inc/vigia.php); a casca de plugin vem da integridade.
	if ( blindagem_quarentena_automatica( $achados ) ) {
		$relatorio = get_option( 'blindagem_rel_' . $qual );
		$achados   = $relatorio['achados'];
	}
	if ( 'varredura' === $qual ) {
		blindagem_quarentena_expirar();
	}

	$assinatura = md5( wp_json_encode( wp_list_pluck( $achados, 'arquivo' ) ) );
	$anterior   = get_option( 'blindagem_alertado_' . $qual );

	if ( $achados && $assinatura !== $anterior ) {
		blindagem_enviar_alerta( $qual, $achados );
	}

	update_option( 'blindagem_alertado_' . $qual, $achados ? $assinatura : '', false );

	return $relatorio;
}

function blindagem_enviar_alerta( $qual, $achados ) {
	$rotulos = blindagem_tipos_achado();
	$linhas  = array();

	foreach ( $achados as $achado ) {
		$linhas[] = sprintf( '- %s: %s', $rotulos[ $achado['tipo'] ] ?? $achado['tipo'], blindagem_visivel( $achado['arquivo'] ) );
		if ( ! empty( $achado['evidencia'] ) ) {
			$linhas[] = '    Por quê: ' . $achado['evidencia'];
		}
	}

	wp_mail(
		blindagem_email_alerta(),
		sprintf( '[%s] ALERTA de segurança: %s encontrou arquivo suspeito', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), 'integridade' === $qual ? 'a checagem de integridade' : 'a varredura' ),
		sprintf(
			"Site: %s\n\n%s\n\n---\nO que fazer:\n" .
			"1. NÃO apague antes de olhar — o arquivo é a prova de como entraram.\n" .
			"2. Arquivo do core alterado: `wp core download --force --skip-content` restaura.\n" .
			"   Plugin alterado: reinstale o plugin pelo painel ou `wp plugin install <nome> --force`.\n" .
			"3. Depois de limpar: troque as senhas e rode `wp config shuffle-salts`.\n" .
			"4. Se o arquivo for legítimo, reconheça em Configurações → Blindagem.\n\n%s\n",
			home_url( '/' ),
			implode( "\n", $linhas ),
			admin_url( 'options-general.php?page=blindagem' )
		)
	);
}

/** Aviso no painel — e-mail de hospedagem compartilhada se perde. */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$total = 0;
	foreach ( array( 'varredura', 'integridade' ) as $qual ) {
		$relatorio = get_option( 'blindagem_rel_' . $qual );
		$total    += is_array( $relatorio ) ? count( $relatorio['achados'] ) : 0;
	}

	if ( ! $total ) {
		return;
	}

	printf(
		'<div class="notice notice-error"><p><strong>Blindagem:</strong> %d arquivo(s) suspeito(s) encontrado(s). <a href="%s">Ver o relatório</a></p></div>',
		(int) $total,
		esc_url( admin_url( 'options-general.php?page=blindagem&aba=verificacao' ) )
	);
} );
